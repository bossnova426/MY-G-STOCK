
export const DevDocs = `# 技术设计与开发文档 (GeminiQuant)

## 1. 项目概述
**GeminiQuant** 是一个基于 **React**, **TypeScript** 和 **Tailwind CSS** 构建的专业级股票分析仪表盘。它利用 **Google Gemini 模型** 进行实时的市场情绪分析和技术形态识别。

### 核心技术栈
*   **框架:** React 19 (基于 ESM)
*   **语言:** TypeScript
*   **样式:** Tailwind CSS (支持深色/浅色模式)
*   **图表:** \`lightweight-charts\` (TradingView 风格) & \`recharts\` (统计图表)
*   **AI:** \`@google/genai\` (Gemini 2.5/3 Flash 模型)
*   **图标:** \`lucide-react\`
*   **构建/运行:** 浏览器原生 ES Modules (通过 \`index.html\` importmap 加载)。

---

## 2. 架构与数据流

### A. 中心状态管理 (\`App.tsx\`)
本项目不使用 Redux 或 Context API 进行全局管理。相反，\`App.tsx\` 作为中心控制器：
1.  **工作区 (Workspaces):** 管理 \`Workspace\` 对象列表，每个工作区包含一个 \`Widgets\` 网格。
2.  **分组状态 (Group States):** 管理 \`groupStates\` (Record<string, GroupState>)。
    *   *概念:* 每个 Widget 被分配一个 "链接组" (Link Group, 1-6)。
    *   同一组 (例如 Group 1) 内的所有 Widget 共享相同的 **股票代码 (Symbol)**、**图表数据**、**新闻**和**分析结果**。
    *   在一个 Widget 中更改股票代码会自动更新整个组的数据。
3.  **观察列表 (Watchlists):** 管理用户自定义和系统预设（只读）的观察列表。

### B. 插件架构 (\`pluginRegistry.tsx\`)
应用采用模块化组件系统。所有插件组件均位于 \`components/widgets/\` 目录下，并按领域分类：
*   **trading/**: 交易相关 (K线图, 深度行情, 交易列表)
*   **analysis/**: 分析工具 (基本面, RRG, 产业链)
*   **info/**: 资讯信息 (新闻, 浏览器, AI对话)
*   **tools/**: 系统工具 (观察列表, 选股器, 预警)

*   **注册表:** \`REGISTERED_PLUGINS\` 将字符串 ID (如 'CHART', 'NEWS') 映射到组件和元数据。
*   **上下文:** 每个 Widget 组件都接收 \`WidgetContext\` props，其中包含：
    *   数据: \`chartData\`, \`news\`, \`analysis\`, \`profile\`。
    *   操作: \`onSymbolSelect\`, \`onAddStockToWatchlists\` 等。
    *   配置: \`widgetConfig\` (特定于该 Widget 实例的配置)。

### C. 统一指标系统 (\`services/indicatorService.ts\`)
**关键点:** 此文件是所有指标数据的 "唯一事实来源 (Source of Truth)"。
*   **定义:** 同时定义 **技术指标** (SMA, RSI - 客户端计算) 和 **基本面指标** (PE Ratio - 模拟/API获取)。
*   **用途:**
    *   **图表 (Charts):** 使用 \`calculate()\` 函数在 \`lightweight-charts\` 上绘制叠加线。
    *   **选股器 (Screener):** 使用元数据 (\`category\`, \`dataType\`) 构建过滤 UI。
    *   **观察列表 (Watchlist):** 使用定义来填充表头和单元格数据。
*   **规则:** 若要添加新指标，必须添加到此处的 \`INDICATOR_REGISTRY\`。严禁在组件中硬编码指标逻辑。

---

## 3. 目录结构与关键文件

| 文件路径 | 职责 |
| :--- | :--- |
| \`index.html\` | 入口文件，Import Maps 配置，Tailwind 配置，CSS 变量。 |
| \`App.tsx\` | 主布局，状态容器，Widget 网格逻辑，主题管理。 |
| \`components/GridItem.tsx\` | (Refactored) 独立的网格卡片容器，处理头部、拖拽手柄和链接组。 |
| \`components/LinkGroupSelector.tsx\` | (Refactored) 链接组颜色选择器组件。 |
| \`types.ts\` | 全局类型定义 (\`Widget\`, \`StockDataPoint\`, \`AnalysisResult\`)。 |
| \`constants.ts\` | 模拟数据，默认设置，过滤器定义。 |
| \`pluginRegistry.tsx\` | 插件注册表，处理 **Code Splitting (React.lazy)**。 |
| \`services/geminiService.ts\` | 处理 Google GenAI API 调用，包含重试逻辑和错误处理。 |
| \`services/indicatorService.ts\` | 指标数学逻辑 (SMA, EMA, RSI) 和指标注册表。 |
| \`services/eventBus.ts\` | 简单的 Pub/Sub 事件总线，用于跨组件通信 (如点击股票)。 |
| \`components/widgets/trading/\` | 交易类组件目录。 |
| \`components/widgets/analysis/\` | 分析类组件目录。 |
| \`components/widgets/info/\` | 信息类组件目录。 |
| \`components/widgets/tools/\` | 工具类组件目录。 |

---

## 4. 关键组件实现细节

### 股票图表 (\`components/widgets/trading/StockChart/StockChart.tsx\`)
*   **库:** 使用 \`lightweight-charts\`。
*   **逻辑:**
    *   接收原始 OHLCV 数据。
    *   在 \`useMemo\` 中通过 \`indicatorService\` 计算当前激活的指标。
    *   通过 Refs 管理多个序列 (K线, 成交量直方图, 线形图)。
    *   通过 \`sharedHoverLabel\` prop 实现跨图表的十字准线同步。

### 选股器 (\`components/widgets/tools/Screener/Screener.tsx\`)
*   **逻辑:** 支持嵌套逻辑组 (AND/OR)。
*   **执行:** 目前基于模拟数据进行客户端过滤。
*   **估算:** 基于过滤条件的严格程度，防抖 (Debounced) 计算 "预计匹配数量"。

### 观察列表 (\`components/widgets/tools/Watchlist/Watchlist.tsx\`)
*   **特性:**
    *   列拖拽排序。
    *   自定义公式列 (\`evaluateFormula\`)。
    *   支持层级分组 (文件夹)。
    *   "独占模式" (Exclusive Mode, 显示并集 vs 交集)。

---

## 5. AI IDE 开发指南

当要求 AI 修改此代码库时，请遵循以下规则：

1.  **添加 Widget:**
    1.  确定 Widget 所属的领域 (trading, analysis, info, tools)。
    2.  在 \`components/widgets/[DOMAIN]/\` 下创建新的插件目录（例如 \`MyWidget/\`）。
    3.  创建组件文件 \`MyWidget.tsx\`。
    4.  在 \`pluginRegistry.tsx\` 中使用 \`lazy\` 导入它。
    5.  创建一个适配器组件 (例如 \`MyNewPluginComponent\`)，解构 \`WidgetContext\`。
    6.  将其添加到 \`REGISTERED_PLUGINS\`。

2.  **添加指标 (例如 ATR):**
    1.  修改 \`services/indicatorService.ts\`。
    2.  编写数学函数 \`calculateATR\`。
    3.  在 \`INDICATOR_REGISTRY\` 中添加定义，并配置 \`calculate: calculateATR\`。
    4.  *自动效果:* 它将立即出现在图表指标菜单、选股器过滤器和观察列表列中。

3.  **样式规则:**
    *   仅使用 **Tailwind CSS** 类。
    *   使用 \`dark:\` 前缀支持深色模式 (例如 \`bg-white dark:bg-slate-950\`)。
    *   结构色使用 \`slate\` (slate-50 到 slate-950)。
    *   操作色使用 \`indigo\` 或 \`primary\`。

4.  **数据获取:**
    *   使用 \`services/mockDataService.ts\` 进行数据模拟。
    *   使用 \`services/geminiService.ts\` 进行 LLM 调用。
    *   日期格式必须始终为 \`YYYY-MM-DD\` 以兼容图表库。

5.  **环境变量:**
    *   API Key 必须通过 \`process.env.API_KEY\` 访问。

---

## 6. UI 交互规范 (Interaction Rules)

1.  **层级管理 (Layering):**
    *   任何被**点击呼出**的菜单、弹窗、下拉列表或输入框（如重命名操作），必须确保处于页面的**最上层**。
    *   **实现方式:**
        *   首选使用 \`createPortal(content, document.body)\` 将元素挂载到 DOM 根部，避免被父容器的 \`overflow: hidden\` 裁剪。
        *   若使用绝对定位，必须显式设置极高的 \`z-index\` (例如 \`z-[100]\` 或 \`z-[9999]\`)，并确保其父级上下文没有限制。
    *   **禁止:** 使用系统原生 \`prompt()\` 进行交互，除非用于极其简单的调试。应使用自定义 Modal 或 Inline Input。

2.  **常见模式:**
    *   **重命名 (Inline Edit):** 点击编辑图标后，文本应直接替换为 \`<input autoFocus />\`，该输入框应覆盖原文本区域，并具有高层级阴影效果。
    *   **右键菜单:** 必须使用 \`fixed\` 定位并根据鼠标位置计算坐标，同时检查视口边界防止溢出。

3.  **公式评估:**
    观察列表中的自定义列使用 \`constants.ts\` -> \`evaluateFormula\` 中的安全 \`new Function()\` 评估。确保 \`price\` (价格), \`change\` (涨跌额), 和 \`volume\` (成交量) 变量在作用域内可用。

---

## 7. 重构策略 (避免上下文漂移)

随着文件变大（特别是 \`App.tsx\` 或复杂的 Widget），LLM 在处理长上下文时容易产生“注意力漂移”，导致修改功能 A 时意外破坏功能 B。

**解决方案：积极的组件拆分**

如果单个文件超过 **400 行**，必须进行重构。

**重构案例 (App.tsx):**
*   **问题:** \`App.tsx\` 同时处理布局状态、数据获取，并内联渲染了包含复杂拖拽逻辑的网格卡片。
*   **行动:**
    1.  将 \`LinkGroupSelector\` 提取到 \`components/LinkGroupSelector.tsx\`。
    2.  将 \`GridItem\` (卡片容器) 提取到 \`components/GridItem.tsx\`。
*   **结果:** \`App.tsx\` 现在仅专注于 *布局状态管理* 和 *工作区切换*。

**未来开发规则:**
1.  **隔离复杂度:** 如果一个 \`map()\` 函数渲染了超过 20 行 JSX，请将其提取为独立组件。
2.  **单一职责:** \`App.tsx\` 应只负责顶层协调。具体的 UI 逻辑（如调整大小的手柄、标题栏按钮）属于子组件。
3.  **文件大小限制:** 尽可能将文件保持在 300 行以内。
`;
export default {};
