
# GeminiQuant Plugin Development Reference

This document provides detailed technical specifications for each registered widget in the GeminiQuant platform. It is intended for developers extending the system or maintaining existing plugins.

## Architecture Overview

All plugins are registered in `pluginRegistry.tsx` and consumed via `App.tsx`.
They receive a unified `WidgetContext` object containing application state, data streams, and action handlers.

**Common Dependencies:**
*   `lucide-react`: For UI icons.
*   `WidgetContext`: The core interface defined in `types.ts`.
*   `Tailwind CSS`: For styling (using `slate` color scale and `dark:` modifiers).

---

## 1. StockChart (Price Chart)

**ID:** `CHART`  
**Path:** `components/StockChart.tsx`

### Functionality
A high-performance interactive financial chart powered by `lightweight-charts`. It renders candlestick data, volume overlays, and technical indicators. It includes a built-in drawing toolbar and indicator management menu.

### Build Conditions & Requirements

*   **Libraries:** `lightweight-charts` (Canvas-based rendering).
*   **Context Usage:**
    *   `settings`: Reads `theme` (light/dark) and `modules.chart` (up/down colors) for styling.
    *   `onHover`: Call this to broadcast the crosshair timestamp to other widgets.
    *   `sharedHoverLabel`: Listen to this to sync crosshair position (logic implemented via `subscribeCrosshairMove`).
*   **Internal State:**
    *   `activeIndicators`: Array of string IDs (e.g., `['sma20', 'vol']`). Managed locally but modified via the `command` prop.
    *   `drawings`: Array of local vector objects (Lines, Fibonacci, Text). Not persisted globally.

### Data Interface (Props)
The component expects an array of OHLCV data points sorted by date (ascending).

```typescript
// Prop: data
type StockData = StockDataPoint[];

interface StockDataPoint {
  date: string;   // ISO Format "YYYY-MM-DD"
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number; // Integer
  // Optional: Pre-calculated indicator values can be passed here
  // e.g., sma20: number;
}
```

---

## 2. Watchlist (Market Boards)

**ID:** `WATCHLIST`  
**Path:** `components/Watchlist.tsx`

### Functionality
A complex data grid supporting multi-column sorting, custom formula columns, grouping (by Sector), and drag-and-drop column reordering. It also supports "Saved Views" (shortcuts) at the bottom.

### Build Conditions & Requirements

*   **Config (`widgetConfig`):**
    *   `watchlistIds`: Array of strings. Determines which lists to aggregate and display.
    *   `exclusiveMode`: Boolean. If true, shows intersection of lists; otherwise, union.
*   **Features:**
    *   **Formula Evaluation:** Uses `new Function()` safely wrapped in `evaluateFormula` (constants.ts) to calculate custom columns like `price * volume`.
    *   **Drag & Drop:** Native HTML5 Drag API used for column headers.

### Data Interface (Props)
Consumes a list of `CustomWatchlist` objects.

```typescript
// Prop: availableWatchlists
type WatchlistData = CustomWatchlist[];

interface CustomWatchlist {
  id: string;     // Unique ID
  name: string;   // Display Name (supports grouping via "/", e.g. "US/Tech")
  readOnly?: boolean;
  stocks: WatchlistItem[];
}

interface WatchlistItem {
  symbol: string;
  name?: string;
  price: number;
  change: number;
  changePercent: number; // e.g., 1.5 for 1.5%
  vol: number | string;  // Can be raw number or formatted string "10M"
  sector?: string;       // Used for grouping
  sector_l1?: string;    // Level 1 Sector (optional)
  sector_l2?: string;    // Level 2 Sector (optional)
  pe?: number;           // P/E Ratio (optional)
  mkt_cap?: number;      // Market Cap (optional)
  trend?: number[];      // Array of numbers for sparkline chart
}
```

---

## 3. Screener (Strategy Builder)

**ID:** `SCREENER`  
**Path:** `components/widgets/Screener.tsx`

### Functionality
A visual query builder for filtering stocks based on technical and fundamental criteria. Supports nested logic groups (AND/OR), date range filtering, and ranking (weighted scoring).

### Build Conditions & Requirements

*   **UI Layout:** 3-Pane Layout (Library, Builder, Results). Uses manual resize handles.
*   **Execution Logic:**
    *   Filtering happens client-side in `runStrategy()` using `mockUniverse` or provided list data.
    *   **Performance:** Heavily dependent on `useCallback` for the `checkCondition` function to avoid re-renders during loop execution.

### Data Interface (Props)
Uses the same data structures as **Watchlist** for its source universe (`availableWatchlists`). Additionally, it manages saved strategies.

```typescript
// Prop: savedScreens
interface SavedScreen {
  id: string;
  name: string;
  groups: FilterGroup[]; // Logic definition
  rankingCriteria?: RankingCriterion[];
  createdAt: string;
}
```

---

## 4. AlertsWidget (Advanced Alerts)

**ID:** `ALERTS`  
**Path:** `components/widgets/AlertsWidget.tsx`

### Functionality
Simulates a real-time server-side alert system. It maintains a list of monitoring rules and generates a log stream when conditions are met.

### Build Conditions & Requirements

*   **State Management:**
    *   `rules`: Local state array of `AlertRule`.
    *   `logs`: Rolling array of triggered events (kept to last 100).
    *   `intervalRef`: Uses `window.setInterval` to simulate incoming signals.

### Data Interface (Props)
Uses `availableWatchlists` to pick random stocks for simulated trigger events.

---

## 5. BrowserWidget (Embedded Web)

**ID:** `BROWSER`  
**Path:** `components/BrowserWidget.tsx`

### Functionality
An `iframe` wrapper designed to show external financial data or news synced to the currently selected symbol.

### Build Conditions & Requirements

*   **Config (`widgetConfig`):**
    *   `urlTemplate`: String with placeholders (`xxxxxx` for symbol, `!!` for market, `##STOCKNAME##` for name).
    *   `isSyncEnabled`: Boolean. If true, URL updates when global symbol changes.

### Data Interface (Props)
Requires basic symbol context.

```typescript
// Context Props
symbol: string; // e.g. "NVDA"
profile: {
    name: string; // e.g. "NVIDIA Corp"
}
```

---

## 6. StarRadarWidget (Scatter Plot / RRG)

**ID:** `RADAR`  
**Path:** `components/StarRadarWidget.tsx`

### Functionality
A specialized scatter plot visualization tracking the history (trail) of stocks over time on two axes (e.g., Price Change vs Volume, or RS-Ratio vs RS-Momentum).

### Build Conditions & Requirements

*   **Libraries:** Custom SVG implementation.
*   **Data Transformation:**
    *   Requires fetching historical data (`getHistory`) for *every* stock in the selected watchlist.
    *   **Caching:** Implements an internal `historyCache` to prevent re-fetching data when switching axes.

### Data Interface (Props)
Expects `availableWatchlists` to define the universe. It then fetches `StockDataPoint[]` (same as StockChart) for each item.

---

## 7. TabContainerWidget (Multi-Tab)

**ID:** `TAB_CONTAINER`  
**Path:** `components/TabContainerWidget.tsx`

### Functionality
A recursive container that can host other widgets inside tabs. This allows for creating dense layouts (e.g., a "Fundamental" tab and a "News" tab in the same grid cell).

### Data Interface (Config)
Purely configuration-driven.

```typescript
// Config
interface TabContainerConfig {
    activeTabId: string;
    tabs: Array<{
        id: string;
        type: string; // Plugin ID (e.g., "CHART")
        title: string;
        config: any;  // Configuration passed to child
    }>;
}
```

---

## 8. AnalysisPanel (AI Insights)

**ID:** `ANALYSIS`  
**Path:** `components/AnalysisPanel.tsx`

### Functionality
Displays structured AI analysis results (Summary, Support/Resistance, Risks) generated by the Gemini model.

### Data Interface (Props)
Expects a structured analysis object, typically generated by an LLM.

```typescript
// Prop: analysis
interface AnalysisResult {
  symbol: string;
  summary: string; // 2-3 sentence overview
  technicalSignal: 'BUY' | 'SELL' | 'HOLD';
  confidenceScore: number; // 0-100
  keyLevels: {
    support: number[];    // e.g. [120.5, 118.0]
    resistance: number[]; // e.g. [135.0, 140.0]
  };
  risks: string[]; // ["High Volatility", "Earnings Risk"]
}
```

---

## 9. ChatInterface (AI Assistant)

**ID:** `CHAT`  
**Path:** `components/ChatInterface.tsx`

### Functionality
A conversational interface for querying market data via LLM.

### Data Interface
Internal state only (`messages` array). Interacts with `geminiService`.

---

## 10. TickerTape (Global Component)

**Path:** `components/TickerTape.tsx`

### Functionality
A scrolling marquee of market indices (S&P 500, Shanghai Composite, BTC).

### Data Interface
Internal list of indices.

```typescript
interface MarketIndex {
    id: string;
    name: string;
    value: number;
    change: number;
    changePercent: number;
}
```

---

## 11. QuoteDetail (Level 2 Data)

**ID:** `QUOTE`  
**Path:** `components/QuoteDetail.tsx`

### Functionality
Simulates Level 2 (Order Book) data showing Bid/Ask depth and detailed transaction stats.

### Data Interface (Props)
Requires two data objects.

```typescript
// Prop: profile
interface StockProfile {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  sector: string;
}

// Prop: fundamentals
interface FundamentalData {
  marketCap: string; // e.g. "2.0T"
  peRatio: string;
  eps: string;
  beta: string;
  divYield: string;
  high52: string;
  low52: string;
}
```

---

## 12. MarketNavigatorWidget (Directory)

**ID:** `MARKET_NAV`  
**Path:** `components/MarketNavigatorWidget.tsx`

### Functionality
A file-system-like explorer for all Watchlists and Boards.

### Data Interface
Consumes `availableWatchlists` (see Watchlist section).
