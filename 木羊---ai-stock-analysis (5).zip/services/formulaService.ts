
import { FormulaFile, BackendChartResponse } from '../types';

// Mock Data for demonstration if backend is offline
const MOCK_FORMULAS: FormulaFile[] = [
    { 
        id: 'f1', name: 'Dual MA Strategy', category: 'Trend', updatedAt: Date.now(), 
        code: `# Moving Average Crossover\nfast = MA(CLOSE, 10)\nslow = MA(CLOSE, 30)\n\nif CROSS(fast, slow):\n    BUY('Golden Cross')` 
    },
    { 
        id: 'f2', name: 'RSI Divergence', category: 'Oscillator', updatedAt: Date.now(), 
        code: `# RSI Logic\nrsi_val = RSI(CLOSE, 14)\n\nPLOT(rsi_val, color='purple', panel='bottom')` 
    }
];

class FormulaService {
    private baseUrl = 'http://localhost:8000/api'; // Adjust to your Python port

    // GET /api/formulas
    async getFormulas(): Promise<FormulaFile[]> {
        try {
            // In a real app, uncomment this:
            // const res = await fetch(`${this.baseUrl}/formulas`);
            // return await res.json();
            
            // Return Mock for UI dev
            return new Promise(resolve => setTimeout(() => resolve(MOCK_FORMULAS), 300));
        } catch (e) {
            console.error("Failed to fetch formulas", e);
            return [];
        }
    }

    // POST /api/save_and_calc
    async runSimulation(code: string, symbol: string): Promise<BackendChartResponse> {
        try {
            // const res = await fetch(`${this.baseUrl}/save_and_calc`, {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ code, symbol })
            // });
            // return await res.json();

            // --- MOCK RESPONSE GENERATOR (Simulating Python Backend) ---
            await new Promise(r => setTimeout(r, 800)); // Simulate calculation time
            
            // Randomly generate some lines based on the code content
            const isRsi = code.includes('RSI');
            const dataLength = 100;
            const now = new Date();
            
            const plots = [];
            const markers = [];
            
            // Helper to gen dates
            const dates = Array.from({length: dataLength}, (_, i) => {
                const d = new Date();
                d.setDate(now.getDate() - (dataLength - i));
                return d.toISOString().split('T')[0];
            });

            if (isRsi) {
                // Generate logic for RSI mock
                const rsiData = dates.map(d => ({ 
                    time: d, 
                    value: 50 + Math.sin(new Date(d).getTime()) * 30 + (Math.random() * 10) 
                }));
                plots.push({
                    id: 'rsi_line', name: 'RSI(14)', type: 'line' as const, color: '#a855f7', 
                    data: rsiData, panel: 'bottom' as const
                });
                // Overbought markers
                rsiData.forEach(p => {
                    if (p.value > 70) markers.push({ time: p.time, position: 'aboveBar' as const, shape: 'arrowDown' as const, color: 'red', text: 'OB' });
                });
            } else {
                // Generate logic for MA mock
                const ma10 = dates.map((d, i) => ({ time: d, value: 100 + i + Math.random() * 5 }));
                const ma30 = dates.map((d, i) => ({ time: d, value: 105 + (i * 0.8) }));
                
                plots.push({ id: 'ma10', name: 'MA(10)', type: 'line' as const, color: '#fbbf24', data: ma10, panel: 'main' as const });
                plots.push({ id: 'ma30', name: 'MA(30)', type: 'line' as const, color: '#3b82f6', data: ma30, panel: 'main' as const });
                
                // Random Buy Signal
                markers.push({ time: dates[dates.length-5], position: 'belowBar' as const, shape: 'arrowUp' as const, color: '#10b981', text: 'BUY', size: 2 });
            }

            return {
                plots,
                segments: [], // Pattern lines
                markers,
                logs: ["> System initialized", "> Loading data for " + symbol, "> Calculation complete (0.04s)"]
            };

        } catch (e) {
            return { plots: [], segments: [], markers: [], error: "Backend Connection Failed" };
        }
    }

    async saveFormula(id: string, code: string) {
        console.log(`Saving ${id}...`);
    }
}

export const formulaService = new FormulaService();
