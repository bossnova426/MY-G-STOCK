
import { IndicatorDefinition, IndicatorMetadata, IndicatorParams } from '../indicators/types';
import { StockDataPoint } from '../types';

// Static Imports for Core (Built-ins)
import { sma20, sma50 } from '../indicators/core/sma';
import { ema20 } from '../indicators/core/ema';
import { bollinger } from '../indicators/core/bollinger';
import { rsi } from '../indicators/core/rsi';
import { macd } from '../indicators/core/macd';
import { vol } from '../indicators/core/vol';
// Import Metadata Index (Now from TS file)
import { INDICATOR_INDEX } from '../indicators/metadata';

// --- Universal Remote Calculator ---
// This function handles ALL 'remote' type indicators.
// It sends the ID, Symbol, and Params to the backend (Python), which returns the calculated array.
const remoteCalculator = async (id: string, data: StockDataPoint[], params?: IndicatorParams): Promise<StockDataPoint[]> => {
    console.log(`[RemoteCalc] Requesting ${id} from backend...`);
    
    // Simulate Network Latency
    await new Promise(r => setTimeout(r, 600));

    // MOCK RESPONSE LOGIC (Replace with real fetch)
    // const response = await fetch(`/api/indicator/${id}`, { method: 'POST', body: JSON.stringify({ data, params }) });
    // return response.json();

    // Mocking return based on ID for demo purposes
    if (id === 'supertrend_pro') {
        return data.map((d, i) => ({
            ...d,
            supertrend_pro: i > 10 ? d.close * (1 - 0.05) : null // Mock trailing stop line
        }));
    }
    
    if (id === 'ms_pattern') {
        // Mock Pattern Logic
        return data.map((d, i) => {
            const res = { ...d };
            if (i > data.length - 20) res.ms_pattern_high = d.close * 1.05;
            if (i % 50 === 45) res._markers = [{ time: d.date, position: 'aboveBar', color: '#6366f1', shape: 'arrowDown', text: 'Cup' }];
            return res;
        });
    }

    // Default Fallback
    return data;
};

class IndicatorService {
    private cache: Map<string, IndicatorDefinition> = new Map();
    private index: IndicatorMetadata[] = [...INDICATOR_INDEX]; // Local copy to allow appending

    constructor() {
        // Pre-register core indicators for performance
        this.registerBuiltIn(sma20);
        this.registerBuiltIn(sma50);
        this.registerBuiltIn(ema20);
        this.registerBuiltIn(bollinger);
        this.registerBuiltIn(rsi);
        this.registerBuiltIn(macd);
        this.registerBuiltIn(vol);
        
        // Auto-fetch manifest on init
        this.fetchRemoteManifest();
    }

    private registerBuiltIn(def: IndicatorDefinition) {
        this.cache.set(def.id, def);
    }

    /**
     * Fetch all formulas from backend manifest and register them.
     */
    public async fetchRemoteManifest() {
        try {
            // const res = await fetch('/api/formula_system/manifest');
            // const manifest = await res.json();
            
            // Mock Manifest
            const manifest: any[] = [
                {
                    id: "remote_kdj",
                    name: "KDJ Stochastic",
                    shortName: "KDJ",
                    category: "Momentum/Oscillator",
                    source: "remote",
                    version: "1.0",
                    dataType: "number",
                    chartType: "oscillator",
                    outputDefs: [
                        { key: "k", label: "K Line", type: "line", defaultStyle: { color: "#ffffff", lineWidth: 1 } },
                        { key: "d", label: "D Line", type: "line", defaultStyle: { color: "#fbbf24", lineWidth: 1 } },
                        { key: "j", label: "J Line", type: "line", defaultStyle: { color: "#ec4899", lineWidth: 1 } }
                    ],
                    paramDefs: [
                        { key: "n", label: "Period", type: "number", default: 9, min: 1, max: 100 }
                    ]
                }
            ];

            // Merge into Index
            manifest.forEach(m => {
                if (!this.index.find(i => i.id === m.id)) {
                    this.index.push(m);
                }
            });
            console.log("Remote Manifest Loaded", manifest.length);
        } catch (e) {
            console.error("Failed to fetch remote manifest", e);
        }
    }

    /**
     * Get the full list of available indicators (Metadata only)
     * Used by the Indicator Manager UI.
     */
    public getIndex(): IndicatorMetadata[] {
        return this.index;
    }

    /**
     * Lazy load a specific indicator definition.
     * If it's remote, constructs a definition that points to the generic remote calculator.
     */
    public async getDefinition(id: string): Promise<IndicatorDefinition | undefined> {
        // 1. Check Cache (Built-ins and already loaded)
        if (this.cache.has(id)) {
            return this.cache.get(id);
        }

        // 2. Find in Index
        const meta = this.index.find(i => i.id === id);
        if (!meta) return undefined;

        // 3. Construct Definition based on Source
        let def: IndicatorDefinition;

        if (meta.source === 'remote') {
            // Construct a generic remote definition
            // The meta object from manifest already contains paramDefs and outputDefs
            // We just need to attach the calculator
            def = {
                ...meta,
                defaultStyle: meta['defaultStyle'] || { color: '#888888', lineWidth: 1 }, 
                calculate: (data, params) => remoteCalculator(id, data, params),
                isAsync: true
            };
        } else {
            // Should have been built-in, maybe missing import
            console.warn(`Indicator ${id} is marked as built-in but not registered.`);
            return undefined;
        }

        // 4. Cache and Return
        this.cache.set(id, def);
        return def;
    }

    // Facade for backward compatibility
    public getIndicatorById(id: string) {
        return this.cache.get(id); // Only works for synchronously loaded ones
    }
}

export const indicatorService = new IndicatorService();
export const INDICATOR_REGISTRY = indicatorService.getIndex(); // Export index for simple lists
export const getIndicatorById = (id: string) => indicatorService.getIndicatorById(id);
export const loadIndicator = (id: string) => indicatorService.getDefinition(id);
