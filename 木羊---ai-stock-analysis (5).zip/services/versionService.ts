
import { AppState, VersionCheckpoint } from '../types';

const STORAGE_KEY = 'gq_version_history';
const MAX_AUTO_SAVES = 10;
const MAX_MANUAL_SAVES = 20;

class VersionService {
    private history: VersionCheckpoint[] = [];

    constructor() {
        this.loadHistory();
    }

    private loadHistory() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);
            this.history = saved ? JSON.parse(saved) : [];
        } catch (e) {
            console.error("Failed to load version history", e);
            this.history = [];
        }
    }

    private pruneHistory(limitAuto: number, limitManual: number) {
        const autoSaves = this.history.filter(v => v.type === 'AUTO').sort((a, b) => b.timestamp - a.timestamp);
        const manualSaves = this.history.filter(v => v.type === 'MANUAL').sort((a, b) => b.timestamp - a.timestamp);

        const keepAuto = autoSaves.slice(0, limitAuto);
        const keepManual = manualSaves.slice(0, limitManual);

        this.history = [...keepAuto, ...keepManual].sort((a, b) => b.timestamp - a.timestamp);
    }

    private saveHistory() {
        try {
            // Standard Pruning
            this.pruneHistory(MAX_AUTO_SAVES, MAX_MANUAL_SAVES);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(this.history));
        } catch (e: any) {
            if (this.isQuotaExceeded(e)) {
                console.warn("LocalStorage quota exceeded. Attempting aggressive pruning...");
                
                // Aggressive Pruning: Reduce to very recent
                try {
                    // Keep only 2 auto saves and 3 manual saves
                    this.pruneHistory(2, 3);
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.history));
                    console.log("Saved with aggressive pruning.");
                } catch (retryErr) {
                    if (this.isQuotaExceeded(retryErr)) {
                        // Emergency Pruning: Keep only latest 1 item total
                        console.warn("Quota still exceeded. Emergency pruning.");
                        this.history = this.history.slice(0, 1);
                        try {
                            localStorage.setItem(STORAGE_KEY, JSON.stringify(this.history));
                        } catch (finalErr) {
                            console.error("Critical: Unable to save history even with single item.", finalErr);
                        }
                    }
                }
            } else {
                console.error("Failed to save version history", e);
            }
        }
    }

    private isQuotaExceeded(e: any) {
        return (
            e instanceof DOMException &&
            (e.code === 22 ||
             e.code === 1014 ||
             e.name === 'QuotaExceededError' ||
             e.name === 'NS_ERROR_DOM_QUOTA_REACHED')
        );
    }

    getHistory(): VersionCheckpoint[] {
        return this.history;
    }

    createCheckpoint(type: 'AUTO' | 'MANUAL', label: string, data: AppState, description?: string): VersionCheckpoint {
        const checkpoint: VersionCheckpoint = {
            id: `v-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            type,
            label,
            data,
            description
        };

        this.history.unshift(checkpoint);
        this.saveHistory();
        return checkpoint;
    }

    deleteCheckpoint(id: string) {
        this.history = this.history.filter(v => v.id !== id);
        this.saveHistory();
    }

    clearAll() {
        this.history = [];
        this.saveHistory();
    }
}

export const versionService = new VersionService();
