
import { StockDataPoint, StockProfile, FundamentalData, NewsItem, DataSettings, CustomWatchlist } from '../types';
import { generateStockData, generateStockNews, generateFundamentals } from './mockDataService';
import { MOCK_WATCHLISTS } from '../constants';

// --- Architecture for Real-time Data ---

export interface DataProvider {
    // 1. Core Market Data
    getQuote(symbol: string): Promise<StockProfile>;
    getHistory(symbol: string, days: number): Promise<StockDataPoint[]>;
    
    // 2. Auxiliary Data
    getFundamentals(symbol: string): Promise<FundamentalData>;
    getNews(symbol: string): Promise<NewsItem[]>;
    
    // 3. System Data
    getWatchlists(): Promise<CustomWatchlist[]>;
    
    // 4. Search
    searchSymbols(query: string): Promise<StockProfile[]>;
}

// --- Implementation A: Mock Service (Client-side Simulation) ---
class MockDataProvider implements DataProvider {
    async getQuote(symbol: string): Promise<StockProfile> {
        const data = generateStockData(symbol, 1);
        const last = data[0];
        return {
            symbol,
            name: `${symbol} Corp`,
            price: last.close,
            change: last.close - last.open, 
            changePercent: ((last.close - last.open) / last.open) * 100,
            sector: 'Technology',
            vol: (last.volume / 1000000).toFixed(2) + 'M', // Return string for UI
            volume: last.volume // Return raw number for sorting/calculations
        };
    }

    async getHistory(symbol: string, days: number): Promise<StockDataPoint[]> {
        return generateStockData(symbol, days);
    }

    async getFundamentals(symbol: string): Promise<FundamentalData> {
        return generateFundamentals(symbol, 100); 
    }

    async getNews(symbol: string): Promise<NewsItem[]> {
        return generateStockNews(symbol);
    }

    async getWatchlists(): Promise<CustomWatchlist[]> {
        // Return default mocks wrapped as CustomWatchlist
        return Object.entries(MOCK_WATCHLISTS).map(([id, stocks]) => ({
            id,
            name: id.charAt(0).toUpperCase() + id.slice(1),
            stocks,
            readOnly: true
        }));
    }

    async searchSymbols(query: string): Promise<StockProfile[]> {
        const q = query.toUpperCase();
        const allStocks = Object.values(MOCK_WATCHLISTS).flat();
        const seen = new Set<string>();
        
        return allStocks.filter(s => {
            if (seen.has(s.symbol)) return false;
            seen.add(s.symbol);
            return s.symbol.includes(q) || s.name.toUpperCase().includes(q);
        });
    }
}

// --- Implementation B: KiteTDX Adapter (Python Backend) ---
class KiteTdxDataProvider implements DataProvider {
    private baseUrl: string;

    constructor(baseUrl: string) {
        this.baseUrl = baseUrl.replace(/\/$/, ""); 
    }

    private async fetchJson(endpoint: string) {
        try {
            const res = await fetch(`${this.baseUrl}${endpoint}`);
            if (!res.ok) throw new Error(`API Error: ${res.statusText}`);
            return await res.json();
        } catch (error) {
            // Suppress explicit error logging to avoid console noise when offline
            // The calling method will handle the fallback to mock data
            throw error;
        }
    }

    async getQuote(symbol: string): Promise<StockProfile> {
        try {
            // Expects backend: GET /api/quote?symbol=600036
            const data = await this.fetchJson(`/api/quote?symbol=${symbol}`);
            return {
                symbol: data.symbol,
                name: data.name || symbol, 
                price: data.price,
                change: data.change,
                changePercent: data.changePercent,
                sector: data.sector || 'Unknown',
                vol: data.volume ? (data.volume / 1000000).toFixed(2) + 'M' : undefined,
                volume: data.volume || 0
            };
        } catch (e) {
            console.warn(`Failed to fetch quote for ${symbol} from server, falling back to mock.`);
            return new MockDataProvider().getQuote(symbol);
        }
    }

    async getHistory(symbol: string, days: number): Promise<StockDataPoint[]> {
        try {
            // Expects backend: GET /api/history?symbol=600036&days=100
            const data = await this.fetchJson(`/api/history?symbol=${symbol}&days=${days}`);
            if (!Array.isArray(data) || data.length === 0) {
                return new MockDataProvider().getHistory(symbol, days);
            }
            return data.map((d: any) => ({
                date: d.date,
                open: d.open,
                high: d.high,
                low: d.low,
                close: d.close,
                price: d.close, 
                volume: d.volume
            }));
        } catch (e) {
            return new MockDataProvider().getHistory(symbol, days);
        }
    }

    async getWatchlists(): Promise<CustomWatchlist[]> {
        try {
            // Fetch System Data (Markets & Blocks)
            // Expects backend: GET /api/sys_data
            const lists = await this.fetchJson(`/api/sys_data`);
            if (Array.isArray(lists) && lists.length > 0) {
                return lists;
            }
            return new MockDataProvider().getWatchlists();
        } catch (e) {
            console.warn("Failed to load TDX system data, using mock.");
            return new MockDataProvider().getWatchlists();
        }
    }

    async getFundamentals(symbol: string): Promise<FundamentalData> {
        return new MockDataProvider().getFundamentals(symbol);
    }

    async getNews(symbol: string): Promise<NewsItem[]> {
        return new MockDataProvider().getNews(symbol);
    }

    async searchSymbols(query: string): Promise<StockProfile[]> {
        try {
            // Expects backend: GET /api/search_stocks?query=600
            const data = await this.fetchJson(`/api/search_stocks?query=${query}`);
            if (Array.isArray(data)) {
                return data.map((d: any) => ({
                    symbol: d.symbol,
                    name: d.name,
                    price: 0,
                    change: 0,
                    changePercent: 0,
                    sector: 'Search Result'
                }));
            }
            return [];
        } catch (e) {
            return [];
        }
    }
}

// --- Dynamic Data Service Wrapper ---
class DynamicDataService implements DataProvider {
    private provider: DataProvider;

    constructor() {
        this.provider = new MockDataProvider();
    }

    configure(settings: DataSettings) {
        if (settings.provider === 'mock') {
            this.provider = new MockDataProvider();
            console.log("Data Service: Switched to Mock");
        } else if (settings.provider === 'kitetdx' || settings.provider === 'rest_api') {
            this.provider = new KiteTdxDataProvider(settings.apiBaseUrl);
            console.log(`Data Service: Switched to KiteTDX/REST (${settings.apiBaseUrl})`);
        }
    }

    getQuote(symbol: string) { return this.provider.getQuote(symbol); }
    getHistory(symbol: string, days: number) { return this.provider.getHistory(symbol, days); }
    getFundamentals(symbol: string) { return this.provider.getFundamentals(symbol); }
    getNews(symbol: string) { return this.provider.getNews(symbol); }
    getWatchlists() { return this.provider.getWatchlists(); }
    searchSymbols(query: string) { return this.provider.searchSymbols(query); }
}

export const dataService = new DynamicDataService();
