
type EventHandler = (payload: any) => void;

class EventBus {
    private listeners: Map<string, Set<EventHandler>> = new Map();

    /**
     * Subscribe to an event topic.
     * Returns an unsubscribe function.
     */
    on(topic: string, handler: EventHandler): () => void {
        if (!this.listeners.has(topic)) {
            this.listeners.set(topic, new Set());
        }
        this.listeners.get(topic)!.add(handler);

        return () => {
            const handlers = this.listeners.get(topic);
            if (handlers) {
                handlers.delete(handler);
            }
        };
    }

    /**
     * Publish an event to a topic.
     */
    emit(topic: string, payload?: any) {
        const handlers = this.listeners.get(topic);
        if (handlers) {
            handlers.forEach(handler => {
                try {
                    handler(payload);
                } catch (e) {
                    console.error(`Error in EventBus handler for topic "${topic}":`, e);
                }
            });
        }
    }

    /**
     * Clear all listeners (useful for resets).
     */
    clear() {
        this.listeners.clear();
    }
}

// Export a singleton instance
export const eventBus = new EventBus();

// Define standard event topics for type safety guidance
export const EVENTS = {
    STOCK_SELECTED: 'stock:selected',
    TIMEFRAME_CHANGED: 'chart:timeframe_changed',
    INDICATOR_ADDED: 'chart:indicator_added',
    GLOBAL_REFRESH: 'system:refresh'
};
