
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { StockDataPoint, AnalysisResult, NewsItem } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const MAX_RETRIES = 3;
const BASE_DELAY = 2000; // Start with 2s delay

async function retryWithBackoff<T>(fn: () => Promise<T>, retries = MAX_RETRIES, delay = BASE_DELAY): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    // Improved error parsing to handle nested Google API error structures
    // The error might be { error: { code: 429, ... } } or just { status: 429 }
    const status = error.status || 
                   error.response?.status || 
                   error.code || 
                   error.error?.code || 
                   error.error?.status;
                   
    const message = (error.message || error.error?.message || '').toString().toLowerCase();

    // Check for specific conditions to retry
    const isRateLimit = status === 429 || 
                        status === 'RESOURCE_EXHAUSTED' || 
                        message.includes('429') || 
                        message.includes('quota');
                        
    const isServerOverload = (typeof status === 'number' && status >= 500) ||
                             status === 'UNKNOWN' || // Often maps to 500/Transport errors
                             status === 'INTERNAL';

    const isTransportError = message.includes('rpc failed') || 
                             message.includes('xhr error') || 
                             message.includes('fetch failed');

    if (retries > 0 && (isRateLimit || isServerOverload || isTransportError)) {
      console.warn(`Gemini API Error (${status || 'Unknown'}). Retrying in ${delay}ms... (${retries} attempts left)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryWithBackoff(fn, retries - 1, delay * 2);
    } else {
      throw error;
    }
  }
}

export const analyzeStockData = async (
  symbol: string,
  data: StockDataPoint[],
  news: NewsItem[]
): Promise<AnalysisResult> => {
  
  // Prepare concise context for the model
  const recentData = data.slice(-14); // Last 14 days
  const dataSummary = recentData.map(d => 
    `${d.date}: Close ${d.close.toFixed(2)}, Vol ${d.volume}`
  ).join('\n');

  const newsSummary = news.map(n => `- ${n.title} (${n.source})`).join('\n');

  const prompt = `
    You are a senior financial analyst. Analyze the following data for stock ticker ${symbol}.
    
    Recent Price History (Last 14 candles):
    ${dataSummary}

    Recent News Headlines:
    ${newsSummary}

    Provide a structured technical and sentimental analysis. 
    Identify key support and resistance levels based on the price data provided.
    Determine a 'BUY', 'SELL', or 'HOLD' signal based on momentum and news sentiment.
    List potential risks.
  `;

  try {
    const response = await retryWithBackoff<GenerateContentResponse>(() => ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            symbol: { type: Type.STRING },
            summary: { type: Type.STRING, description: "A 2-3 sentence executive summary of the stock's current setup." },
            technicalSignal: { type: Type.STRING, enum: ['BUY', 'SELL', 'HOLD'] },
            confidenceScore: { type: Type.NUMBER, description: "Confidence in the signal from 0 to 100" },
            keyLevels: {
              type: Type.OBJECT,
              properties: {
                support: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                resistance: { type: Type.ARRAY, items: { type: Type.NUMBER } }
              }
            },
            risks: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    }));

    if (response.text) {
      return JSON.parse(response.text) as AnalysisResult;
    }
    throw new Error("No response from Gemini");

  } catch (error: any) {
    const status = error.status || error.code || error.error?.code || error.error?.status;
    const isQuota = status === 429 || status === 'RESOURCE_EXHAUSTED';

    if (!isQuota) {
        console.error("Gemini Analysis Error:", error);
    } else {
        console.warn("Gemini API Quota Exceeded. Switching to simulated analysis.");
    }
    
    let errorSummary = "Unable to generate real-time analysis.";
    if (isQuota) {
        errorSummary = "API Quota Exceeded. Displaying simulated analysis based on technicals.";
    } else {
        errorSummary = "Service unavailable. Displaying technical fallback.";
    }

    // Fallback Calculation for "Offline Mode"
    // We generate a plausible analysis based on the actual price data provided to keep the UI useful.
    const lastPrice = data.length > 0 ? data[data.length - 1].close : 100;
    const prevPrice = data.length > 5 ? data[data.length - 6].close : lastPrice; // 5 day lookback
    const isBullish = lastPrice > prevPrice;
    
    // Simple support/resistance calculation
    const support = parseFloat((lastPrice * 0.95).toFixed(2));
    const resistance = parseFloat((lastPrice * 1.05).toFixed(2));

    return {
      symbol,
      summary: errorSummary + (isBullish 
        ? " Price action shows short-term bullish momentum relative to the weekly open." 
        : " Price action suggests consolidation with downward pressure."),
      technicalSignal: isBullish ? 'BUY' : 'HOLD',
      confidenceScore: Math.floor(Math.random() * 20) + 60, // Mock confidence
      keyLevels: {
        support: [support, parseFloat((support * 0.95).toFixed(2))],
        resistance: [resistance, parseFloat((resistance * 1.05).toFixed(2))]
      },
      risks: ["Market Volatility (Simulated)", "Sector Rotation (Simulated)"]
    };
  }
};

export const chatWithAnalyst = async (history: {role: string, content: string}[], newMessage: string) => {
    try {
        const response = await retryWithBackoff<GenerateContentResponse>(() => ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Context: User is looking at a stock dashboard.
            History: ${JSON.stringify(history)}
            User Question: ${newMessage}
            
            Answer briefly and professionally as a stock trader.`
        }));
        return response.text;
    } catch (e: any) {
        console.warn("Chat API Error:", e.message || e);
        const status = e.status || e.code || e.error?.code || e.error?.status;
        if (status === 429 || status === 'RESOURCE_EXHAUSTED') {
            return "I'm currently receiving too many requests (Quota Exceeded). Please try again later.";
        }
        return "I'm having trouble connecting to the market data server right now. Please try again.";
    }
}
