import { StockDataPoint, FundamentalData, NewsItem } from '../types';

// Helper functions to replace date-fns
const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0]; // YYYY-MM-DD for TradingView charts
};

const subDays = (date: Date, days: number): Date => {
  const result = new Date(date);
  result.setDate(result.getDate() - days);
  return result;
};

const addDays = (date: Date, days: number): Date => {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
};

export const generateStockData = (symbol: string, days: number = 90): StockDataPoint[] => {
  const data: StockDataPoint[] = [];
  // Deterministic starting price based on symbol char codes
  let seed = symbol.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  let currentPrice = (seed % 500) + 50; 
  
  const random = () => {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  };

  for (let i = days; i >= 0; i--) {
    const date = subDays(new Date(), i);
    // Random walk
    const change = (random() - 0.5) * (currentPrice * 0.05); 
    const open = currentPrice;
    const close = currentPrice + change;
    const high = Math.max(open, close) + random() * (currentPrice * 0.02);
    const low = Math.min(open, close) - random() * (currentPrice * 0.02);
    const volume = Math.floor(random() * 1000000) + 500000;

    data.push({
      date: formatDate(date),
      price: close,
      open,
      high,
      low,
      close,
      volume
    });

    currentPrice = close;
  }
  return data;
};

export const generateFundamentals = (symbol: string, currentPrice: number): FundamentalData => {
    // Generate pseudo-realistic stats based on symbol
    const randomVal = (min: number, max: number, decimals: number = 2) => {
        const seed = symbol.length + currentPrice; // Simple seed
        const rand = (Math.sin(seed) + 1) / 2; // 0-1
        return (min + (rand * (max - min))).toFixed(decimals);
    };

    const mktCapB = (currentPrice * 0.5 + 10).toFixed(2);
    
    return {
        marketCap: `${mktCapB}B`,
        peRatio: randomVal(10, 80),
        eps: randomVal(1, 15),
        beta: randomVal(0.8, 2.5),
        divYield: (Math.random() * 3).toFixed(2) + '%',
        nextEarnings: formatDate(addDays(new Date(), Math.floor(Math.random() * 60) + 10)),
        high52: (currentPrice * 1.2).toFixed(2),
        low52: (currentPrice * 0.7).toFixed(2)
    };
};

export const generateStockNews = (symbol: string): NewsItem[] => {
    const sources = ['Bloomberg', 'Reuters', 'MarketWatch', 'CNBC', 'Yahoo Finance'];
    const sentiments: ('positive' | 'neutral' | 'negative')[] = ['positive', 'neutral', 'negative'];
    
    const templates = [
        `Analysts upgrade ${symbol} target price following strong quarterly results`,
        `${symbol} announces new strategic partnership to expand AI capabilities`,
        `Market volatility impacts ${symbol} as sector faces headwinds`,
        `Why ${symbol} is moving higher today: Key takeaways`,
        `Insider trading report: CEO sells block of ${symbol} shares`,
        `${symbol} unveils next-generation product line at tech summit`,
        `Regulatory concerns loom over ${symbol}'s latest acquisition`,
        `Investor sentiment shifts for ${symbol} ahead of earnings call`
    ];

    // Pick 3-5 random news items
    const count = 3 + Math.floor(Math.random() * 3);
    const news: NewsItem[] = [];

    for(let i=0; i<count; i++) {
        const templateIdx = Math.floor(Math.random() * templates.length);
        const sourceIdx = Math.floor(Math.random() * sources.length);
        const sentIdx = Math.floor(Math.random() * sentiments.length);
        
        news.push({
            id: `news-${symbol}-${i}`,
            title: templates[templateIdx],
            source: sources[sourceIdx],
            time: `${Math.floor(Math.random() * 24) + 1}h ago`,
            sentiment: sentiments[sentIdx],
            url: '#'
        });
    }

    return news;
};