
import React, { Suspense, lazy } from 'react';
import { 
  BarChart2, List, Zap, MessageSquare, Newspaper, PieChart, 
  Grid, Crosshair, Table2, FolderTree, Network, Radar, Compass, FileText, BarChartHorizontal, PanelTop, Globe, Monitor, Filter, Bell, AlignCenter, LayoutGrid, Library, FileCode, Loader2
} from 'lucide-react';
import { WidgetPlugin, WidgetContext } from './types';

// --- Loading Component ---
const WidgetLoader = () => (
    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900/50 text-slate-400">
        <Loader2 className="w-6 h-6 animate-spin mb-2" />
        <span className="text-[10px] uppercase font-bold tracking-wider">Loading Widget...</span>
    </div>
);

// --- Lazy Load Helper ---
const withSuspense = (LazyComponent: React.LazyExoticComponent<any>) => {
    return (props: WidgetContext) => (
        <Suspense fallback={<WidgetLoader />}>
            <LazyComponent {...(props as any)} />
        </Suspense>
    );
};

// ============================================================================
// DOMAIN: TRADING (Charts, Quotes, Execution)
// ============================================================================

const StockChart = lazy(() => import('./components/widgets/trading/StockChart/StockChart').then(m => ({ default: m.StockChart })));
const ChartPluginComponent: React.FC<WidgetContext> = (props) => {
    return (
        <Suspense fallback={<WidgetLoader />}>
             <StockChart 
                data={props.chartData}
                symbol={props.symbol}
                settings={props.settings}
                sharedHoverLabel={props.sharedHoverLabel}
                onHover={props.setSharedHoverLabel}
                customColumns={props.customColumns}
                command={props.command}
             />
        </Suspense>
    );
};

const QuoteDetail = lazy(() => import('./components/widgets/trading/QuoteDetail/QuoteDetail').then(m => ({ default: m.QuoteDetail })));
const TransactionList = lazy(() => import('./components/widgets/trading/TransactionList/TransactionList').then(m => ({ default: m.TransactionList })));
const PriceVolumeDistribution = lazy(() => import('./components/widgets/trading/PriceVolumeDistribution/PriceVolumeDistribution').then(m => ({ default: m.PriceVolumeDistribution })));

// ============================================================================
// DOMAIN: ANALYSIS (AI, Technicals, Fundamentals)
// ============================================================================

const AnalysisPanel = lazy(() => import('./components/widgets/analysis/AnalysisPanel/AnalysisPanel').then(m => ({ default: m.AnalysisPanel })));
const AnalysisPluginComponent: React.FC<WidgetContext> = (props) => (
    <Suspense fallback={<WidgetLoader />}>
        <AnalysisPanel 
            analysis={props.analysis}
            loading={props.loadingAnalysis}
            onRefresh={props.onRefreshData}
            settings={props.settings}
        />
    </Suspense>
);

const StatsTable = lazy(() => import('./components/widgets/analysis/StatsTable/StatsTable').then(m => ({ default: m.StatsTable })));
const StatsPluginComponent: React.FC<WidgetContext> = (props) => (
    <Suspense fallback={<WidgetLoader />}>
        <StatsTable 
            data={props.fundamentals}
            settings={props.settings}
        />
    </Suspense>
);

const PointFigureChart = lazy(() => import('./components/widgets/analysis/PointFigureChart/PointFigureChart').then(m => ({ default: m.PointFigureChart })));
const PointFigurePluginComponent: React.FC<WidgetContext> = (props) => (
    <Suspense fallback={<WidgetLoader />}>
        <PointFigureChart 
            data={props.chartData}
            boxSize={props.widgetConfig?.boxSize}
            reversal={props.widgetConfig?.reversal}
        />
    </Suspense>
);

const RRGChart = lazy(() => import('./components/widgets/analysis/RRGChart/RRGChart').then(m => ({ default: m.RRGChart })));
const RRGPluginComponent: React.FC<WidgetContext> = (props) => (
    <Suspense fallback={<WidgetLoader />}>
        <RRGChart 
            data={props.activeList || []} 
        />
    </Suspense>
);

const StarRadarWidget = lazy(() => import('./components/widgets/analysis/StarRadarWidget/StarRadarWidget').then(m => ({ default: m.StarRadarWidget })));
const IndustryChainWidget = lazy(() => import('./components/widgets/analysis/IndustryChainWidget/IndustryChainWidget').then(m => ({ default: m.IndustryChainWidget })));
const MultiChartWidget = lazy(() => import('./components/widgets/analysis/MultiChartWidget/MultiChartWidget').then(m => ({ default: m.MultiChartWidget })));

// ============================================================================
// DOMAIN: INFORMATION (News, Web)
// ============================================================================

const NewsFeed = lazy(() => import('./components/widgets/info/NewsFeed/NewsFeed').then(m => ({ default: m.NewsFeed })));
const BrowserWidget = lazy(() => import('./components/widgets/info/BrowserWidget/BrowserWidget').then(m => ({ default: m.BrowserWidget })));
const ChatInterface = lazy(() => import('./components/widgets/info/ChatInterface/ChatInterface').then(m => ({ default: m.ChatInterface })));

// ============================================================================
// DOMAIN: TOOLS & MANAGEMENT
// ============================================================================

const Watchlist = lazy(() => import('./components/widgets/tools/Watchlist/Watchlist').then(m => ({ default: m.Watchlist })));
const WatchlistPluginComponent: React.FC<WidgetContext> = (props) => {
    const config = props.widgetConfig || {};
    return (
        <Suspense fallback={<WidgetLoader />}>
            <Watchlist 
                availableLists={props.availableWatchlists}
                selectedListIds={config.watchlistIds || ['default']}
                onSelectionChange={(ids) => props.onUpdateConfig({ watchlistIds: ids })}
                exclusiveMode={config.exclusiveMode || false}
                onToggleExclusiveMode={(val) => props.onUpdateConfig({ exclusiveMode: val })}
                customColumns={props.customColumns}
                onAddCustomColumn={props.onAddCustomColumn}
                onRemoveCustomColumn={props.onRemoveCustomColumn}
                onSymbolSelect={props.onSymbolSelect}
                onAddStockToWatchlists={props.onAddStockToWatchlists}
                onRemoveStockFromWatchlist={props.onRemoveStockFromWatchlist}
                onAddWatchlist={props.onAddWatchlist}
                onRenameWatchlist={props.onRenameWatchlist}
                onDeleteWatchlist={props.onDeleteWatchlist}
                onUpdateWatchlist={props.onUpdateWatchlist}
                settings={props.settings}
                currentSymbol={props.symbol}
                onOpenScreener={props.onOpenScreener}
                onBroadcastList={props.onBroadcastList}
            />
        </Suspense>
    );
};

const IndicatorTreeWidget = lazy(() => import('./components/widgets/tools/IndicatorTreeWidget/IndicatorTreeWidget').then(m => ({ default: m.IndicatorTreeWidget })));
const ListTreeWidget = lazy(() => import('./components/widgets/tools/ListTreeWidget/ListTreeWidget').then(m => ({ default: m.ListTreeWidget })));
const MarketNavigatorWidget = lazy(() => import('./components/widgets/tools/MarketNavigatorWidget/MarketNavigatorWidget').then(m => ({ default: m.MarketNavigatorWidget })));
const TabContainerWidget = lazy(() => import('./components/widgets/tools/TabContainerWidget/TabContainerWidget').then(m => ({ default: m.TabContainerWidget })));
const WorkspaceManagerWidget = lazy(() => import('./components/widgets/tools/WorkspaceManagerWidget/WorkspaceManagerWidget').then(m => ({ default: m.WorkspaceManagerWidget })));
const ScreenerWidget = lazy(() => import('./components/widgets/tools/Screener/ScreenerWidget').then(m => ({ default: m.ScreenerWidget })));
const AlertsWidget = lazy(() => import('./components/widgets/tools/AlertsWidget/AlertsWidget').then(m => ({ default: m.AlertsWidget })));
const IndicatorManagerWidget = lazy(() => import('./components/widgets/tools/IndicatorManagerWidget/IndicatorManagerWidget').then(m => ({ default: m.IndicatorManagerWidget })));
const FormulaEditorWidget = lazy(() => import('./components/widgets/tools/FormulaEditor/FormulaEditorWidget').then(m => ({ default: m.FormulaEditorWidget })));


// ============================================================================
// PLUGIN REGISTRY
// ============================================================================

export const REGISTERED_PLUGINS: Record<string, WidgetPlugin> = {
    // --- TOOLS ---
    'FORMULA_EDITOR': {
        id: 'FORMULA_EDITOR',
        title: 'Python Editor',
        description: 'Edit & Backtest Formulas',
        icon: FileCode,
        defaultLayout: { w: 12, h: 10 },
        component: withSuspense(FormulaEditorWidget),
        documentation: '# Formula Editor\n\nWrite Python/Pandas logic to create custom indicators.'
    },
    'INDICATOR_MGR': {
        id: 'INDICATOR_MGR',
        title: 'Formula Manager',
        description: 'Search & Manage 1000+ Indicators',
        icon: Library,
        defaultLayout: { w: 6, h: 8 },
        component: withSuspense(IndicatorManagerWidget),
        documentation: '# Formula Manager\n\nManage and search through the extensive library of technical indicators.'
    },
    'WS_MANAGER': {
        id: 'WS_MANAGER',
        title: 'Workspace Manager',
        description: 'Create, Switch and Manage Tabs',
        icon: Monitor,
        defaultLayout: { w: 3, h: 8 },
        component: withSuspense(WorkspaceManagerWidget),
        documentation: '# Workspace Manager...'
    },
    'SCREENER': {
        id: 'SCREENER',
        title: 'Strategy Screener',
        description: 'Advanced Filter & Ranking',
        icon: Filter,
        defaultLayout: { w: 12, h: 10 },
        component: withSuspense(ScreenerWidget),
        documentation: '# Strategy Screener Widget...'
    },
    'ALERTS': {
        id: 'ALERTS',
        title: 'Advanced Alerts',
        description: 'Real-time Condition Monitoring',
        icon: Bell,
        defaultLayout: { w: 8, h: 10 },
        component: withSuspense(AlertsWidget),
        documentation: `# Advanced Alerts Widget...`
    },
    'TAB_CONTAINER': {
        id: 'TAB_CONTAINER',
        title: 'Multi-Tab Container',
        description: 'Group multiple widgets in tabs',
        icon: PanelTop,
        defaultLayout: { w: 6, h: 8 },
        component: withSuspense(TabContainerWidget),
        defaultConfig: { tabs: [], activeTabId: '' },
        documentation: `# Tab Container...`
    },
    'IND_TREE': {
        id: 'IND_TREE',
        title: 'Indicator Tree',
        description: 'Manage Technical Indicators',
        icon: Network,
        defaultLayout: { w: 3, h: 8 },
        component: withSuspense(IndicatorTreeWidget),
        documentation: `# Indicator Tree...`
    },
    'LIST_TREE': {
        id: 'LIST_TREE',
        title: 'Board Manager',
        description: 'Manage Watchlists & Folders',
        icon: FolderTree,
        defaultLayout: { w: 3, h: 8 },
        component: withSuspense(ListTreeWidget),
        documentation: `# Board Manager...`
    },
    'MARKET_NAV': {
        id: 'MARKET_NAV',
        title: 'Market Navigator',
        description: 'Boards & Sectors Directory',
        icon: Compass,
        defaultLayout: { w: 4, h: 10 },
        component: withSuspense(MarketNavigatorWidget),
        documentation: `# Market Navigator...`
    },

    // --- INFORMATION ---
    'BROWSER': {
        id: 'BROWSER',
        title: 'Browser',
        description: 'Embedded Web Page',
        icon: Globe,
        defaultLayout: { w: 6, h: 8 },
        component: withSuspense(BrowserWidget),
        documentation: `# Browser Widget...`
    },
    'CHAT': {
        id: 'CHAT',
        title: 'AI Assistant',
        description: 'Chat with market data',
        icon: MessageSquare,
        defaultLayout: { w: 4, h: 8 },
        component: withSuspense(ChatInterface),
        documentation: `# AI Assistant Widget...`
    },
    'NEWS': {
        id: 'NEWS',
        title: 'News Feed',
        description: 'Latest market headlines',
        icon: Newspaper,
        defaultLayout: { w: 4, h: 6 },
        component: withSuspense(NewsFeed),
        documentation: `# News Feed Widget...`
    },

    // --- TRADING ---
    'CHART': {
        id: 'CHART',
        title: 'Price Chart',
        description: 'Interactive technical chart',
        icon: BarChart2,
        defaultLayout: { w: 8, h: 8 },
        component: ChartPluginComponent, 
        documentation: `# Price Chart Widget...`
    },
    'WATCHLIST': {
        id: 'WATCHLIST',
        title: 'Watchlist',
        description: 'Track multiple tickers',
        icon: List,
        defaultLayout: { w: 4, h: 8 },
        defaultConfig: { watchlistIds: ['default'] },
        component: WatchlistPluginComponent,
        documentation: `# Watchlist Widget...`
    },
    'QUOTE': {
        id: 'QUOTE',
        title: 'Level 2 Quote',
        description: 'Order book & detailed stats',
        icon: Table2,
        defaultLayout: { w: 4, h: 8 },
        component: withSuspense(QuoteDetail),
        documentation: `# Level 2 Quote Widget...`
    },
    'TICKS': {
        id: 'TICKS',
        title: 'Transactions',
        description: 'Real-time executed trades',
        icon: FileText,
        defaultLayout: { w: 3, h: 8 },
        component: withSuspense(TransactionList),
        documentation: `# Transactions Widget...`
    },
    'PRICE_DIST': {
        id: 'PRICE_DIST',
        title: 'Price Distribution',
        description: 'Volume by Price Level',
        icon: BarChartHorizontal,
        defaultLayout: { w: 3, h: 8 },
        component: withSuspense(PriceVolumeDistribution),
        documentation: `# Price Distribution Widget...`
    },

    // --- ANALYSIS ---
    'ANALYSIS': {
        id: 'ANALYSIS',
        title: 'Gemini Insight',
        description: 'AI-powered technicals',
        icon: Zap,
        defaultLayout: { w: 4, h: 10 },
        component: AnalysisPluginComponent,
        documentation: `# Gemini Insight Widget...`
    },
    'STATS': {
        id: 'STATS',
        title: 'Fundamentals',
        description: 'Key ratios & stats',
        icon: PieChart,
        defaultLayout: { w: 4, h: 6 },
        component: StatsPluginComponent,
        documentation: `# Fundamentals Widget...`
    },
    'PNF': {
        id: 'PNF',
        title: 'Point & Figure',
        description: 'X/O trend reversal chart',
        icon: Grid,
        defaultLayout: { w: 6, h: 8 },
        component: PointFigurePluginComponent,
        documentation: `# Point & Figure Chart...`
    },
    'RRG': {
        id: 'RRG',
        title: 'RRG Graph',
        description: 'Relative Rotation Graph',
        icon: Crosshair,
        defaultLayout: { w: 6, h: 8 },
        component: RRGPluginComponent,
        documentation: `# Relative Rotation Graph (RRG)...`
    },
    'RADAR': {
        id: 'RADAR',
        title: 'Star Radar',
        description: 'X/Y Scatter with Trails',
        icon: Radar,
        defaultLayout: { w: 8, h: 10 },
        component: withSuspense(StarRadarWidget),
        documentation: `# Star Radar Widget...`
    },
    'MULTI_CHART': {
        id: 'MULTI_CHART',
        title: 'N-Grid Price Chart',
        description: 'Multi-stock Grid View',
        icon: LayoutGrid,
        defaultLayout: { w: 8, h: 12 },
        component: withSuspense(MultiChartWidget),
        defaultConfig: { rows: 2, cols: 2, watchlistId: 'default', sourceMode: 'static' },
        documentation: `# N-Grid Price Chart Widget\n\nDisplays multiple small charts in a grid layout...`
    },
    'IND_CHAIN': {
        id: 'IND_CHAIN',
        title: 'Sector Heatmap',
        description: 'Multi-level Sector Drill-down',
        icon: AlignCenter,
        defaultLayout: { w: 8, h: 10 },
        component: withSuspense(IndustryChainWidget),
        documentation: `# Sector Heatmap Widget...`
    },
};

export const getPluginList = () => Object.values(REGISTERED_PLUGINS);
