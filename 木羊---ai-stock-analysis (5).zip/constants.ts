
import { StockProfile, NewsItem, Workspace, FilterDefinition, WatchlistItem, AppSettings } from './types';
import { INDICATOR_REGISTRY } from './services/indicatorService';

export const INITIAL_STOCK: StockProfile = {
  symbol: '600036',
  name: '招商银行',
  price: 32.50,
  change: 0.45,
  changePercent: 1.40,
  sector: 'Finance'
};

export const I18N = {
    en: {
        appTitle: "GeminiQuant",
        dashboard: "Dashboard",
        screener: "Screener",
        addWidgets: "Add Widgets",
        settings: "Settings",
        
        appearance: "Appearance",
        system: "System",
        chart: "Chart",
        watchlist: "Watchlist",
        language: "Language",
        theme: "Theme",
        fontSize: "Font Size",
        
        // Data Settings
        dataSource: "Data Source",
        provider: "Data Provider",
        apiBaseUrl: "API Base URL",
        apiKey: "API Key (Optional)",
        testConnection: "Test Connection",
        providerMock: "Simulation (Mock Data)",
        providerRest: "Custom REST API",
        providerKite: "KiteTDX (Local)",
        dataNote: "Configure external data providers like Kitetdx or proprietary APIs.",
        
        selectWatchlist: "Select Watchlist",
        createList: "Create List",
        favorites: "Favorites",
        
        p_quote: "Level 2 Quote",
        p_ticks: "Transactions",
        p_price_dist: "Price Distribution",
        p_chart: "Price Chart",
        p_watchlist: "Watchlist",
        p_stats: "Fundamentals",
        p_pnf: "Point & Figure",
        p_rrg: "RRG Graph",
        p_analysis: "Gemini Insight",
        p_chat: "AI Assistant",
        p_news: "News Feed",
        p_radar: "Star Radar",
        p_market_nav: "Navigator",
        p_ind_tree: "Indicator Tree",
        p_list_tree: "List Tree",
        p_tab_container: "Multi-Tab Container",
        p_browser: "Web Browser",
        p_alerts: "Advanced Alerts",
        
        loading: "Loading...",
        noData: "No data available",
        symbol: "Symbol",
        price: "Price",
        change: "Change",
        vol: "Vol",
        
        technicalSignal: "Technical Signal",
        confidence: "Confidence",
        summary: "Executive Summary",
        support: "Support",
        resistance: "Resistance",
        risks: "Risk Factors",
        regenerate: "Regenerate Analysis",
        
        chatPlaceholder: "Ask about trends, support levels...",
        
        marketCap: "Market Cap",
        peRatio: "PE Ratio",
        eps: "EPS (TTM)",
        beta: "Beta",
        divYield: "Div Yield",
        nextEarnings: "Next Earnings",
        high52: "52W High",
        low52: "52W Low",
        
        open: "Open",
        high: "High",
        low: "Low",
        prev: "Prev",
        amt: "Amt",
        turnover: "Turnover",
        inflow: "Inflow",
        
        filters: "Filters",
        saved: "Saved",
        library: "Library",
        builder: "Strategy Builder",
        runScreen: "Run Screen",
        matches: "Matches",
        
        sourceUniverse: "Source Universe",
        allMarket: "All Market Symbols",
        date: "Date",
        filterRules: "Filter Rules",
        rankRules: "Ranking Rules",
        saveLogic: "Save Logic",
        results: "Results",
        saveList: "Save List",
        
        indicators: "Indicators",
        manage: "Manage",
        remove: "Remove",
        flag: "Flag"
    },
    zh: {
        appTitle: "GeminiQuant 量化终端",
        dashboard: "仪表盘",
        screener: "选股器",
        addWidgets: "添加组件",
        settings: "设置",
        
        appearance: "外观",
        system: "系统",
        chart: "图表",
        watchlist: "观察列表",
        language: "语言",
        theme: "主题",
        fontSize: "字体大小",
        
        // Data Settings
        dataSource: "数据源",
        provider: "数据提供商",
        apiBaseUrl: "API 接口地址",
        apiKey: "API 密钥 (可选)",
        testConnection: "测试连接",
        providerMock: "模拟数据 (Mock)",
        providerRest: "自定义 REST API",
        providerKite: "KiteTDX (本地代理)",
        dataNote: "配置外部数据源，例如 Kitetdx 或私有量化接口。",
        
        selectWatchlist: "选择列表",
        createList: "创建列表",
        favorites: "收藏夹",
        
        p_quote: "深度行情 (L2)",
        p_ticks: "成交明细",
        p_price_dist: "分价统计",
        p_chart: "价格图表",
        p_watchlist: "观察列表",
        p_stats: "基本面数据",
        p_pnf: "点数图 (P&F)",
        p_rrg: "相对轮动图 (RRG)",
        p_analysis: "AI 深度分析",
        p_chat: "AI 助手",
        p_news: "新闻快讯",
        p_radar: "星空雷达",
        p_market_nav: "市场导航",
        p_ind_tree: "指标管理",
        p_list_tree: "列表管理",
        p_tab_container: "多标签页容器",
        p_browser: "Web 浏览器",
        p_alerts: "高级预警",
        
        loading: "加载中...",
        noData: "暂无数据",
        symbol: "代码",
        price: "价格",
        change: "涨跌",
        vol: "成交量",
        
        technicalSignal: "技术信号",
        confidence: "置信度",
        summary: "摘要分析",
        support: "支撑位",
        resistance: "阻力位",
        risks: "风险因素",
        regenerate: "重新生成分析",
        
        chatPlaceholder: "询问趋势、支撑位...",
        
        marketCap: "市值",
        peRatio: "市盈率",
        eps: "每股收益",
        beta: "贝塔系数",
        divYield: "股息率",
        nextEarnings: "下次财报",
        high52: "52周最高",
        low52: "52周最低",
        
        open: "开盘",
        high: "最高",
        low: "最低",
        prev: "昨收",
        amt: "成交额",
        turnover: "换手率",
        inflow: "主力流入",
        
        filters: "过滤器",
        saved: "已保存",
        library: "指标库",
        builder: "策略构建器",
        runScreen: "运行选股",
        matches: "匹配数",
        
        sourceUniverse: "选股范围",
        allMarket: "全市场",
        date: "日期",
        filterRules: "过滤规则",
        rankRules: "排序规则",
        saveLogic: "保存策略",
        results: "选股结果",
        saveList: "保存列表",
        
        indicators: "指标",
        manage: "管理",
        remove: "移除",
        flag: "标记"
    }
};

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'en',
  theme: 'dark',
  fontSize: 'medium',
  accentColor: '#4f46e5', // Indigo-600 default
  modules: {
      chart: {
          strokeWidth: 2,
          showGrid: true,
          upColor: '#10b981', // Emerald-500
          downColor: '#f43f5e', // Rose-500
      },
      watchlist: {
          showGridHorizontal: true,
          showGridVertical: false,
          highlightSelected: true,
          flashUpdates: true,
          // Defaults for new appearance settings
          fontSizeHead: 'small',
          fontSizeRow: 'small',
          rowHeight: 'standard',
          fontFamily: 'sans',
          rowStyle: 'plain'
      },
      system: {
          animations: true,
          refreshRate: 5
      }
  },
  data: {
      provider: 'kitetdx', // Default to kitetdx as per guide for local dev
      apiBaseUrl: 'http://localhost:8000', // Default local python server
      updateInterval: 5000
  }
};

// Helper for dynamic formulas
export const evaluateFormula = (formula: string, price: number, change: number, volume: number) => {
  try {
    // Sanitized basic eval
    const func = new Function('price', 'change', 'volume', `return ${formula}`);
    return func(price, change, volume);
  } catch (e) {
    return NaN;
  }
};

export const MOCK_NEWS: NewsItem[] = [
  {
    id: '1',
    title: 'Analyst upgrades price target citing AI demand surge',
    source: 'MarketWatch',
    time: '2h ago',
    sentiment: 'positive',
    url: '#'
  },
  {
    id: '2',
    title: 'Semiconductor sector faces minor pullback ahead of earnings',
    source: 'Bloomberg',
    time: '4h ago',
    sentiment: 'neutral',
    url: '#'
  },
  {
    id: '3',
    title: 'New chip regulations could impact global exports',
    source: 'Reuters',
    time: '6h ago',
    sentiment: 'negative',
    url: '#'
  }
];

// Helper to generate mock trend
const genTrend = () => Array.from({length: 15}, () => Math.random() * 100);
const genRank = () => Math.floor(Math.random() * 99) + 1;
const genPE = () => (Math.random() * 50 + 10).toFixed(2);

// Generate some random stock data for fixed lists
const mockStock = (symbol: string, name: string, price: number, sector: string) => {
    const change = +(Math.random() * 4 - 2).toFixed(2);
    const prev = price - change;
    const changePercent = (change / prev) * 100;
    return {
        symbol, name, price, change, changePercent, 
        vol: (Math.random() * 100).toFixed(1) + 'M', sector,
        // Mock Classification Data
        sws_l1: sector,
        sws_l2: sector + ' Mfg',
        sws_l3: sector + ' Components',
        tdx_hy: sector,
        tdx_gn: 'Blue Chip',
        trend: genTrend(), rps: genRank(), pe: +genPE()
    };
};

export const MOCK_WATCHLISTS: Record<string, WatchlistItem[]> = {
  'default': [
    { 
        symbol: 'NVDA', name: 'NVIDIA Corp', price: 892.45, change: 1.45, changePercent: 0.16, vol: '45M', sector: 'Semiconductors', 
        sector_l1: 'Technology', sector_l2: 'Semiconductors', sector_l3: 'Compute', sector_l4: 'AI Chips',
        sws_l1: 'Electronics', sws_l2: 'Semiconductors', sws_l3: 'Discrete Device',
        tdx_hy: 'Semiconductors', tdx_gn: 'AI / Computing',
        trend: genTrend(), rps: 99, eps_rank: 98, pe: 74.5, 
        sma20: 880.25, sma50: 840.10, ema20: 885.30 
    },
    { 
        symbol: 'AMD', name: 'Adv Micro Dev', price: 178.23, change: -0.85, changePercent: -0.47, vol: '12M', sector: 'Semiconductors', 
        sector_l1: 'Technology', sector_l2: 'Semiconductors', sector_l3: 'Compute', sector_l4: 'Processors',
        sws_l1: 'Electronics', sws_l2: 'Semiconductors', sws_l3: 'IC Design',
        tdx_hy: 'Semiconductors', tdx_gn: 'Processors',
        trend: genTrend(), rps: 92, eps_rank: 85, pe: 45.2,
        sma20: 175.40, sma50: 168.20, ema20: 176.10
    },
    { 
        symbol: 'TSM', name: 'Taiwan Semi', price: 142.10, change: 0.55, changePercent: 0.39, vol: '8M', sector: 'Semiconductors', 
        sector_l1: 'Technology', sector_l2: 'Semiconductors', sector_l3: 'Manufacturing', sector_l4: 'Foundry',
        sws_l1: 'Electronics', sws_l2: 'Semiconductors', sws_l3: 'Foundry',
        tdx_hy: 'Semiconductors', tdx_gn: 'Manufacturing',
        trend: genTrend(), rps: 94, eps_rank: 90, pe: 28.4,
        sma20: 140.05, sma50: 135.50, ema20: 141.20
    },
    { 
        symbol: 'INTC', name: 'Intel Corp', price: 44.30, change: -1.20, changePercent: -2.64, vol: '25M', sector: 'Semiconductors', 
        sector_l1: 'Technology', sector_l2: 'Semiconductors', sector_l3: 'Manufacturing', sector_l4: 'Integrated Circuits',
        sws_l1: 'Electronics', sws_l2: 'Semiconductors', sws_l3: 'Integrated Circuits',
        tdx_hy: 'Semiconductors', tdx_gn: 'Legacy Tech',
        trend: genTrend(), rps: 45, eps_rank: 40, pe: 15.6,
        sma20: 45.10, sma50: 46.50, ema20: 44.80
    },
    { 
        symbol: 'MSFT', name: 'Microsoft', price: 420.15, change: 0.90, changePercent: 0.21, vol: '18M', sector: 'Software', 
        sector_l1: 'Technology', sector_l2: 'Software', sector_l3: 'Infrastructure', sector_l4: 'Cloud Services',
        sws_l1: 'Computer', sws_l2: 'Software Dev', sws_l3: 'System Soft',
        tdx_hy: 'Software', tdx_gn: 'Cloud Computing',
        trend: genTrend(), rps: 96, eps_rank: 95, pe: 35.8,
        sma20: 415.60, sma50: 405.20, ema20: 418.30
    },
    { 
        symbol: 'GOOGL', name: 'Alphabet Inc', price: 175.50, change: 0.30, changePercent: 0.17, vol: '15M', sector: 'Internet', 
        sector_l1: 'Communication', sector_l2: 'Internet', sector_l3: 'Services', sector_l4: 'Search',
        sws_l1: 'Media', sws_l2: 'Internet Media', sws_l3: 'Search Engine',
        tdx_hy: 'Internet', tdx_gn: 'Big Data',
        trend: genTrend(), rps: 90, eps_rank: 88, pe: 24.5,
        sma20: 172.40, sma50: 165.80, ema20: 174.10
    },
  ],
  'a_shares': [
      mockStock('600519', 'Kweichow Moutai', 1700.50, 'Consumer'),
      mockStock('601398', 'ICBC', 5.40, 'Finance'),
      mockStock('600036', 'China Merchants', 32.10, 'Finance'),
      mockStock('601857', 'PetroChina', 8.20, 'Energy'),
      mockStock('600900', 'China Yangtze Power', 22.50, 'Utilities'),
  ],
  'b_shares': [
      mockStock('900901', 'Cloud B', 0.45, 'Tech'),
      mockStock('900932', 'Lujiazui B', 0.78, 'Real Estate'),
      mockStock('900933', 'Huaxin B', 1.20, 'Materials'),
  ],
  'sh_comp': [
      mockStock('000001.SS', 'ShangHai Composite', 3050.20, 'Index'),
      mockStock('000016.SS', 'SSE 50', 2450.10, 'Index'),
      mockStock('000300.SS', 'CSI 300', 3560.80, 'Index'),
  ],
  'sz_comp': [
      mockStock('399001.SZ', 'ShenZhen Component', 9450.30, 'Index'),
      mockStock('399006.SZ', 'ChiNext', 1850.60, 'Index'),
  ],
  'bj_se': [
      mockStock('830832', 'Qi An Xin', 45.20, 'Tech'),
      mockStock('832566', 'BeiJing Stock 50', 980.50, 'Index'),
  ],
  'funds': [
      mockStock('510050', '50 ETF', 2.45, 'ETF'),
      mockStock('510300', '300 ETF', 3.56, 'ETF'),
      mockStock('159915', 'ChiNext ETF', 1.85, 'ETF'),
  ],
  'concepts': [
      mockStock('BK0800', 'AI Concept', 1245.30, 'Concept'),
      mockStock('BK0950', 'EV Battery', 890.20, 'Concept'),
      mockStock('BK0666', 'Cloud Comp', 1105.50, 'Concept'),
  ],
  'growth': [
    { 
        symbol: 'PLTR', name: 'Palantir Tech', price: 24.50, change: 5.20, changePercent: 26.94, vol: '30M', sector: 'Software', 
        sector_l1: 'Technology', sector_l2: 'Software', sector_l3: 'Applications', sector_l4: 'Data Analytics',
        sws_l1: 'Computer', sws_l2: 'Software Dev', sws_l3: 'AI Software',
        tdx_hy: 'Software', tdx_gn: 'AI',
        trend: genTrend(), rps: 95, eps_rank: 70, pe: 120.5,
        sma20: 23.10, sma50: 21.50, ema20: 24.00
    },
    { 
        symbol: 'SOFI', name: 'SoFi Tech', price: 7.80, change: 2.10, changePercent: 36.84, vol: '15M', sector: 'Finance', 
        sector_l1: 'Financials', sector_l2: 'Fintech', sector_l3: 'Banking', sector_l4: 'Personal Finance',
        sws_l1: 'Non-Bank Fin', sws_l2: 'Diversified Fin', sws_l3: 'Fintech',
        tdx_hy: 'Finance', tdx_gn: 'Digital Bank',
        trend: genTrend(), rps: 85, eps_rank: 60, pe: -1,
        sma20: 7.50, sma50: 7.20, ema20: 7.65
    },
    { 
        symbol: 'NET', name: 'Cloudflare', price: 98.20, change: 1.50, changePercent: 1.55, vol: '5M', sector: 'Software', 
        sector_l1: 'Technology', sector_l2: 'Software', sector_l3: 'Infrastructure', sector_l4: 'Security',
        sws_l1: 'Computer', sws_l2: 'Software Dev', sws_l3: 'Cybersecurity',
        tdx_hy: 'Software', tdx_gn: 'Cybersecurity',
        trend: genTrend(), rps: 91, eps_rank: 55, pe: 150.2,
        sma20: 95.40, sma50: 90.10, ema20: 97.00
    },
  ]
};

export const DEFAULT_WORKSPACES: Workspace[] = [
  {
    id: 'ws-1',
    name: 'Market Monitor',
    isHeadersCompact: false, // Default standard view
    widgets: [
      // Top Row
      { id: 'w1', type: 'CHART', title: 'Technical Chart', layout: { x: 0, y: 0, w: 8, h: 8 }, config: {} },
      { id: 'w2', type: 'WATCHLIST', title: 'Semiconductors', layout: { x: 8, y: 0, w: 4, h: 8 }, config: { watchlistIds: ['default'] } },
      // Bottom Row
      { id: 'w3', type: 'NEWS', title: 'Live News Feed', layout: { x: 0, y: 8, w: 4, h: 6 }, config: {} },
      { id: 'w4', type: 'STATS', title: 'Key Fundamentals', layout: { x: 4, y: 8, w: 8, h: 6 }, config: {} },
    ]
  },
  {
    id: 'ws-2',
    name: 'AI Deep Dive',
    isHeadersCompact: true, // Minimized headers for this workspace
    widgets: [
      { id: 'w5', type: 'ANALYSIS', title: 'Gemini Insight', layout: { x: 0, y: 0, w: 4, h: 10 }, config: {} },
      { id: 'w6', type: 'CHAT', title: 'AI Assistant', layout: { x: 0, y: 10, w: 4, h: 8 }, config: {} },
      { id: 'w7', type: 'CHART', title: 'Price Action', layout: { x: 4, y: 0, w: 8, h: 18 }, config: {} },
    ]
  },
];

// Unified source for Screener Filters
// Includes additional base filters not in the registry if needed, 
// but preferring registry as the source of truth.
const BASE_FILTERS: FilterDefinition[] = [
    { id: 'price', name: 'Price', shortName: 'Price', category: 'Market/Basic', dataType: 'number', unit: '$', chartType: 'none' },
    { id: 'country', name: 'Country', shortName: 'Country', category: 'Market/General', dataType: 'select', options: ['USA', 'China', 'Europe'], chartType: 'none' }
];

// Merge BASE with Registry
export const FILTER_DEFINITIONS: FilterDefinition[] = [
    ...BASE_FILTERS,
    ...INDICATOR_REGISTRY
];

const STANDARD_METRICS = [
    { id: 'trend', name: 'Trend Line', type: 'sparkline' },
    { id: 'price', name: 'Price', type: 'number' },
    { id: 'change', name: 'Change %', type: 'number' },
    // Volume is in registry now, but kept here for default ordering if preferred
    { id: 'rps', name: 'RPS', type: 'number' },
    { id: 'eps_rank', name: 'EPS Rank', type: 'number' },
    { id: 'sector_l1', name: 'Economic Sector (L1)', type: 'string' },
    { id: 'sector_l3', name: 'Sub-industry (L3)', type: 'string' },
    { id: 'sector_l4', name: 'Industry Group (L4)', type: 'string' },
    { id: 'sws_l1', name: 'SWS Sector (L1)', type: 'string' },
    { id: 'sws_l2', name: 'SWS Industry (L2)', type: 'string' },
    { id: 'tdx_hy', name: 'TDX Industry', type: 'string' },
];

// Merge standard metrics with registered indicators for the Watchlist/Screener dropdowns
export const AVAILABLE_METRICS = [
  ...STANDARD_METRICS,
  ...INDICATOR_REGISTRY.map(ind => ({ 
      id: ind.id, 
      name: ind.shortName, // Use short name for columns 
      type: ind.dataType === 'number' ? 'number' : 'string' 
  }))
];
