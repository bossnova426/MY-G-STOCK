
import React from 'react';

// --- Core Data Models ---

export interface StockProfile {
    symbol: string;
    name: string;
    price: number;
    change: number;
    changePercent: number;
    sector: string;
    vol?: string;
    [key: string]: any;
}

export interface StockDataPoint {
    date: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    [key: string]: any;
}

export interface NewsItem {
    id: string;
    title: string;
    source: string;
    time: string;
    sentiment: 'positive' | 'neutral' | 'negative';
    url: string;
}

export interface FundamentalData {
    marketCap: string;
    peRatio: string;
    eps: string;
    beta: string;
    divYield: string;
    nextEarnings: string;
    high52: string;
    low52: string;
}

export interface AnalysisResult {
    symbol: string;
    summary: string;
    technicalSignal: 'BUY' | 'SELL' | 'HOLD';
    confidenceScore: number;
    keyLevels: {
        support: number[];
        resistance: number[];
    };
    risks: string[];
}

// --- App State & Settings ---

export interface ModuleSettings {
    chart: {
        strokeWidth: number;
        showGrid: boolean;
        upColor: string;
        downColor: string;
    };
    watchlist: {
        showGridHorizontal: boolean;
        showGridVertical: boolean;
        highlightSelected: boolean;
        flashUpdates: boolean;
        fontSizeHead: string;
        fontSizeRow: string;
        rowHeight: string;
        fontFamily: string;
        rowStyle: string;
    };
    system: {
        animations: boolean;
        refreshRate: number;
    };
}

export interface DataSettings {
    provider: string;
    apiBaseUrl: string;
    apiKey?: string;
    updateInterval: number;
}

export interface AppSettings {
    language: 'en' | 'zh';
    theme: 'dark' | 'light';
    fontSize: string;
    accentColor: string;
    modules: ModuleSettings;
    data: DataSettings;
}

// --- Watchlists & Screener ---

export interface WatchlistItem extends StockProfile {
    // Extends profile with potential extra metrics
    trend?: number[];
    [key: string]: any;
}

export interface WatchlistColumn {
    id: string;
    defId: string;
    label: string;
    timeframe: string;
    width: number;
}

export interface CustomWatchlist {
    id: string;
    name: string;
    stocks: WatchlistItem[];
    readOnly?: boolean;
    columns?: WatchlistColumn[];
}

export interface CustomColumn {
    id: string;
    name: string;
    formula: string;
}

// Screener Types
export interface FilterDefinition {
    id: string;
    name: string;
    shortName: string;
    category: string;
    dataType: 'number' | 'string' | 'select' | 'boolean';
    unit?: string;
    chartType: 'none' | 'overlay' | 'oscillator';
    options?: string[];
}

export interface ActiveFilter {
    id: string;
    defId: string;
    name: string;
    mode: string;
    operator: string;
    scope: string;
    value: string | number;
    logic?: string;
}

export interface FilterGroup {
    id: string;
    logic: 'AND' | 'OR';
    filters: ActiveFilter[];
    operator?: 'AND' | 'OR'; 
}

export interface RankingCriterion {
    id: string;
    defId: string;
    name: string;
    direction: 'asc' | 'desc';
    scope: string;
    weight: number;
}

export interface SavedScreen {
    id: string;
    name: string;
    groups: FilterGroup[];
    rankingCriteria: RankingCriterion[];
    createdAt: string;
}

export interface SavedFilterGroup {
    id: string;
    name: string;
    filters: ActiveFilter[];
}

// --- Workspaces & Widgets ---

export interface WidgetConfigHistory {
    timestamp: number;
    config: any;
    description: string;
}

export interface Widget {
    id: string;
    type: string;
    title: string;
    layout: { x: number; y: number; w: number; h: number };
    config: any;
    configHistory?: WidgetConfigHistory[];
    hideHeader?: boolean;
    linkGroup?: string;
}

export interface Workspace {
    id: string;
    name: string;
    widgets: Widget[];
    sidebarWidgets?: Widget[];
    rightWidgets?: Widget[];
    bottomWidgets?: Widget[];
    isHeadersCompact?: boolean;
}

// --- Plugins ---

export interface WidgetCommand {
    type: string;
    payload: any;
}

// Simple EventBus Interface for Context
export interface IEventBus {
    on(topic: string, handler: (payload: any) => void): () => void;
    emit(topic: string, payload?: any): void;
}

export interface WidgetContext {
    symbol: string;
    profile: StockProfile;
    chartData: StockDataPoint[];
    analysis: AnalysisResult | null;
    loadingAnalysis: boolean;
    availableWatchlists: CustomWatchlist[];
    news: NewsItem[];
    fundamentals: FundamentalData | null;
    widgetConfig: any;
    settings: AppSettings;
    sharedHoverLabel: string | null;
    setSharedHoverLabel: (label: string | null) => void;
    customColumns: CustomColumn[];
    onAddCustomColumn: (col: CustomColumn) => void;
    onRemoveCustomColumn: (id: string) => void;
    onUpdateConfig: (config: any) => void;
    onRefreshData: () => void;
    onSymbolSelect: (symbol: string) => void;
    onAddStockToWatchlists: (symbol: string, listIds: string[]) => void;
    onRemoveStockFromWatchlist: (symbol: string, listId: string) => void;
    onAddWatchlist: (name: string) => void;
    onRenameWatchlist: (id: string, newName: string) => void;
    onDeleteWatchlist: (id: string) => void;
    onUpdateWatchlist: (id: string, updates: Partial<CustomWatchlist>) => void;
    onSaveWatchlist?: (watchlist: CustomWatchlist) => void;
    pluginRegistry: any; // Record<string, WidgetPlugin>
    workspaces: Workspace[];
    activeWorkspaceId: string;
    onSwitchWorkspace: (id: string) => void;
    onAddWorkspace: (name?: string) => void;
    onRenameWorkspace: (id: string, name: string) => void;
    onDeleteWorkspace: (id: string) => void;
    savedScreens: SavedScreen[];
    onSaveScreen: (screen: SavedScreen) => void;
    onOpenScreener: (ids: string[]) => void;
    activeList?: WatchlistItem[];
    onBroadcastList?: (list: WatchlistItem[]) => void;
    command: WidgetCommand | null;
    eventBus: IEventBus; // Added EventBus
}

export interface WidgetPlugin {
    id: string;
    title: string;
    description: string;
    icon: React.ElementType;
    defaultLayout: { w: number, h: number };
    component: React.ComponentType<WidgetContext>; // Relaxed type for Lazy
    defaultConfig?: any;
    documentation?: string;
}

export interface AppState {
    workspaces: Workspace[];
    watchlists: CustomWatchlist[];
    settings: AppSettings;
    savedScreens?: SavedScreen[];
}

export interface VersionCheckpoint {
    id: string;
    timestamp: number;
    type: 'AUTO' | 'MANUAL';
    label: string;
    data: AppState;
    description?: string;
}

// --- Formula System & Universal Renderer ---

export interface FormulaFile {
    id: string;
    name: string;
    category: string;
    code: string;
    updatedAt: number;
}

export interface BackendChartResponse {
    plots: Array<{
        id: string;
        name: string;
        type: 'line' | 'histogram' | 'area';
        color: string;
        width?: number;
        data: { time: string; value: number; color?: string }[];
        panel?: 'main' | 'bottom';
    }>;
    segments: Array<{
        id: string;
        x1: string;
        y1: number;
        x2: string;
        y2: number;
        color: string;
        width?: number;
        style?: 'solid' | 'dashed' | 'dotted';
    }>;
    markers: Array<{
        time: string;
        position: 'aboveBar' | 'belowBar' | 'inBar';
        shape: 'arrowUp' | 'arrowDown' | 'circle' | 'square';
        color: string;
        text: string;
        size?: number;
    }>;
    logs?: string[];
    error?: string;
}

// --- Indicators ---
export type IndicatorSource = 'built-in' | 'remote' | 'user-script';
export type RenderType = 'line' | 'histogram' | 'area' | 'band' | 'icon';

export interface IndicatorStyle {
    color: string;
    lineWidth?: number;
    lineStyle?: number;
    visible?: boolean;
    areaColor?: string;
    upColor?: string;
    downColor?: string;
    showLabel?: boolean;
}

export interface IndicatorParams {
    [key: string]: any;
}

export interface IndicatorConfig {
    id: string;
    defId: string;
    visible: boolean;
    period?: number;
    params: IndicatorParams;
    color: string;
    lineWidth: number;
    styles: Record<string, IndicatorStyle>;
}

export interface IndicatorParamDef {
    key: string;
    label: string;
    type: 'number' | 'boolean' | 'string' | 'select' | 'color';
    default: any;
    min?: number;
    max?: number;
    step?: number;
    options?: string[];
}

export interface OutputDef {
    key: string;
    label: string;
    type: 'line' | 'histogram' | 'marker' | 'area' | 'band';
    defaultStyle: IndicatorStyle;
}

export interface IndicatorMetadata {
    id: string;
    name: string;
    shortName: string;
    category: string;
    source: IndicatorSource;
    version?: string;
    author?: string;
    description?: string;
    tags?: string[];
    isFavorite?: boolean;
    dataType: 'number' | 'string' | 'select' | 'boolean';
    chartType: 'none' | 'overlay' | 'oscillator';
    unit?: string;
    options?: string[];
    isAsync?: boolean;
}

export interface IndicatorDefinition extends IndicatorMetadata {
    renderType?: RenderType;
    paramDefs?: IndicatorParamDef[];
    outputDefs?: OutputDef[];
    defaultStyle?: IndicatorStyle;
    calculate: (data: StockDataPoint[], params?: IndicatorParams) => StockDataPoint[] | Promise<StockDataPoint[]>;
}

export type TimeFrame = '1m' | '5m' | '15m' | '1H' | '4H' | '1D' | '1W' | '1M';
