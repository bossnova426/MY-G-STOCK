
# GeminiQuant 插件开发参考手册

本文档为 GeminiQuant 平台中注册的每个 Widget 提供了详细的技术规范。旨在帮助开发者扩展系统或维护现有插件。

## 架构概览

所有插件均在 `pluginRegistry.tsx` 中注册，并通过 `App.tsx` 进行消费。
它们接收统一的 `WidgetContext` 对象，其中包含应用程序状态、数据流和操作处理程序。

**通用依赖:**
*   `lucide-react`: 用于 UI 图标。
*   `WidgetContext`: 定义在 `types.ts` 中的核心接口。
*   `Tailwind CSS`: 用于样式设计 (使用 `slate` 色阶和 `dark:` 修饰符)。

---

## 1. StockChart (价格图表)

**ID:** `CHART`  
**路径:** `components/StockChart.tsx`

### 功能
一个基于 `lightweight-charts` 的高性能交互式金融图表。它渲染 K 线数据、成交量叠加层和技术指标。包含内置的绘图工具栏（趋势线、斐波那契回调、文本标注）和指标管理菜单。

### 构建条件与要求

*   **核心库:** `lightweight-charts` (基于 Canvas 渲染)。
*   **上下文使用:**
    *   `settings`: 读取 `theme` (深/浅色模式) 和 `modules.chart` (涨/跌颜色) 以进行样式适配。
    *   `onHover`: 调用此函数以向其他组件广播十字准线的时间戳。
    *   `sharedHoverLabel`: 监听此属性以同步十字准线位置 (通过 `subscribeCrosshairMove` 实现)。
*   **内部状态:**
    *   `activeIndicators`: 字符串 ID 数组 (例如 `['sma20', 'vol']`)。在本地管理，但可通过 `command` 属性修改。
    *   `drawings`: 本地矢量对象数组 (线段, 斐波那契, 文本)。目前未全局持久化。

### 数据接口 (Data Interface)
组件需要接收一个按日期升序排列的 OHLCV 数据数组。

```typescript
// Prop: data
type StockData = StockDataPoint[];

interface StockDataPoint {
  date: string;   // ISO 格式 "YYYY-MM-DD"
  open: number;   // 开盘价
  high: number;   // 最高价
  low: number;    // 最低价
  close: number;  // 收盘价
  volume: number; // 成交量 (整数)
  // 可选: 如果不在客户端计算，可在此传递预计算的指标值
  // 例如: sma20: number;
}
```

---

## 2. Watchlist (观察列表/行情板)

**ID:** `WATCHLIST`  
**路径:** `components/Watchlist.tsx`

### 功能
一个复杂的数据网格，支持多列排序、自定义公式列、分组（按板块）和拖放列重新排序。底部支持“已保存视图”（快捷方式）。

### 构建条件与要求

*   **配置 (`widgetConfig`):**
    *   `watchlistIds`: 字符串数组。决定聚合和显示哪些列表的数据。
    *   `exclusiveMode`: 布尔值。如果为 true，显示列表的交集；否则显示并集。
*   **特性:**
    *   **公式评估:** 使用 `new Function()` 安全封装在 `evaluateFormula` (constants.ts) 中，用于计算如 `price * volume` 等自定义列。
    *   **拖放:** 列标题使用原生 HTML5 Drag API。

### 数据接口 (Data Interface)
消费 `CustomWatchlist` 对象列表。

```typescript
// Prop: availableWatchlists
type WatchlistData = CustomWatchlist[];

interface CustomWatchlist {
  id: string;     // 唯一 ID
  name: string;   // 显示名称 (支持使用 "/" 进行分组，例如 "US/Tech")
  readOnly?: boolean; // 是否只读 (系统列表)
  stocks: WatchlistItem[];
}

interface WatchlistItem {
  symbol: string;        // 代码
  name?: string;         // 名称
  price: number;         // 现价
  change: number;        // 涨跌额
  changePercent: number; // 涨跌幅 (例如 1.5 代表 1.5%)
  vol: number | string;  // 成交量 (支持数字或 "10M" 格式字符串)
  sector?: string;       // 板块 (用于分组)
  sector_l1?: string;    // 一级行业 (可选)
  sector_l2?: string;    // 二级行业 (可选)
  pe?: number;           // 市盈率 (可选)
  mkt_cap?: number;      // 市值 (可选)
  trend?: number[];      // 用于迷你图的数字数组
}
```

---

## 3. Screener (策略选股器)

**ID:** `SCREENER`  
**路径:** `components/widgets/Screener.tsx`

### 功能
一个可视化的查询构建器，用于根据技术和基本面标准筛选股票。支持嵌套逻辑组 (AND/OR)、日期范围过滤和排名（加权评分）。

### 构建条件与要求

*   **UI 布局:** 3 栏布局（指标库、构建器、结果）。使用手动调整大小的手柄。
*   **执行逻辑:**
    *   过滤在客户端 `runStrategy()` 中使用 `mockUniverse` 或提供的数据列表进行。
    *   **性能:** 严重依赖 `useCallback` 优化的 `checkCondition` 函数，以避免循环执行期间的重新渲染。

### 数据接口 (Data Interface)
使用与 **Watchlist** 相同的数据结构作为其源数据 (`availableWatchlists`)。此外，它管理已保存的策略。

```typescript
// Prop: savedScreens
interface SavedScreen {
  id: string;
  name: string;
  groups: FilterGroup[]; // 逻辑定义
  rankingCriteria?: RankingCriterion[]; // 排序定义
  createdAt: string;
}
```

---

## 4. AlertsWidget (高级预警)

**ID:** `ALERTS`  
**路径:** `components/widgets/AlertsWidget.tsx`

### 功能
模拟实时服务端预警系统。它维护一个监控规则列表，并在满足条件时生成日志流。

### 构建条件与要求

*   **状态管理:**
    *   `rules`: `AlertRule` 的本地状态数组。
    *   `logs`: 触发事件的滚动数组（保留最后 100 条）。
    *   `intervalRef`: 使用 `window.setInterval` 模拟传入信号。

### 数据接口 (Data Interface)
使用 `availableWatchlists` 来随机抽取股票以生成模拟触发事件。

---

## 5. BrowserWidget (内嵌浏览器)

**ID:** `BROWSER`  
**路径:** `components/BrowserWidget.tsx`

### 功能
一个 `iframe` 包装器，设计用于显示与当前选中股票代码同步的外部金融数据或新闻。

### 构建条件与要求

*   **配置 (`widgetConfig`):**
    *   `urlTemplate`: 包含占位符的字符串（`xxxxxx` 代表代码, `!!` 代表市场, `##STOCKNAME##` 代表名称）。
    *   `isSyncEnabled`: 布尔值。如果为 true，当全局代码变更时更新 URL。

### 数据接口 (Data Interface)
需要基本的代码上下文。

```typescript
// Context Props
symbol: string; // 例如 "NVDA"
profile: {
    name: string; // 例如 "NVIDIA Corp"
}
```

---

## 6. StarRadarWidget (星空雷达 / RRG)

**ID:** `RADAR`  
**路径:** `components/StarRadarWidget.tsx`

### 功能
一种专门的散点图可视化，用于追踪股票在两个轴（例如：价格变化 vs 成交量，或 RS-Ratio vs RS-Momentum）随时间变化的轨迹（尾迹）。

### 构建条件与要求

*   **库:** 自定义 SVG 实现。
*   **数据转换:**
    *   需要获取所选观察列表中*每只*股票的历史数据 (`getHistory`)。
    *   **缓存:** 实现内部 `historyCache`，以防止在切换轴时重新获取数据。

### 数据接口 (Data Interface)
期望 `availableWatchlists` 定义范围。然后为每只股票获取 `StockDataPoint[]` (与 StockChart 相同)。

---

## 7. TabContainerWidget (多标签容器)

**ID:** `TAB_CONTAINER`  
**路径:** `components/TabContainerWidget.tsx`

### 功能
一个递归容器，可以在标签页中托管其他 Widget。这允许创建高密度布局（例如，在同一个网格单元中放置“基本面”标签和“新闻”标签）。

### 数据接口 (Config)
纯配置驱动。

```typescript
// Config
interface TabContainerConfig {
    activeTabId: string;
    tabs: Array<{
        id: string;
        type: string; // 插件 ID (例如 "CHART")
        title: string;
        config: any;  // 传递给子组件的配置
    }>;
}
```

---

## 8. AnalysisPanel (AI 深度分析)

**ID:** `ANALYSIS`  
**路径:** `components/AnalysisPanel.tsx`

### 功能
显示由 Gemini 模型生成的结构化 AI 分析结果（摘要、支撑/阻力位、风险因素）。

### 数据接口 (Data Interface)
期望一个结构化的分析对象，通常由 LLM 生成。

```typescript
// Prop: analysis
interface AnalysisResult {
  symbol: string;
  summary: string; // 2-3 句话的概述
  technicalSignal: 'BUY' | 'SELL' | 'HOLD'; // 信号
  confidenceScore: number; // 0-100 置信度
  keyLevels: {
    support: number[];    // 支撑位数组 [120.5, 118.0]
    resistance: number[]; // 阻力位数组 [135.0, 140.0]
  };
  risks: string[]; // 风险因素数组 ["High Volatility", "Earnings Risk"]
}
```

---

## 9. ChatInterface (AI 助手)

**ID:** `CHAT`  
**路径:** `components/ChatInterface.tsx`

### 功能
一个用于通过 LLM 查询市场数据的对话界面。

### 数据接口
仅内部状态 (`messages` 数组)。与 `geminiService` 交互。

---

## 10. TickerTape (滚动行情条)

**路径:** `components/TickerTape.tsx`

### 功能
市场指数（标准普尔 500、上证指数、BTC）的滚动跑马灯。

### 数据接口
内部指数列表。

```typescript
interface MarketIndex {
    id: string;
    name: string;
    value: number;
    change: number;
    changePercent: number;
}
```

---

## 11. QuoteDetail (深度行情 L2)

**ID:** `QUOTE`  
**路径:** `components/QuoteDetail.tsx`

### 功能
模拟 Level 2 (订单簿) 数据，显示买/卖深度和详细的交易统计数据。

### 数据接口 (Data Interface)
需要两个数据对象。

```typescript
// Prop: profile
interface StockProfile {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  sector: string;
}

// Prop: fundamentals
interface FundamentalData {
  marketCap: string; // 例如 "2.0T"
  peRatio: string;
  eps: string;
  beta: string;
  divYield: string;
  high52: string;
  low52: string;
}
```

---

## 12. MarketNavigatorWidget (市场导航)

**ID:** `MARKET_NAV`  
**路径:** `components/MarketNavigatorWidget.tsx`

### 功能
一个类似于文件系统的资源管理器，用于浏览所有观察列表和板块。

### 数据接口
消费 `availableWatchlists` (参见 Watchlist 部分)。
