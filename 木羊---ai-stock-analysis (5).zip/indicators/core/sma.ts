
import { IndicatorDefinition } from '../types';
import { calculateSMA } from '../utils';

export const sma20: IndicatorDefinition = {
    id: 'sma20',
    name: 'SMA 20',
    shortName: 'SMA(20)',
    category: 'Technical/Trend',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#fbbf24', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 20, min: 1, max: 200 }],
    calculate: (data, params) => calculateSMA(data, params?.period || 20, 'sma20')
};

export const sma50: IndicatorDefinition = {
    id: 'sma50',
    name: 'SMA 50',
    shortName: 'SMA(50)',
    category: 'Technical/Trend',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#3b82f6', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 50, min: 1, max: 200 }],
    calculate: (data, params) => calculateSMA(data, params?.period || 50, 'sma50')
};
