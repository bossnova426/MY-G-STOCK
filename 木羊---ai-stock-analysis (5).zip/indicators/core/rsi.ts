
import { StockDataPoint } from '../../types';
import { IndicatorDefinition } from '../types';

const calculateRSI = (data: StockDataPoint[], period: number = 14): StockDataPoint[] => {
    if (!data || data.length <= period) return data.map(d => ({ ...d, rsi: null }));

    let gains = 0;
    let losses = 0;

    // Initial avg
    for(let i=1; i<=period; i++) {
        if (!data[i] || !data[i-1]) continue;
        const diff = data[i].close - data[i-1].close;
        if(diff >= 0) gains += diff;
        else losses += Math.abs(diff);
    }
    
    let avgGain = gains / period;
    let avgLoss = losses / period;

    return data.map((point, index) => {
        if (index <= period) return { ...point, rsi: null };
        if (!data[index-1]) return { ...point, rsi: null };
        
        const diff = point.close - data[index-1].close;
        const currentGain = diff > 0 ? diff : 0;
        const currentLoss = diff < 0 ? Math.abs(diff) : 0;
        
        avgGain = ((avgGain * (period - 1)) + currentGain) / period;
        avgLoss = ((avgLoss * (period - 1)) + currentLoss) / period;
        
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        const rsi = 100 - (100 / (1 + rs));
        
        return { ...point, rsi };
    });
};

export const rsi: IndicatorDefinition = {
    id: 'rsi',
    name: 'RSI (14)',
    shortName: 'RSI(14)',
    category: 'Technical/Oscillator',
    source: 'built-in',
    dataType: 'number',
    chartType: 'oscillator',
    defaultStyle: { color: '#8b5cf6', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 14, min: 2, max: 100 }],
    calculate: (data, params) => calculateRSI(data, params?.period || 14)
};
