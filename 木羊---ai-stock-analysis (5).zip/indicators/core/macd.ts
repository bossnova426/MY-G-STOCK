
import { StockDataPoint } from '../../types';
import { IndicatorDefinition } from '../types';

const calculateMACD = (data: StockDataPoint[], fast: number = 12, slow: number = 26, signal: number = 9): StockDataPoint[] => {
    if (!data || data.length === 0) return [];
    
    let eFast = data[0]?.close || 0;
    let eSlow = data[0]?.close || 0;
    const kFast = 2 / (fast + 1); 
    const kSlow = 2 / (slow + 1);
    const kSignal = 2 / (signal + 1);

    const withMacdLine = data.map((p, i) => {
        if(i===0) return { ...p, macd: 0, macd_signal: 0, macd_hist: 0 };
        const price = p?.close || 0;
        eFast = (price * kFast) + (eFast * (1 - kFast));
        eSlow = (price * kSlow) + (eSlow * (1 - kSlow));
        const macd = eFast - eSlow;
        return { ...p, macd };
    });

    let eSignal = withMacdLine[0]?.macd || 0;
    return withMacdLine.map((p, i) => {
        if (i===0) return p;
        const currentMacd = p.macd || 0;
        eSignal = (currentMacd * kSignal) + (eSignal * (1 - kSignal));
        return { ...p, macd_signal: eSignal, macd_hist: currentMacd - eSignal };
    });
};

export const macd: IndicatorDefinition = {
    id: 'macd',
    name: 'MACD',
    shortName: 'MACD',
    category: 'Technical/Momentum',
    source: 'built-in',
    dataType: 'number',
    chartType: 'oscillator',
    defaultStyle: { color: '#10b981', lineWidth: 2 },
    paramDefs: [
        { key: 'fast', label: 'Fast Length', type: 'number', default: 12, min: 2, max: 50 },
        { key: 'slow', label: 'Slow Length', type: 'number', default: 26, min: 2, max: 100 },
        { key: 'signal', label: 'Signal Length', type: 'number', default: 9, min: 2, max: 50 }
    ],
    calculate: (data, params) => calculateMACD(data, params?.fast || 12, params?.slow || 26, params?.signal || 9)
};
