
import { StockDataPoint } from '../../types';
import { IndicatorDefinition } from '../types';

const calculateBollinger = (data: StockDataPoint[], period: number, mult: number): StockDataPoint[] => {
  if (!data || data.length === 0) return [];
  return data.map((point, index, array) => {
    if (index < period - 1) return { ...point, bb_upper: null, bb_lower: null };
    
    const slice = array.slice(index - period + 1, index + 1);
    const sum = slice.reduce((acc, curr) => acc + (curr?.close || 0), 0);
    const sma = sum / period;
    
    const squaredDiffs = slice.map(p => Math.pow((p?.close || 0) - sma, 2));
    const variance = squaredDiffs.reduce((acc, curr) => acc + curr, 0) / period;
    const stdDev = Math.sqrt(variance);

    return { 
      ...point, 
      bb_upper: sma + (stdDev * mult),
      bb_lower: sma - (stdDev * mult)
    };
  });
};

export const bollinger: IndicatorDefinition = {
    id: 'bollinger',
    name: 'Bollinger Bands',
    shortName: 'BB(20,2)',
    category: 'Technical/Volatility',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#a8a29e', lineWidth: 1, areaColor: 'rgba(168, 162, 158, 0.1)' },
    paramDefs: [
        { key: 'period', label: 'Period', type: 'number', default: 20, min: 2, max: 100 },
        { key: 'mult', label: 'Multiplier', type: 'number', default: 2, min: 0.5, max: 5, step: 0.1 }
    ],
    calculate: (data, params) => calculateBollinger(data, params?.period || 20, params?.mult || 2)
};
