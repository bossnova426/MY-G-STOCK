
import { IndicatorDefinition } from '../types';
import { calculateEMA } from '../utils';

export const ema20: IndicatorDefinition = {
    id: 'ema20',
    name: 'EMA 20',
    shortName: 'EMA(20)',
    category: 'Technical/Trend',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#ec4899', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 20, min: 1, max: 200 }],
    calculate: (data, params) => calculateEMA(data, params?.period || 20, 'ema20')
};
