
import { StockDataPoint } from '../../types';
import { IndicatorDefinition } from '../types';

const mapVolume = (data: StockDataPoint[]): StockDataPoint[] => {
    if (!data) return [];
    return data.map(d => ({ ...d, vol: d.volume }));
};

export const vol: IndicatorDefinition = {
    id: 'vol',
    name: 'Volume',
    shortName: 'Vol',
    category: 'Market/Liquidity',
    source: 'built-in',
    dataType: 'number',
    unit: 'M',
    chartType: 'oscillator',
    defaultStyle: { color: '#26a69a', upColor: '#10b981', downColor: '#f43f5e' },
    calculate: (data) => mapVolume(data)
};
