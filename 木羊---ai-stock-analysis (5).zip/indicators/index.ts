
import { IndicatorDefinition } from './types';

// Core
import { sma20, sma50 } from './core/sma';
import { ema20 } from './core/ema';
import { bollinger } from './core/bollinger';
import { rsi } from './core/rsi';
import { macd } from './core/macd';
import { vol } from './core/vol';

// Remote
import { marketSmith } from './remote/marketSmith';

// --- FUNDAMENTAL / MARKET (No Chart Calculation) ---
const fundamentals: IndicatorDefinition[] = [
  { id: 'mkt_cap', name: 'Market Cap', shortName: 'Mkt Cap', category: 'Market/Basic', source: 'built-in', dataType: 'number', unit: 'B', chartType: 'none', calculate: (d) => d },
  { id: 'pe_ratio', name: 'P/E Ratio', shortName: 'P/E', category: 'Financial/Valuation', source: 'built-in', dataType: 'number', chartType: 'none', calculate: (d) => d },
  { id: 'div_yield', name: 'Dividend Yield', shortName: 'Div Yield', category: 'Financial/Income', source: 'built-in', dataType: 'number', unit: '%', chartType: 'none', calculate: (d) => d },
  { id: 'sector', name: 'Sector', shortName: 'Sector', category: 'Market/General', source: 'built-in', dataType: 'select', options: ['Tech', 'Finance', 'Energy', 'Healthcare'], chartType: 'none', calculate: (d) => d },
  { id: 'eps_growth', name: 'EPS Growth (YoY)', shortName: 'EPS Growth', category: 'Financial/Growth', source: 'built-in', dataType: 'number', unit: '%', chartType: 'none', calculate: (d) => d },
];

export const INDICATOR_REGISTRY: IndicatorDefinition[] = [
    ...fundamentals,
    sma20,
    sma50,
    ema20,
    bollinger,
    vol,
    rsi,
    macd,
    marketSmith
];

export const getIndicatorById = (id: string) => INDICATOR_REGISTRY.find(i => i.id === id);
