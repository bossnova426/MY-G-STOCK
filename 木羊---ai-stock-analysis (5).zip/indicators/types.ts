
import { StockDataPoint } from '../types';

export type IndicatorSource = 'built-in' | 'remote' | 'user-script';
export type RenderType = 'line' | 'histogram' | 'area' | 'band' | 'icon';

export interface IndicatorStyle {
    color: string;
    lineWidth?: number;
    lineStyle?: number; // 0=Solid, 1=Dotted, 2=Dashed
    visible?: boolean;
    areaColor?: string; // For area-type indicators
    upColor?: string;   // For histograms/candles
    downColor?: string;
}

export interface IndicatorParams {
    [key: string]: any;
}

export interface IndicatorParamDef {
    key: string;
    label: string;
    type: 'number' | 'boolean' | 'string' | 'select' | 'color';
    default: any;
    min?: number;
    max?: number;
    step?: number;
    options?: string[];
}

export interface OutputDef {
    key: string;
    label: string;
    type: 'line' | 'histogram' | 'marker' | 'area' | 'band';
    defaultStyle: IndicatorStyle;
}

// Lightweight Metadata for Indexing
export interface IndicatorMetadata {
    id: string;
    name: string;
    shortName: string;
    category: string; // e.g., "Trend/Moving Averages"
    source: IndicatorSource;
    version?: string;
    author?: string;
    description?: string;
    tags?: string[];
    isFavorite?: boolean;
    
    // Properties shared with FilterDefinition and required for UI/Filtering
    dataType: 'number' | 'string' | 'select' | 'boolean';
    chartType: 'none' | 'overlay' | 'oscillator';
    unit?: string;
    options?: string[];
    isAsync?: boolean;
}

// Full Definition (Loaded on demand)
export interface IndicatorDefinition extends IndicatorMetadata {
    renderType?: RenderType; // New: Hint for Universal Renderer
    
    // Parameter Definitions (for UI generation)
    paramDefs?: IndicatorParamDef[];

    // Output Definitions (for multi-line/style configuration)
    outputDefs?: OutputDef[];

    // Default Style Configuration (Legacy/Simple)
    defaultStyle?: IndicatorStyle;

    // Calculation Logic
    // Local: Synchronous calculation
    // Remote: Can be async (returns Promise)
    calculate: (data: StockDataPoint[], params?: IndicatorParams) => StockDataPoint[] | Promise<StockDataPoint[]>;
}
