
import { IndicatorMetadata } from './types';

export const INDICATOR_INDEX: IndicatorMetadata[] = [
  {
    id: "sma20",
    name: "Simple Moving Average 20",
    shortName: "SMA(20)",
    category: "Trend/Moving Average",
    source: "built-in",
    version: "1.0.0",
    description: "The average of the closing price over the last 20 periods.",
    tags: ["trend", "lagging", "popular"],
    dataType: "number",
    chartType: "overlay"
  },
  {
    id: "ema20",
    name: "Exponential Moving Average 20",
    shortName: "EMA(20)",
    category: "Trend/Moving Average",
    source: "built-in",
    version: "1.0.0",
    description: "Weighted moving average that gives more importance to recent price data.",
    tags: ["trend", "lagging"],
    dataType: "number",
    chartType: "overlay"
  },
  {
    id: "rsi",
    name: "Relative Strength Index",
    shortName: "RSI(14)",
    category: "Momentum/Oscillator",
    source: "built-in",
    version: "1.0.0",
    tags: ["momentum", "overbought", "oversold"],
    dataType: "number",
    chartType: "oscillator"
  },
  {
    id: "macd",
    name: "Moving Average Convergence Divergence",
    shortName: "MACD",
    category: "Momentum/Trend",
    source: "built-in",
    version: "1.0.0",
    tags: ["momentum", "trend"],
    dataType: "number",
    chartType: "oscillator"
  },
  {
    id: "bollinger",
    name: "Bollinger Bands",
    shortName: "BB(20,2)",
    category: "Volatility/Bands",
    source: "built-in",
    version: "1.0.0",
    tags: ["volatility", "bands"],
    dataType: "number",
    chartType: "overlay"
  },
  {
    id: "vol",
    name: "Volume",
    shortName: "Vol",
    category: "Market/Volume",
    source: "built-in",
    version: "1.0.0",
    tags: ["volume", "liquidity"],
    dataType: "number",
    chartType: "oscillator"
  },
  {
    id: "ms_pattern",
    name: "MarketSmith Pattern Recognition",
    shortName: "MS Pattern",
    category: "Pattern/AI",
    source: "remote",
    version: "2.1.0",
    author: "GeminiQuant Team",
    description: "Detects Cup with Handle, Flat Base, and Double Bottom patterns using server-side logic.",
    tags: ["pattern", "ai", "advanced"],
    dataType: "string",
    chartType: "overlay",
    isAsync: true
  },
  {
    id: "supertrend_pro",
    name: "SuperTrend Pro (Remote)",
    shortName: "SuperTrend",
    category: "Trend/Advanced",
    source: "remote",
    version: "1.0.5",
    description: "Server-calculated SuperTrend with dynamic ATR adjustment.",
    tags: ["trend", "stop-loss", "remote"],
    dataType: "number",
    chartType: "overlay",
    isAsync: true
  },
  {
    id: "institutional_flow",
    name: "Institutional Net Flow",
    shortName: "Inst Flow",
    category: "Market/Funds",
    source: "remote",
    version: "0.9.0",
    description: "Tracks large block orders > $1M.",
    tags: ["volume", "smart-money", "remote"],
    dataType: "number",
    chartType: "oscillator",
    isAsync: true
  }
];
