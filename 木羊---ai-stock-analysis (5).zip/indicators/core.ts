
import { StockDataPoint } from '../types';
import { IndicatorDefinition } from './types';

// --- MATH HELPERS ---

const calculateSMA = (data: StockDataPoint[], period: number, key: string): StockDataPoint[] => {
  if (!data || data.length === 0) return [];
  return data.map((point, index, array) => {
    if (index < period - 1) return { ...point, [key]: null };
    const slice = array.slice(index - period + 1, index + 1);
    const sum = slice.reduce((acc, curr) => acc + (curr?.close || 0), 0);
    return { ...point, [key]: sum / period };
  });
};

const calculateEMA = (data: StockDataPoint[], period: number, key: string): StockDataPoint[] => {
  if (!data || data.length === 0) return [];
  const k = 2 / (period + 1);
  let prevEma = data[0]?.close || 0; 
  return data.map((point, index) => {
    if (index === 0) return { ...point, [key]: prevEma };
    const currentPrice = point?.close || 0;
    const ema = (currentPrice * k) + (prevEma * (1 - k));
    prevEma = ema;
    return { ...point, [key]: ema };
  });
};

const calculateRSI = (data: StockDataPoint[], period: number = 14): StockDataPoint[] => {
    if (!data || data.length <= period) return data.map(d => ({ ...d, rsi: null }));

    let gains = 0;
    let losses = 0;

    // Initial avg
    for(let i=1; i<=period; i++) {
        if (!data[i] || !data[i-1]) continue;
        const diff = data[i].close - data[i-1].close;
        if(diff >= 0) gains += diff;
        else losses += Math.abs(diff);
    }
    
    let avgGain = gains / period;
    let avgLoss = losses / period;

    return data.map((point, index) => {
        if (index <= period) return { ...point, rsi: null };
        if (!data[index-1]) return { ...point, rsi: null };
        
        const diff = point.close - data[index-1].close;
        const currentGain = diff > 0 ? diff : 0;
        const currentLoss = diff < 0 ? Math.abs(diff) : 0;
        
        avgGain = ((avgGain * (period - 1)) + currentGain) / period;
        avgLoss = ((avgLoss * (period - 1)) + currentLoss) / period;
        
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        const rsi = 100 - (100 / (1 + rs));
        
        return { ...point, rsi };
    });
};

const calculateMACD = (data: StockDataPoint[]): StockDataPoint[] => {
    if (!data || data.length === 0) return [];
    
    let e12 = data[0]?.close || 0;
    let e26 = data[0]?.close || 0;
    const k12 = 2/13; 
    const k26 = 2/27;
    const k9 = 2/10;

    const withMacdLine = data.map((p, i) => {
        if(i===0) return { ...p, macd: 0, macd_signal: 0, macd_hist: 0 };
        const price = p?.close || 0;
        e12 = (price * k12) + (e12 * (1 - k12));
        e26 = (price * k26) + (e26 * (1 - k26));
        const macd = e12 - e26;
        return { ...p, macd };
    });

    let e9 = withMacdLine[0]?.macd || 0;
    return withMacdLine.map((p, i) => {
        if (i===0) return p;
        const currentMacd = p.macd || 0;
        e9 = (currentMacd * k9) + (e9 * (1 - k9));
        return { ...p, macd_signal: e9, macd_hist: currentMacd - e9 };
    });
};

const calculateBollinger = (data: StockDataPoint[], period: number, mult: number): StockDataPoint[] => {
  if (!data || data.length === 0) return [];
  return data.map((point, index, array) => {
    if (index < period - 1) return { ...point, bb_upper: null, bb_lower: null };
    
    const slice = array.slice(index - period + 1, index + 1);
    const sum = slice.reduce((acc, curr) => acc + (curr?.close || 0), 0);
    const sma = sum / period;
    
    const squaredDiffs = slice.map(p => Math.pow((p?.close || 0) - sma, 2));
    const variance = squaredDiffs.reduce((acc, curr) => acc + curr, 0) / period;
    const stdDev = Math.sqrt(variance);

    return { 
      ...point, 
      bb_upper: sma + (stdDev * mult),
      bb_lower: sma - (stdDev * mult)
    };
  });
};

const mapVolume = (data: StockDataPoint[]): StockDataPoint[] => {
    if (!data) return [];
    return data.map(d => ({ ...d, vol: d.volume }));
};

// --- DEFINITIONS ---

export const sma20: IndicatorDefinition = {
    id: 'sma20',
    name: 'SMA 20',
    shortName: 'SMA(20)',
    category: 'Technical/Trend',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#fbbf24', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 20 }],
    calculate: (data, params) => calculateSMA(data, params?.period || 20, 'sma20')
};

export const sma50: IndicatorDefinition = {
    id: 'sma50',
    name: 'SMA 50',
    shortName: 'SMA(50)',
    category: 'Technical/Trend',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#3b82f6', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 50 }],
    calculate: (data, params) => calculateSMA(data, params?.period || 50, 'sma50')
};

export const ema20: IndicatorDefinition = {
    id: 'ema20',
    name: 'EMA 20',
    shortName: 'EMA(20)',
    category: 'Technical/Trend',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#ec4899', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 20 }],
    calculate: (data, params) => calculateEMA(data, params?.period || 20, 'ema20')
};

export const bollinger: IndicatorDefinition = {
    id: 'bollinger',
    name: 'Bollinger Bands',
    shortName: 'BB(20,2)',
    category: 'Technical/Volatility',
    source: 'built-in',
    dataType: 'number',
    chartType: 'overlay',
    defaultStyle: { color: '#a8a29e', lineWidth: 1, areaColor: 'rgba(168, 162, 158, 0.1)' },
    paramDefs: [
        { key: 'period', label: 'Period', type: 'number', default: 20 },
        { key: 'mult', label: 'Multiplier', type: 'number', default: 2 }
    ],
    calculate: (data, params) => calculateBollinger(data, params?.period || 20, params?.mult || 2)
};

export const rsi: IndicatorDefinition = {
    id: 'rsi',
    name: 'RSI (14)',
    shortName: 'RSI(14)',
    category: 'Technical/Oscillator',
    source: 'built-in',
    dataType: 'number',
    chartType: 'oscillator',
    defaultStyle: { color: '#8b5cf6', lineWidth: 2 },
    paramDefs: [{ key: 'period', label: 'Period', type: 'number', default: 14 }],
    calculate: (data, params) => calculateRSI(data, params?.period || 14)
};

export const macd: IndicatorDefinition = {
    id: 'macd',
    name: 'MACD (12,26,9)',
    shortName: 'MACD',
    category: 'Technical/Momentum',
    source: 'built-in',
    dataType: 'number',
    chartType: 'oscillator',
    defaultStyle: { color: '#10b981', lineWidth: 2 },
    calculate: (data) => calculateMACD(data)
};

export const vol: IndicatorDefinition = {
    id: 'vol',
    name: 'Volume',
    shortName: 'Vol',
    category: 'Market/Liquidity',
    source: 'built-in',
    dataType: 'number',
    unit: 'M',
    chartType: 'oscillator',
    defaultStyle: { color: '#26a69a', upColor: '#10b981', downColor: '#f43f5e' },
    calculate: (data) => mapVolume(data)
};
