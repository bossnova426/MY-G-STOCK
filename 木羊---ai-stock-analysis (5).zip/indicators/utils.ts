
import { StockDataPoint } from '../types';

export const calculateSMA = (data: StockDataPoint[], period: number, key: string): StockDataPoint[] => {
  if (!data || data.length === 0) return [];
  return data.map((point, index, array) => {
    if (index < period - 1) return { ...point, [key]: null };
    const slice = array.slice(index - period + 1, index + 1);
    const sum = slice.reduce((acc, curr) => acc + (curr?.close || 0), 0);
    return { ...point, [key]: sum / period };
  });
};

export const calculateEMA = (data: StockDataPoint[], period: number, key: string): StockDataPoint[] => {
  if (!data || data.length === 0) return [];
  const k = 2 / (period + 1);
  let prevEma = data[0]?.close || 0; 
  return data.map((point, index) => {
    if (index === 0) return { ...point, [key]: prevEma };
    const currentPrice = point?.close || 0;
    const ema = (currentPrice * k) + (prevEma * (1 - k));
    prevEma = ema;
    return { ...point, [key]: ema };
  });
};
