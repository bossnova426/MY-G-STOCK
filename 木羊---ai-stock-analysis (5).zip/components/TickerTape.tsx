
import React, { useState, useEffect, useRef } from 'react';
import { Settings, Plus, X, Play, Pause, GripVertical } from 'lucide-react';
import { createPortal } from 'react-dom';

interface MarketIndex {
    id: string;
    name: string;
    value: number;
    change: number;
    changePercent: number;
    turnover?: string; // e.g. "6758.13亿"
}

// Mock Data Generators
const generateMockQuote = (symbol: string): MarketIndex => {
    const baseValue = Math.random() * 3000 + 1000;
    const change = (Math.random() * 100) - 50;
    return {
        id: symbol,
        name: symbol.toUpperCase(),
        value: baseValue,
        change: change,
        changePercent: (change / baseValue) * 100,
        turnover: (Math.random() * 500).toFixed(0) + 'B'
    };
};

const DEFAULT_INDICES: MarketIndex[] = [
    { id: 'sh', name: '上证指数', value: 3052.14, change: 12.45, changePercent: 0.41, turnover: '3890亿' },
    { id: 'sz', name: '深证成指', value: 9450.30, change: -45.20, changePercent: -0.48, turnover: '5400亿' },
    { id: 'cy', name: '创业板指', value: 1850.60, change: -15.30, changePercent: -0.82, turnover: '2100亿' },
    { id: 'bj', name: '北证50', value: 890.12, change: 8.50, changePercent: 0.96, turnover: '85亿' },
    { id: 'spx', name: 'S&P 500', value: 5204.30, change: 24.10, changePercent: 0.46 },
    { id: 'ndx', name: 'Nasdaq', value: 16300.50, change: 150.20, changePercent: 0.93 },
    { id: 'hsi', name: '恒生指数', value: 16750.20, change: -80.50, changePercent: -0.48 },
    { id: 'btc', name: 'BTC/USD', value: 68500.00, change: 1200.00, changePercent: 1.78 },
];

export const TickerTape: React.FC = () => {
    const [indices, setIndices] = useState(DEFAULT_INDICES);
    const [isScrolling, setIsScrolling] = useState(true);
    const [isHovered, setIsHovered] = useState(false);
    
    // Settings State
    const [showSettings, setShowSettings] = useState(false);
    const [newSymbol, setNewSymbol] = useState('');
    const settingsButtonRef = useRef<HTMLButtonElement>(null);
    const [settingsPos, setSettingsPos] = useState({ top: 0, left: 0 });

    // Simulate live updates
    useEffect(() => {
        const interval = setInterval(() => {
            setIndices(prev => prev.map(idx => ({
                ...idx,
                value: idx.value + (Math.random() - 0.5) * 2,
                changePercent: idx.changePercent + (Math.random() - 0.5) * 0.01
            })));
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const toggleSettings = () => {
        if (!showSettings && settingsButtonRef.current) {
            const rect = settingsButtonRef.current.getBoundingClientRect();
            setSettingsPos({
                top: rect.top - 10, // Slightly above
                left: rect.left
            });
        }
        setShowSettings(!showSettings);
    };

    const handleAddSymbol = (e: React.FormEvent) => {
        e.preventDefault();
        if (newSymbol.trim()) {
            const newItem = generateMockQuote(newSymbol);
            setIndices(prev => [...prev, newItem]);
            setNewSymbol('');
        }
    };

    const handleRemoveSymbol = (id: string) => {
        setIndices(prev => prev.filter(i => i.id !== id));
    };

    // If scrolling, we duplicate list to make loop seamless. If static, just list once.
    const displayIndices = isScrolling ? [...indices, ...indices] : indices;

    return (
        <>
            <div 
                className="h-7 bg-slate-950 border-t border-slate-800 flex items-center relative select-none z-40"
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
            >
                <style>{`
                    @keyframes ticker {
                        0% { transform: translateX(0); }
                        100% { transform: translateX(-50%); }
                    }
                    .animate-ticker {
                        animation: ticker ${Math.max(20, indices.length * 5)}s linear infinite;
                    }
                    .pause-ticker {
                        animation-play-state: paused;
                    }
                `}</style>

                {/* Left label / Settings Button */}
                <div className="h-full bg-slate-900 border-r border-slate-800 flex items-center z-20 shadow-[4px_0_8px_rgba(0,0,0,0.5)] shrink-0">
                    <button 
                        ref={settingsButtonRef}
                        onClick={toggleSettings}
                        className="h-full px-2 flex items-center gap-1.5 hover:bg-slate-800 transition-colors group"
                        title="Configure Ticker"
                    >
                        <Settings className="w-3 h-3 text-slate-500 group-hover:text-indigo-400" />
                        <span className="text-[10px] font-bold text-slate-400 group-hover:text-indigo-400 uppercase">Quotes</span>
                    </button>
                </div>

                {/* Content Track */}
                <div className={`flex-1 overflow-hidden relative h-full flex items-center ${!isScrolling ? 'overflow-x-auto custom-scrollbar' : ''}`}>
                    <div className={`flex items-center h-full ${isScrolling ? (isHovered ? 'pause-ticker' : 'animate-ticker') : ''} whitespace-nowrap`}>
                        {displayIndices.map((idx, i) => {
                            const isUp = idx.changePercent >= 0;
                            const color = isUp ? 'text-rose-500' : 'text-emerald-500'; // CN Market Colors
                            const barColor = isUp ? 'bg-rose-500' : 'bg-emerald-500';
                            const widthPercent = Math.min(100, Math.abs(idx.changePercent) * 30); 

                            return (
                                <div key={`${idx.id}-${i}`} className="flex items-center gap-3 px-4 border-r border-slate-800/50 h-full shrink-0">
                                    <span className="text-xs text-slate-300 font-medium">{idx.name}</span>
                                    
                                    <div className={`flex items-center gap-1.5 ${color} font-mono text-xs`}>
                                        <span className="font-bold">{idx.value.toFixed(2)}</span>
                                        <span className="text-[10px]">{idx.change > 0 ? '+' : ''}{idx.changePercent.toFixed(2)}%</span>
                                    </div>

                                    {/* Mini Bar */}
                                    <div className="w-6 h-1 bg-slate-800 rounded-full overflow-hidden flex">
                                        {isUp ? (
                                            <>
                                                <div className="h-full flex-1"></div>
                                                <div className={`h-full ${barColor}`} style={{ width: `${widthPercent}%` }}></div>
                                            </>
                                        ) : (
                                            <>
                                                <div className={`h-full ${barColor}`} style={{ width: `${widthPercent}%` }}></div>
                                                <div className="h-full flex-1"></div>
                                            </>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                        {/* Empty spacer for static mode if list is short */}
                        {!isScrolling && <div className="w-4"></div>}
                    </div>
                </div>
            </div>

            {/* Settings Popover */}
            {showSettings && createPortal(
                <div 
                    className="fixed inset-0 z-[9998]" 
                    onClick={() => setShowSettings(false)}
                >
                    <div 
                        className="fixed bg-slate-900 border border-slate-700 rounded-lg shadow-2xl w-64 p-3 z-[9999] animate-in fade-in zoom-in-95 origin-bottom-left"
                        style={{ top: settingsPos.top - 200, left: settingsPos.left }} // Render above
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center mb-3 border-b border-slate-800 pb-2">
                            <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                                <Settings className="w-3.5 h-3.5" /> Ticker Config
                            </span>
                            <button onClick={() => setShowSettings(false)} className="text-slate-500 hover:text-white"><X className="w-3.5 h-3.5" /></button>
                        </div>

                        {/* Toggle Mode */}
                        <div className="flex bg-slate-800 p-1 rounded mb-3">
                            <button 
                                onClick={() => setIsScrolling(true)}
                                className={`flex-1 flex items-center justify-center gap-1.5 py-1 text-[10px] font-bold rounded transition-colors ${isScrolling ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
                            >
                                <Play className="w-3 h-3" /> Scroll
                            </button>
                            <button 
                                onClick={() => setIsScrolling(false)}
                                className={`flex-1 flex items-center justify-center gap-1.5 py-1 text-[10px] font-bold rounded transition-colors ${!isScrolling ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
                            >
                                <Pause className="w-3 h-3" /> Static
                            </button>
                        </div>

                        {/* Add Symbol */}
                        <form onSubmit={handleAddSymbol} className="flex gap-2 mb-3">
                            <input 
                                type="text" 
                                value={newSymbol}
                                onChange={e => setNewSymbol(e.target.value)}
                                placeholder="Add Symbol (e.g. AAPL)..."
                                className="flex-1 bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white outline-none focus:border-indigo-500 uppercase placeholder-slate-600"
                            />
                            <button type="submit" className="p-1 bg-slate-800 border border-slate-700 hover:bg-slate-700 text-indigo-400 rounded transition-colors">
                                <Plus className="w-4 h-4" />
                            </button>
                        </form>

                        {/* List Items */}
                        <div className="max-h-32 overflow-y-auto custom-scrollbar space-y-1">
                            {indices.map(idx => (
                                <div key={idx.id} className="flex justify-between items-center bg-slate-800/50 px-2 py-1.5 rounded group">
                                    <div className="flex items-center gap-2">
                                        <GripVertical className="w-3 h-3 text-slate-600 cursor-move" />
                                        <span className="text-xs text-slate-300 font-mono">{idx.name}</span>
                                    </div>
                                    <button 
                                        onClick={() => handleRemoveSymbol(idx.id)}
                                        className="text-slate-600 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                        <X className="w-3 h-3" />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>,
                document.body
            )}
        </>
    );
};
