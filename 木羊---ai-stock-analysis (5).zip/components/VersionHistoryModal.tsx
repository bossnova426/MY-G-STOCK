import React, { useState, useEffect } from 'react';
import { X, History, Save, RotateCcw, Trash2, Clock, GitCommit, Layout, List, Settings, CheckCircle } from 'lucide-react';
import { AppState, VersionCheckpoint } from '../types';
import { versionService } from '../services/versionService';

interface VersionHistoryModalProps {
    isOpen: boolean;
    onClose: () => void;
    currentState: AppState;
    onRestore: (state: AppState) => void;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({ isOpen, onClose, currentState, onRestore }) => {
    const [history, setHistory] = useState<VersionCheckpoint[]>([]);
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [newLabel, setNewLabel] = useState('');
    const [newDesc, setNewDesc] = useState('');

    useEffect(() => {
        if (isOpen) {
            refreshHistory();
        }
    }, [isOpen]);

    const refreshHistory = () => {
        setHistory(versionService.getHistory());
    };

    const handleCreateSnapshot = () => {
        const label = newLabel.trim() || `Manual Save ${new Date().toLocaleTimeString()}`;
        versionService.createCheckpoint('MANUAL', label, currentState, newDesc);
        setNewLabel('');
        setNewDesc('');
        refreshHistory();
    };

    const handleDelete = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        if (confirm("Delete this snapshot?")) {
            versionService.deleteCheckpoint(id);
            if (selectedId === id) setSelectedId(null);
            refreshHistory();
        }
    };

    const handleRestore = () => {
        const target = history.find(v => v.id === selectedId);
        if (target) {
            if (confirm(`Restore version "${target.label}"? Unsaved changes will be lost.`)) {
                onRestore(target.data);
                onClose();
            }
        }
    };

    if (!isOpen) return null;

    const selectedVersion = history.find(v => v.id === selectedId);

    return (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-4xl h-[600px] rounded-xl shadow-2xl flex overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                
                {/* Left Panel: History List */}
                <div className="w-1/3 border-r border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-col">
                    <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
                        <History className="w-5 h-5 text-indigo-500" />
                        <h2 className="font-bold text-slate-800 dark:text-slate-200">Version History</h2>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-2 space-y-2 custom-scrollbar">
                        {history.map(v => (
                            <div 
                                key={v.id}
                                onClick={() => setSelectedId(v.id)}
                                className={`p-3 rounded-lg cursor-pointer border transition-all relative group
                                    ${selectedId === v.id 
                                        ? 'bg-white dark:bg-slate-800 border-indigo-500 shadow-sm' 
                                        : 'bg-transparent border-transparent hover:bg-slate-200 dark:hover:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'}
                                `}
                            >
                                <div className="flex justify-between items-start mb-1">
                                    <div className="flex items-center gap-2">
                                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${v.type === 'MANUAL' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300' : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'}`}>
                                            {v.type}
                                        </span>
                                        <span className="text-xs text-slate-400">{new Date(v.timestamp).toLocaleTimeString()}</span>
                                    </div>
                                    <button onClick={(e) => handleDelete(e, v.id)} className="p-1 text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                                <div className="font-bold text-sm text-slate-700 dark:text-slate-200 truncate">{v.label}</div>
                                {v.description && <div className="text-xs text-slate-500 truncate mt-0.5">{v.description}</div>}
                            </div>
                        ))}
                        {history.length === 0 && (
                            <div className="text-center py-8 text-slate-400 text-xs">No snapshots available.</div>
                        )}
                    </div>
                </div>

                {/* Right Panel: Actions & Details */}
                <div className="flex-1 flex flex-col bg-white dark:bg-slate-900">
                    <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-800">
                        <h3 className="font-bold text-slate-800 dark:text-white">Snapshot Details</h3>
                        <button onClick={onClose} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-500"><X className="w-5 h-5" /></button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-6">
                        {/* Create New Section */}
                        <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-4 mb-6">
                            <h4 className="text-xs font-bold text-slate-500 uppercase mb-3 flex items-center gap-2">
                                <Save className="w-3.5 h-3.5" /> Create New Snapshot
                            </h4>
                            <div className="flex flex-col gap-3">
                                <input 
                                    type="text" 
                                    value={newLabel}
                                    onChange={e => setNewLabel(e.target.value)}
                                    placeholder="Version Name (e.g. Before Layout Change)"
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-3 py-2 text-sm outline-none focus:border-indigo-500"
                                />
                                <input 
                                    type="text" 
                                    value={newDesc}
                                    onChange={e => setNewDesc(e.target.value)}
                                    placeholder="Optional Description..."
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-3 py-2 text-sm outline-none focus:border-indigo-500"
                                />
                                <div className="flex justify-end">
                                    <button 
                                        onClick={handleCreateSnapshot}
                                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-bold shadow-sm transition-all flex items-center gap-2"
                                    >
                                        <GitCommit className="w-4 h-4" /> Save Version
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Selected Preview */}
                        {selectedVersion ? (
                            <div className="animate-in fade-in slide-in-from-bottom-2">
                                <h4 className="text-xs font-bold text-slate-500 uppercase mb-3 flex items-center gap-2">
                                    <Clock className="w-3.5 h-3.5" /> Selected Version Content
                                </h4>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
                                        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
                                            <Layout className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <div className="text-lg font-bold text-slate-800 dark:text-white">{selectedVersion.data.workspaces.length}</div>
                                            <div className="text-xs text-slate-500">Workspaces</div>
                                        </div>
                                    </div>
                                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
                                        <div className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg">
                                            <List className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <div className="text-lg font-bold text-slate-800 dark:text-white">{selectedVersion.data.watchlists.length}</div>
                                            <div className="text-xs text-slate-500">Watchlists</div>
                                        </div>
                                    </div>
                                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
                                        <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg">
                                            <CheckCircle className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <div className="text-lg font-bold text-slate-800 dark:text-white">{selectedVersion.data.savedScreens.length}</div>
                                            <div className="text-xs text-slate-500">Strategies</div>
                                        </div>
                                    </div>
                                    <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
                                        <div className="p-2 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg">
                                            <Settings className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <div className="text-lg font-bold text-slate-800 dark:text-white">{selectedVersion.data.settings.theme}</div>
                                            <div className="text-xs text-slate-500">Theme</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-200 text-xs rounded-lg border border-amber-100 dark:border-amber-900/30">
                                    Warning: Restoring this version will overwrite your current workspace layout and watchlists immediately.
                                </div>
                            </div>
                        ) : (
                            <div className="h-40 flex items-center justify-center text-slate-400 text-sm italic">
                                Select a snapshot from the left to view details.
                            </div>
                        )}
                    </div>

                    <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end gap-3">
                        <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white">Cancel</button>
                        <button 
                            onClick={handleRestore}
                            disabled={!selectedVersion}
                            className="px-6 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg text-sm font-bold shadow-lg shadow-rose-500/20 transition-all flex items-center gap-2"
                        >
                            <RotateCcw className="w-4 h-4" /> Restore Version
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};