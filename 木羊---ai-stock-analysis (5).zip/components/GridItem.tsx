
import React, { useState } from 'react';
import { Widget, WidgetConfigHistory } from '../types';
import { LinkGroupSelector } from './LinkGroupSelector';
import { Eye, EyeOff, X, ArrowLeftToLine, ArrowRightToLine, ArrowDownToLine, ArrowUpToLine, Layout } from 'lucide-react';

export interface GridItemProps {
    widget: Widget;
    children: React.ReactNode;
    onRemove: (id: string) => void;
    onUpdateWidget: (id: string, updates: Partial<Widget>) => void;
    isDragging: boolean;
    onDragStart: (e: React.MouseEvent, type: 'move' | 'resize') => void;
    onShowDocs: (id: string) => void;
    onRevertConfig: (id: string, historyItem: WidgetConfigHistory) => void;
    location: 'grid' | 'sidebar' | 'right' | 'bottom';
    onMoveLocation: (id: string, target: 'grid' | 'sidebar' | 'right' | 'bottom') => void;
    customTitle?: string;
}

export const GridItem: React.FC<GridItemProps> = ({ 
    widget, children, onRemove, onUpdateWidget, isDragging, onDragStart, onShowDocs, onRevertConfig, location, onMoveLocation, customTitle
}) => {
    const style: React.CSSProperties = location === 'grid' ? {
        gridColumn: `${widget.layout.x + 1} / span ${widget.layout.w}`,
        gridRow: `${widget.layout.y + 1} / span ${widget.layout.h}`,
        zIndex: isDragging ? 50 : 1
    } : (location === 'sidebar' || location === 'right') ? {
        height: `${Math.max(100, widget.layout.h * 20)}px`,
        marginBottom: '4px'
    } : {
        // Bottom location mapping w to pixel width
        width: `${Math.max(200, widget.layout.w * 25)}px`,
        height: '100%',
        flexShrink: 0
    };

    const displayTitle = customTitle || widget.title;

    return (
        <div 
            className={`relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden transition-shadow duration-200 group/widget 
            ${isDragging ? 'opacity-80 ring-2 ring-indigo-500' : ''}
            ${widget.hideHeader ? 'rounded-none shadow-none' : 'rounded-lg shadow-sm'} 
            `}
            style={style}
        >
            {!widget.hideHeader ? (
                <div 
                    className="h-7 flex items-center justify-between px-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 select-none shrink-0"
                    onMouseDown={(e) => {
                        if ((e.target as HTMLElement).closest('button')) return;
                        if (location === 'grid') onDragStart(e, 'move');
                    }}
                >
                    <div className="flex items-center gap-2 cursor-grab active:cursor-grabbing flex-1 min-w-0">
                        <LinkGroupSelector 
                            currentGroup={widget.linkGroup} 
                            onChange={(g) => onUpdateWidget(widget.id, { linkGroup: g })} 
                        />
                        <div className="h-3 w-px bg-slate-300 dark:bg-slate-700"></div>
                        <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider truncate">{displayTitle}</span>
                    </div>
                    <div className="flex items-center gap-1.5 relative">
                        {location === 'grid' && (
                            <>
                                <button onClick={() => onMoveLocation(widget.id, 'sidebar')} className="p-0.5 text-slate-400 hover:text-indigo-500 rounded"><ArrowLeftToLine className="w-3 h-3" /></button>
                                <button onClick={() => onMoveLocation(widget.id, 'right')} className="p-0.5 text-slate-400 hover:text-indigo-500 rounded"><ArrowRightToLine className="w-3 h-3" /></button>
                                <button onClick={() => onMoveLocation(widget.id, 'bottom')} className="p-0.5 text-slate-400 hover:text-indigo-500 rounded"><ArrowDownToLine className="w-3 h-3" /></button>
                            </>
                        )}
                        {(location === 'sidebar' || location === 'right' || location === 'bottom') && <button onClick={() => onMoveLocation(widget.id, 'grid')} className="p-0.5 text-slate-400 hover:text-indigo-500 rounded"><Layout className="w-3 h-3" /></button>}

                        <button onClick={() => onUpdateWidget(widget.id, { hideHeader: true })} className="p-0.5 text-slate-400 hover:text-indigo-500 rounded"><EyeOff className="w-3 h-3" /></button>
                        <button onClick={() => onRemove(widget.id)} className="p-0.5 text-slate-400 hover:text-rose-500 rounded"><X className="w-3 h-3" /></button>
                    </div>
                </div>
            ) : (
                <div className="absolute top-0 left-0 right-0 h-6 z-[60] group/trigger" onMouseDown={(e) => { if (location === 'grid' && !(e.target as HTMLElement).closest('button')) onDragStart(e, 'move'); }}>
                    <div className="absolute top-0 left-0 right-0 flex justify-between items-center bg-slate-900/90 backdrop-blur-md rounded-b-md px-2 py-1 shadow-lg opacity-0 group-hover/trigger:opacity-100 transition-opacity duration-200 border-b border-slate-700/50">
                         <div className="flex items-center gap-2">
                             <LinkGroupSelector currentGroup={widget.linkGroup} onChange={(g) => onUpdateWidget(widget.id, { linkGroup: g })} />
                             <span className="text-[10px] text-slate-300 font-bold uppercase truncate max-w-[80px]">{displayTitle}</span>
                         </div>
                         <div className="flex items-center gap-2 pointer-events-auto">
                             <button onClick={() => onUpdateWidget(widget.id, { hideHeader: false })} className="text-slate-400 hover:text-white transition-colors"><Eye className="w-3 h-3" /></button>
                             <button onClick={() => onRemove(widget.id)} className="text-slate-400 hover:text-rose-500 transition-colors"><X className="w-3 h-3" /></button>
                         </div>
                    </div>
                </div>
            )}
            <div className="flex-1 min-h-0 relative overflow-hidden bg-white dark:bg-slate-900">{children}</div>
            
            {/* --- Resize Handles (High Z-Index Fix) --- */}
            {/* 1. Main Grid Corner Handle */}
            {location === 'grid' && (
                <div 
                    className="absolute bottom-0 right-0 w-6 h-6 cursor-nwse-resize z-[100] group-hover/widget:opacity-100 opacity-0 transition-opacity"
                    onMouseDown={(e) => onDragStart(e, 'resize')}
                >
                    <div className="absolute bottom-1 right-1 w-3 h-3 border-r-2 border-b-2 border-indigo-500" />
                </div>
            )}

            {/* 2. Sidebars Vertical Handle */}
            {(location === 'sidebar' || location === 'right') && (
                <div 
                    className="absolute bottom-0 left-0 right-0 h-2 cursor-ns-resize z-[100] hover:bg-indigo-500/30 transition-colors opacity-0 group-hover/widget:opacity-100"
                    onMouseDown={(e) => onDragStart(e, 'resize')}
                />
            )}

            {/* 3. Bottom Panel Horizontal Handle */}
            {location === 'bottom' && (
                <div 
                    className="absolute top-0 bottom-0 right-0 w-2 cursor-ew-resize z-[100] hover:bg-indigo-500/30 transition-colors opacity-0 group-hover/widget:opacity-100"
                    onMouseDown={(e) => onDragStart(e, 'resize')}
                />
            )}
        </div>
    );
};
