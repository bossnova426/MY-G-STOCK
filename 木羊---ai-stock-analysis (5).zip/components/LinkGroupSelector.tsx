
import React, { useState } from 'react';
import { Link as LinkIcon, X } from 'lucide-react';

export const LINK_GROUPS = [
    { id: '1', color: 'bg-rose-500', border: 'border-rose-500' },
    { id: '2', color: 'bg-emerald-500', border: 'border-emerald-500' },
    { id: '3', color: 'bg-blue-500', border: 'border-blue-500' },
    { id: '4', color: 'bg-amber-500', border: 'border-amber-500' },
    { id: '5', color: 'bg-purple-500', border: 'border-purple-500' },
    { id: '6', color: 'bg-cyan-500', border: 'border-cyan-500' },
];

interface LinkGroupSelectorProps {
    currentGroup?: string;
    onChange: (g: string) => void;
}

export const LinkGroupSelector: React.FC<LinkGroupSelectorProps> = ({ currentGroup, onChange }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="relative pointer-events-auto">
            <button 
                onClick={(e) => { e.stopPropagation(); setIsOpen(!isOpen); }}
                className={`w-3 h-3 rounded-full border flex items-center justify-center transition-all ${currentGroup ? LINK_GROUPS.find(g => g.id === currentGroup)?.color : 'bg-transparent border-slate-400'}`}
                title="Link Group"
            >
                {!currentGroup && <LinkIcon className="w-2 h-2 text-slate-400" />}
            </button>
            {isOpen && (
                <>
                    <div className="fixed inset-0 z-[60]" onClick={() => setIsOpen(false)}></div>
                    <div className="absolute top-5 left-0 z-[70] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl rounded-lg p-1.5 flex gap-1 animate-in fade-in zoom-in-95">
                        <button onClick={() => { onChange(''); setIsOpen(false); }} className="w-4 h-4 rounded-full border border-slate-400 flex items-center justify-center hover:bg-slate-100"><X className="w-2 h-2" /></button>
                        {LINK_GROUPS.map(g => (
                            <button 
                                key={g.id}
                                onClick={() => { onChange(g.id); setIsOpen(false); }}
                                className={`w-4 h-4 rounded-full ${g.color} hover:ring-2 ring-offset-1 ring-offset-white dark:ring-offset-slate-900 ring-slate-400`}
                            />
                        ))}
                    </div>
                </>
            )}
        </div>
    );
};
