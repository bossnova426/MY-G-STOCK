
import React from 'react';
import { Copy, Terminal, CheckCircle, AlertTriangle, X } from 'lucide-react';

export const SetupGuide: React.FC = () => {
  const pythonCode = `
# server.py
# 依赖: pip install fastapi uvicorn kitetdx pandas
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from kitetdx import Reader, Quotes, SwsReader
import pandas as pd
import json

# --- 配置您的通达信目录 ---
TDX_DIR = 'D:/tdxkxg'  
# --------------------------

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

reader = None
client = None

try:
    reader = Reader.factory(market='std', tdxdir=TDX_DIR)
    print(f"✅ 本地数据加载成功")
except Exception as e:
    print(f"❌ 无法加载通达信目录: {e}")

try:
    client = Quotes.factory(market='std', multithread=True, heartbeat=True)
    print("✅ 行情服务器连接成功")
except Exception as e:
    print(f"❌ 无法连接行情服务器: {e}")

def get_market_code(symbol: str):
    if symbol.startswith('6'): return 1 # SH
    if symbol.startswith('0') or symbol.startswith('3'): return 0 # SZ
    if symbol.startswith('4') or symbol.startswith('8'): return 2 # BJ
    return 0

@app.get("/api/quote")
def get_quote(symbol: str):
    if not client: raise HTTPException(status_code=503, detail="Offline")
    try:
        df = client.security_quotes([(get_market_code(symbol), symbol)])
        if df is None or len(df) == 0: raise HTTPException(status_code=404)
        row = df[0]
        return {
            "symbol": row['code'],
            "name": "Unknown",
            "price": float(row['price']),
            "change": float(row['price']) - float(row['last_close']),
            "changePercent": (float(row['price']) - float(row['last_close'])) / float(row['last_close']) * 100 if float(row['last_close']) > 0 else 0,
            "volume": int(row['vol']),
            "open": float(row['open']),
            "high": float(row['high']),
            "low": float(row['low']),
            "prev_close": float(row['last_close'])
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/history")
def get_history(symbol: str, days: int = 100):
    data = []
    if reader:
        try:
            df = reader.daily(symbol=symbol)
            if not df.empty:
                for _, row in df.tail(days).iterrows():
                    data.append({
                        "date": str(row['date']),
                        "open": float(row['open']), "high": float(row['high']),
                        "low": float(row['low']), "close": float(row['close']),
                        "volume": float(row['volume'])
                    })
                return data
        except: pass
    return data

@app.get("/api/sys_data")
def get_sys_data():
    """
    返回系统列表结构:
    1. System/Markets (行情)
    2. System/Blocks/Concepts (概念)
    3. System/Industries/TDX (通达信行业)
    4. System/Industries/SWS (申万行业)
    """
    lists = []
    
    # 1. Markets
    markets = {1: 'Shanghai', 0: 'Shenzhen', 2: 'Beijing'}
    if client:
        for mid, mname in markets.items():
            try:
                df = client.stocks(market=mid)
                stocks = []
                for _, row in df.head(50).iterrows():
                    stocks.append({
                        "symbol": str(row['code']),
                        "name": str(row['name']) if 'name' in row else str(row['code']),
                        "price": float(row['pre_close']) if 'pre_close' in row else 0,
                        "change": 0, "changePercent": 0, "vol": 0
                    })
                lists.append({
                    "id": f"sys_mkt_{mid}",
                    "name": f"System/Markets/{mname}",
                    "stocks": stocks,
                    "readOnly": True
                })
            except: pass

    # 2. Blocks (Concepts)
    if reader:
        try:
            blocks = reader.block(concept_type='GN')
            for b in blocks[:10]: 
                stocks = []
                for s in b.stocks[:20]:
                    stocks.append({"symbol": s['code'], "name": "Stock", "price": 0, "change": 0, "vol": 0})
                lists.append({
                    "id": f"sys_blk_gn_{b.concept_code}",
                    "name": f"System/Blocks/Concepts/{b.concept_name}",
                    "stocks": stocks,
                    "readOnly": True
                })
        except: pass

        # 3. Industries (TDX Level 1)
        try:
            df_tdx = reader.get_industries(source='tdx', level=1)
            for _, row in df_tdx.head(10).iterrows():
                ind_name = row['industry_name']
                ind_code = row['industry_code']
                # 获取成分股
                stock_codes = reader.get_industry_stocks(ind_code, source='tdx')
                stocks = []
                for code in stock_codes[:20]:
                    stocks.append({"symbol": code, "name": "Stock", "price": 0, "change": 0, "vol": 0})
                
                lists.append({
                    "id": f"sys_ind_tdx_{ind_code}",
                    "name": f"System/Industries/TDX/{ind_name}",
                    "stocks": stocks,
                    "readOnly": True
                })
        except Exception as e:
            print(f"TDX Ind Error: {e}")

    # 4. Industries (SWS Level 1)
    try:
        sws = SwsReader(auto_download=False) # 设为True可自动下载最新数据
        df_sws = sws.get_industries(level=1)
        for _, row in df_sws.head(10).iterrows():
            ind_name = row['industry_name']
            ind_code = row['industry_code']
            stock_codes = sws.get_industry_stocks(ind_name)
            stocks = []
            for code in stock_codes[:20]:
                stocks.append({"symbol": code, "name": "Stock", "price": 0, "change": 0, "vol": 0})

            lists.append({
                "id": f"sys_ind_sws_{ind_code}",
                "name": f"System/Industries/SWS/{ind_name}",
                "stocks": stocks,
                "readOnly": True
            })
    except Exception as e:
        print(f"SWS Ind Error: {e}")

    return lists

if __name__ == "__main__":
    import uvicorn
    print("🚀 Bridge Server Running on port 8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
  `;

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonCode);
    alert("Python code copied to clipboard!");
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-hidden">
      <div className="p-6 max-w-4xl mx-auto w-full overflow-y-auto custom-scrollbar">
        
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-2">
            <Terminal className="w-6 h-6 text-indigo-500" />
            本地数据桥接指南 (KiteTDX)
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            本服务器脚本已更新以支持 <strong>申万 (SWS)</strong> 和 <strong>通达信 (TDX)</strong> 行业数据获取。
          </p>
        </div>

        <div className="grid gap-6">
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5 shadow-sm">
            <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200 mb-3 flex items-center gap-2">
              <span className="bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 w-6 h-6 rounded-full flex items-center justify-center text-sm">1</span>
              Server Code (server.py)
            </h3>
            <div className="relative">
                <div className="bg-slate-900 rounded-lg p-4 font-mono text-xs text-slate-300 overflow-x-auto border border-slate-800">
                    <pre>{pythonCode}</pre>
                </div>
                <button 
                    onClick={handleCopy}
                    className="absolute top-2 right-2 flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-indigo-600 text-slate-300 rounded text-xs transition-all"
                >
                    <Copy className="w-3 h-3" /> Copy
                </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
