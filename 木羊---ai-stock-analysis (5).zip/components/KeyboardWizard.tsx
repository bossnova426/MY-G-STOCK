
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Search, Zap, Hash, Layers, X, Layout } from 'lucide-react';
import { CustomWatchlist, IndicatorDefinition, Workspace } from '../types';
import { INDICATOR_REGISTRY } from '../services/indicatorService';
import { dataService } from '../services/dataAdapter';

interface KeyboardWizardProps {
    isOpen: boolean;
    initialChar: string;
    onClose: () => void;
    onSelect: (item: SearchResult, groupId?: string) => void;
    watchlists: CustomWatchlist[];
    workspaces: Workspace[];
    onSwitchWorkspace: (id: string) => void;
}

export interface SearchResult {
    id: string;
    label: string; // Main text (Symbol or Formula Name)
    desc: string;  // Sub text (Name or Description)
    type: 'STOCK' | 'INDICATOR' | 'SECTOR' | 'WORKSPACE';
    category: string; // For right column (Exchange or Category)
}

export const KeyboardWizard: React.FC<KeyboardWizardProps> = ({ 
    isOpen, 
    initialChar, 
    onClose, 
    onSelect, 
    watchlists,
    workspaces,
    onSwitchWorkspace
}) => {
    const [input, setInput] = useState(initialChar);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [remoteResults, setRemoteResults] = useState<SearchResult[]>([]);
    const inputRef = useRef<HTMLInputElement>(null);

    // Initial focus and input value setup
    useEffect(() => {
        if (isOpen) {
            setInput(initialChar);
            setRemoteResults([]); // Clear previous results
            // Wait for render to focus
            setTimeout(() => {
                inputRef.current?.focus();
            }, 10);
        }
    }, [isOpen, initialChar]);

    // --- Remote Search (Debounced) ---
    useEffect(() => {
        const timer = setTimeout(async () => {
            if (input.trim().length >= 2 && !input.startsWith('.')) {
                try {
                    const res = await dataService.searchSymbols(input);
                    if (res && Array.isArray(res)) {
                        const mapped: SearchResult[] = res.map(s => ({
                            id: s.symbol,
                            label: s.symbol,
                            desc: s.name,
                            type: 'STOCK',
                            category: s.sector || 'Remote'
                        }));
                        setRemoteResults(mapped);
                    }
                } catch (e) {
                    console.warn("Remote search failed", e);
                }
            } else {
                setRemoteResults([]);
            }
        }, 300); // 300ms debounce

        return () => clearTimeout(timer);
    }, [input]);

    // --- Search Logic ---
    const results = useMemo(() => {
        if (!input.trim()) return [];

        const query = input.toUpperCase().trim();
        
        // 0. Workspace Switching Command (.XXX)
        if (query.startsWith('.')) {
            const searchName = query.substring(1); // Remove dot
            const matches: SearchResult[] = [];
            
            // If just dot, show all workspaces, otherwise filter
            workspaces.forEach(ws => {
                if (!searchName || ws.name.toUpperCase().includes(searchName)) {
                    matches.push({
                        id: ws.id,
                        label: ws.name,
                        desc: 'Switch Workspace',
                        type: 'WORKSPACE',
                        category: 'View'
                    });
                }
            });
            return matches;
        }

        // Check for trailing number (Group ID) e.g., "NVDA 2"
        const parts = query.match(/^(.+?)(?:\s+(\d+))?$/);
        const searchText = parts ? parts[1] : query;
        
        const localMatches: SearchResult[] = [];

        // 1. Indicators (Formulas)
        INDICATOR_REGISTRY.forEach(ind => {
            if (ind.id.toUpperCase().includes(searchText) || ind.shortName.toUpperCase().includes(searchText) || ind.name.toUpperCase().includes(searchText)) {
                localMatches.push({
                    id: ind.id,
                    label: ind.shortName,
                    desc: ind.name,
                    type: 'INDICATOR',
                    category: '公式 (Formula)'
                });
            }
        });

        // 2. Stocks & Sectors (Flatten Watchlists)
        const seen = new Set<string>();
        
        // Optimization: Only search user-created watchlists locally.
        // System boards (which can be 6000+) are handled by remote search to prevent UI lag.
        const userWatchlists = watchlists.filter(l => !l.readOnly);
        
        userWatchlists.forEach(list => {
            // Check if list itself matches (Sector/Board)
            const listName = list.name.split('/').pop() || list.name;
            if (listName.toUpperCase().includes(searchText)) {
                localMatches.push({
                    id: list.id, // ID of the watchlist
                    label: listName,
                    desc: '板块 (Sector)',
                    type: 'SECTOR',
                    category: 'Custom'
                });
            }

            list.stocks.forEach(stock => {
                if (seen.has(stock.symbol)) return;
                
                // Match Symbol or Name
                if (stock.symbol.includes(searchText) || (stock.name && stock.name.toUpperCase().includes(searchText))) {
                    localMatches.push({
                        id: stock.symbol,
                        label: stock.symbol,
                        desc: stock.name || '',
                        type: 'STOCK',
                        category: stock.sector || 'Stock'
                    });
                    seen.add(stock.symbol);
                }
            });
        });

        // 3. Merge Remote Results (Deduplicate)
        const combined = [...localMatches];
        remoteResults.forEach(r => {
            if (!seen.has(r.id)) {
                combined.push(r);
                seen.add(r.id);
            }
        });

        // Priority Sort: Exact Symbol > Startswith Symbol > Indicator > Contains
        return combined.sort((a, b) => {
            const aExact = a.label === searchText;
            const bExact = b.label === searchText;
            if (aExact && !bExact) return -1;
            if (!aExact && bExact) return 1;

            const aStart = a.label.startsWith(searchText);
            const bStart = b.label.startsWith(searchText);
            if (aStart && !bStart) return -1;
            if (!aStart && bStart) return 1;

            return 0;
        }).slice(0, 15); // Limit items (increased slightly for remote)
    }, [input, watchlists, workspaces, remoteResults]);

    // Reset selection when results change
    useEffect(() => {
        setSelectedIndex(0);
    }, [results]);

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setSelectedIndex(prev => (prev + 1) % results.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            confirmSelection();
        } else if (e.key === 'Escape') {
            e.preventDefault();
            onClose();
        }
    };

    const confirmSelection = (index = selectedIndex) => {
        const item = results[index];
        if (item) {
            if (item.type === 'WORKSPACE') {
                onSwitchWorkspace(item.id);
            } else {
                // Parse Group ID from input (e.g. "NVDA 2")
                const match = input.match(/\s+(\d+)$/);
                // FIX: Only assign group ID if user explicitly typed a number
                const groupId = match ? match[1] : undefined; 
                onSelect(item, groupId);
            }
            onClose();
        }
    };

    if (!isOpen) return null;

    return createPortal(
        <div className="fixed bottom-0 right-0 z-[10000] p-4 flex flex-col justify-end items-end pointer-events-none">
            <div className="bg-white dark:bg-slate-900 border border-indigo-500 shadow-2xl rounded-lg w-[400px] overflow-hidden pointer-events-auto animate-in slide-in-from-bottom-5 duration-200">
                {/* Header / Input */}
                <div className="bg-indigo-600 p-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Search className="text-white w-4 h-4" />
                        <span className="text-white font-bold text-sm">键盘精灵 (Keyboard Wizard)</span>
                    </div>
                    <button 
                        onClick={onClose}
                        className="text-white/70 hover:text-white hover:bg-indigo-500 rounded p-1 transition-colors"
                    >
                        <X className="w-4 h-4" />
                    </button>
                </div>
                <div className="p-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                    <input 
                        ref={inputRef}
                        type="text" 
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        className="w-full bg-transparent outline-none text-slate-800 dark:text-white font-mono text-lg font-bold uppercase placeholder-slate-400"
                        placeholder="Code / Name / .Workspace"
                        autoComplete="off"
                    />
                </div>

                {/* Results List */}
                <div className="max-h-[300px] overflow-y-auto">
                    {results.length === 0 ? (
                        <div className="p-4 text-center text-slate-400 text-xs">
                            {input.length < 2 ? "Type at least 2 characters..." : "No matches found."}
                        </div>
                    ) : (
                        <table className="w-full text-left text-xs border-collapse">
                            <thead className="bg-slate-100 dark:bg-slate-950 text-slate-500 font-medium">
                                <tr>
                                    <th className="p-2 w-24">Code</th>
                                    <th className="p-2">Name / Description</th>
                                    <th className="p-2 text-right">Category</th>
                                </tr>
                            </thead>
                            <tbody>
                                {results.map((res, i) => {
                                    const isSelected = i === selectedIndex;
                                    return (
                                        <tr 
                                            key={`${res.id}-${i}`}
                                            onClick={() => confirmSelection(i)}
                                            onMouseEnter={() => setSelectedIndex(i)}
                                            className={`cursor-pointer transition-colors ${isSelected ? 'bg-indigo-600 text-white' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                                        >
                                            <td className="p-2 font-mono font-bold flex items-center gap-1">
                                                {res.type === 'WORKSPACE' && <Layout className={`w-3 h-3 ${isSelected ? 'text-pink-300' : 'text-pink-500'}`} />}
                                                {res.type === 'INDICATOR' && <Zap className={`w-3 h-3 ${isSelected ? 'text-yellow-300' : 'text-amber-500'}`} />}
                                                {res.type === 'SECTOR' && <Layers className={`w-3 h-3 ${isSelected ? 'text-indigo-200' : 'text-blue-500'}`} />}
                                                {res.type === 'STOCK' && <Hash className={`w-3 h-3 ${isSelected ? 'text-slate-300' : 'text-slate-400'}`} />}
                                                {res.label}
                                            </td>
                                            <td className="p-2">
                                                {res.desc}
                                            </td>
                                            <td className={`p-2 text-right ${isSelected ? 'text-indigo-200' : 'text-slate-400'}`}>
                                                {res.category}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    )}
                </div>
                
                {/* Footer Hint */}
                <div className="bg-slate-100 dark:bg-slate-950 px-2 py-1 text-[10px] text-slate-400 flex justify-between">
                    <span>Type "." to search Workspaces</span>
                    <span>Suffix number to target Group (e.g., "NVDA 2")</span>
                </div>
            </div>
        </div>,
        document.body
    );
};
