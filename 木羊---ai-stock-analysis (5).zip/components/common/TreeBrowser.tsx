import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Folder, FileText, MoreHorizontal, FolderOpen, Search, Plus } from 'lucide-react';

export interface TreeNode {
  id: string;
  label: string;
  type: 'folder' | 'item';
  icon?: React.ElementType; // Optional custom icon
  color?: string; // Optional custom color class
  data?: any; // Original data object
  children?: TreeNode[];
  isExpanded?: boolean;
}

interface TreeBrowserProps {
  data: TreeNode[];
  onSelect?: (node: TreeNode) => void;
  onAction?: (node: TreeNode, action: string) => void; // For context menu actions
  enableSearch?: boolean;
  selectedId?: string;
  emptyMessage?: string;
}

export const TreeBrowser: React.FC<TreeBrowserProps> = ({ 
  data, 
  onSelect, 
  onAction,
  enableSearch = true,
  selectedId,
  emptyMessage = "No items found"
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());

  const toggleNode = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Filter logic
  const filterNodes = (nodes: TreeNode[]): TreeNode[] => {
    if (!searchTerm) return nodes;
    return nodes.reduce<TreeNode[]>((acc, node) => {
      if (node.type === 'folder' && node.children) {
        const filteredChildren = filterNodes(node.children);
        if (filteredChildren.length > 0 || node.label.toLowerCase().includes(searchTerm.toLowerCase())) {
          acc.push({ ...node, children: filteredChildren, isExpanded: true }); // Auto expand on search
        }
      } else if (node.label.toLowerCase().includes(searchTerm.toLowerCase())) {
        acc.push(node);
      }
      return acc;
    }, []);
  };

  const displayData = searchTerm ? filterNodes(data) : data;

  const renderTree = (nodes: TreeNode[], depth = 0) => {
    return nodes.map(node => {
      const isExpanded = searchTerm ? true : expandedNodes.has(node.id);
      const isSelected = selectedId === node.id;
      const hasChildren = node.children && node.children.length > 0;

      // Icon Logic
      let Icon = node.icon;
      if (!Icon) {
          Icon = node.type === 'folder' ? (isExpanded ? FolderOpen : Folder) : FileText;
      }
      
      // Default Colors matching the screenshot (Yellow/Gold for folders)
      const iconColor = node.color || (node.type === 'folder' ? 'text-amber-500' : 'text-blue-400');

      return (
        <div key={node.id} className="select-none">
          <div 
            className={`
              flex items-center gap-1.5 px-2 py-1.5 cursor-pointer transition-colors border-l-2
              ${isSelected ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-500' : 'border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'}
            `}
            style={{ paddingLeft: `${depth * 16 + 8}px` }}
            onClick={(e) => {
                if (node.type === 'folder') toggleNode(node.id, e);
                if (onSelect) onSelect(node);
            }}
          >
            {/* Expander Arrow */}
            <div className="w-4 h-4 flex items-center justify-center shrink-0">
               {node.type === 'folder' && (
                   hasChildren || !searchTerm ? (
                       isExpanded ? <ChevronDown className="w-3 h-3 text-slate-400" /> : <ChevronRight className="w-3 h-3 text-slate-400" />
                   ) : null
               )}
            </div>

            {/* Icon */}
            <Icon className={`w-4 h-4 ${iconColor}`} />

            {/* Label */}
            <span className={`text-xs truncate flex-1 ${isSelected ? 'font-bold text-indigo-700 dark:text-indigo-300' : 'text-slate-700 dark:text-slate-300'}`}>
                {node.label}
            </span>

            {/* Context Action (Hover) */}
            {onAction && (
                <button 
                    onClick={(e) => { e.stopPropagation(); onAction(node, 'menu'); }}
                    className="p-1 opacity-0 group-hover:opacity-100 hover:text-slate-900 dark:hover:text-white text-slate-400 transition-opacity"
                >
                    <MoreHorizontal className="w-3.5 h-3.5" />
                </button>
            )}
          </div>

          {/* Children */}
          {isExpanded && node.children && (
            <div className="border-l border-slate-200 dark:border-slate-800 ml-[15px]"> 
               {/* ^ Visual Indentation Line */}
               {renderTree(node.children, depth + 1)}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-hidden w-full">
      {enableSearch && (
        <div className="p-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 sticky top-0 z-10 shrink-0">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search tree..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md pl-8 pr-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 outline-none focus:border-indigo-500 transition-all"
            />
          </div>
        </div>
      )}
      <div className="flex-1 overflow-y-auto custom-scrollbar py-1 group min-h-0 w-full">
        {displayData.length > 0 ? renderTree(displayData) : (
            <div className="p-4 text-center text-xs text-slate-400 italic">{emptyMessage}</div>
        )}
      </div>
    </div>
  );
};