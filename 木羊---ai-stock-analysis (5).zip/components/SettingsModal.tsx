
import React, { useState } from 'react';
import { X, Sliders, Monitor, BarChart, List, Layout, RefreshCw, Moon, Sun, Languages, Database, CheckCircle, AlertCircle } from 'lucide-react';
import { AppSettings, ModuleSettings } from '../types';
import { DEFAULT_SETTINGS, I18N } from '../constants';
import { dataService } from '../services/dataAdapter';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (newSettings: AppSettings) => void;
}

type Category = 'General' | 'Chart' | 'Watchlist' | 'System' | 'Data';

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave }) => {
  if (!isOpen) return null;

  const [activeCategory, setActiveCategory] = useState<Category>('General');
  
  // Local state for editing before save
  const [tempSettings, setTempSettings] = useState<AppSettings>(settings);
  
  // Test connection state
  const [testStatus, setTestStatus] = useState<'idle' | 'success' | 'error'>('idle');
  
  const t = I18N[tempSettings.language];

  // Helper to deep update settings
  const update = (key: keyof AppSettings, value: any) => {
      setTempSettings(prev => ({ ...prev, [key]: value }));
  };

  const updateModule = (module: keyof ModuleSettings, key: string, value: any) => {
      setTempSettings(prev => ({
          ...prev,
          modules: {
              ...prev.modules,
              [module]: {
                  ...prev.modules[module],
                  [key]: value
              }
          }
      }));
  };

  const updateData = (key: string, value: any) => {
      setTempSettings(prev => ({
          ...prev,
          data: {
              ...prev.data,
              [key]: value
          }
      }));
      setTestStatus('idle'); // Reset test status on change
  };

  const handleSave = () => {
      onSave(tempSettings);
      // Re-configure data service immediately
      dataService.configure(tempSettings.data);
      onClose();
  };

  const restoreDefaults = () => {
      if(confirm('Restore all settings to default?')) {
          setTempSettings(DEFAULT_SETTINGS);
      }
  };

  const testApiConnection = async () => {
      if (tempSettings.data.provider === 'mock') {
          setTestStatus('success');
          return;
      }
      try {
          // Simple ping via fetch
          const res = await fetch(tempSettings.data.apiBaseUrl, { method: 'HEAD', mode: 'no-cors' });
          // Note: no-cors opaque response is enough to verify server reachability roughly, 
          // or we assume success if no network error thrown.
          setTestStatus('success');
      } catch (e) {
          console.error(e);
          setTestStatus('error');
      }
  };

  const categories: { id: Category; label: string; icon: React.ElementType }[] = [
      { id: 'General', label: t.appearance, icon: Layout },
      { id: 'Data', label: t.dataSource, icon: Database },
      { id: 'System', label: t.system, icon: Monitor },
      { id: 'Chart', label: t.chart, icon: BarChart },
      { id: 'Watchlist', label: t.watchlist, icon: List },
  ];

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 w-full max-w-4xl h-[600px] rounded-xl shadow-2xl flex overflow-hidden">
        
        {/* Sidebar */}
        <div className="w-56 bg-slate-50 dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 flex flex-col">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
                <Sliders className="w-5 h-5 text-primary" />
                <span className="font-bold text-slate-800 dark:text-white">{t.settings}</span>
            </div>
            <div className="flex-1 p-2 space-y-1">
                {categories.map(cat => (
                    <button
                        key={cat.id}
                        onClick={() => setActiveCategory(cat.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors ${activeCategory === cat.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                    >
                        <cat.icon className="w-4 h-4" />
                        {cat.label}
                    </button>
                ))}
            </div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800">
                <button onClick={restoreDefaults} className="flex items-center gap-2 text-xs text-slate-500 hover:text-rose-500 transition-colors">
                    <RefreshCw className="w-3 h-3" /> Restore Defaults
                </button>
            </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col bg-white dark:bg-slate-900">
            <div className="h-14 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 bg-slate-50/50 dark:bg-slate-800/50">
                <h2 className="text-lg font-bold text-slate-800 dark:text-white">{categories.find(c => c.id === activeCategory)?.label} {t.settings}</h2>
                <button onClick={onClose} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white">
                    <X className="w-5 h-5" />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                {activeCategory === 'General' && (
                    <div className="space-y-8 max-w-lg">
                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Global UI</h3>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">{t.language}</label>
                                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700 w-fit">
                                        <button 
                                            onClick={() => update('language', 'en')}
                                            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium transition-all ${tempSettings.language === 'en' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-500'}`}
                                        >
                                            <Languages className="w-3.5 h-3.5" /> English
                                        </button>
                                        <button 
                                            onClick={() => update('language', 'zh')}
                                            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium transition-all ${tempSettings.language === 'zh' ? 'bg-white dark:bg-slate-600 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-500'}`}
                                        >
                                            <span className="font-bold text-[10px]">中</span> 中文
                                        </button>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">{t.theme}</label>
                                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700 w-fit">
                                        <button 
                                            onClick={() => update('theme', 'light')}
                                            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium transition-all ${tempSettings.theme === 'light' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-500'}`}
                                        >
                                            <Sun className="w-3.5 h-3.5" /> Light
                                        </button>
                                        <button 
                                            onClick={() => update('theme', 'dark')}
                                            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium transition-all ${tempSettings.theme === 'dark' ? 'bg-white dark:bg-slate-600 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-500'}`}
                                        >
                                            <Moon className="w-3.5 h-3.5" /> Dark
                                        </button>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">{t.fontSize}</label>
                                    <select 
                                        value={tempSettings.fontSize}
                                        onChange={(e) => update('fontSize', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    >
                                        <option value="small">Compact (Small)</option>
                                        <option value="medium">Standard (Medium)</option>
                                        <option value="large">Presentation (Large)</option>
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Accent Color</label>
                                    <div className="flex items-center gap-3">
                                        <input 
                                            type="color" 
                                            value={tempSettings.accentColor}
                                            onChange={(e) => update('accentColor', e.target.value)}
                                            className="w-8 h-8 rounded cursor-pointer bg-transparent border-none p-0"
                                        />
                                        <span className="text-xs font-mono text-slate-500">{tempSettings.accentColor}</span>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                )}

                {activeCategory === 'Data' && (
                    <div className="space-y-8 max-w-lg">
                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Provider Config</h3>
                            <div className="mb-4 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-200 p-3 rounded-lg text-xs">
                                {t.dataNote}
                            </div>
                            <div className="space-y-4">
                                <div className="grid grid-cols-1 gap-2">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">{t.provider}</label>
                                    <select 
                                        value={tempSettings.data.provider}
                                        onChange={(e) => updateData('provider', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-2 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none w-full"
                                    >
                                        <option value="mock">{t.providerMock}</option>
                                        <option value="rest_api">{t.providerRest}</option>
                                        <option value="kitetdx">{t.providerKite}</option>
                                    </select>
                                </div>

                                {tempSettings.data.provider !== 'mock' && (
                                    <>
                                        <div className="grid grid-cols-1 gap-2">
                                            <label className="text-sm text-slate-600 dark:text-slate-300">{t.apiBaseUrl}</label>
                                            <input 
                                                type="text" 
                                                value={tempSettings.data.apiBaseUrl}
                                                onChange={(e) => updateData('apiBaseUrl', e.target.value)}
                                                placeholder="http://127.0.0.1:8000"
                                                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-2 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none w-full font-mono"
                                            />
                                        </div>
                                        <div className="grid grid-cols-1 gap-2">
                                            <label className="text-sm text-slate-600 dark:text-slate-300">{t.apiKey}</label>
                                            <input 
                                                type="password" 
                                                value={tempSettings.data.apiKey || ''}
                                                onChange={(e) => updateData('apiKey', e.target.value)}
                                                placeholder="sk-..."
                                                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-2 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none w-full font-mono"
                                            />
                                        </div>
                                        <div className="flex items-center justify-between pt-2">
                                            <button 
                                                onClick={testApiConnection}
                                                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors"
                                            >
                                                {t.testConnection}
                                            </button>
                                            {testStatus === 'success' && <span className="text-xs text-emerald-500 font-bold flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Connected</span>}
                                            {testStatus === 'error' && <span className="text-xs text-rose-500 font-bold flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Failed</span>}
                                        </div>
                                    </>
                                )}
                            </div>
                        </section>
                    </div>
                )}

                {activeCategory === 'Chart' && (
                    <div className="space-y-8 max-w-lg">
                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Candlestick & Line</h3>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Stroke Width</label>
                                    <div className="flex items-center gap-3">
                                        <input 
                                            type="range" min="1" max="5" step="0.5"
                                            value={tempSettings.modules.chart.strokeWidth}
                                            onChange={(e) => updateModule('chart', 'strokeWidth', parseFloat(e.target.value))}
                                            className="accent-indigo-500 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer flex-1"
                                        />
                                        <span className="text-xs font-mono text-slate-400 w-8">{tempSettings.modules.chart.strokeWidth}px</span>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Bullish Color</label>
                                    <div className="flex items-center gap-3">
                                        <input 
                                            type="color" 
                                            value={tempSettings.modules.chart.upColor}
                                            onChange={(e) => updateModule('chart', 'upColor', e.target.value)}
                                            className="w-full h-8 rounded cursor-pointer bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-0.5"
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Bearish Color</label>
                                    <div className="flex items-center gap-3">
                                        <input 
                                            type="color" 
                                            value={tempSettings.modules.chart.downColor}
                                            onChange={(e) => updateModule('chart', 'downColor', e.target.value)}
                                            className="w-full h-8 rounded cursor-pointer bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-0.5"
                                        />
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Layout</h3>
                            <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/30 rounded border border-slate-200 dark:border-slate-800">
                                <span className="text-sm text-slate-600 dark:text-slate-300">Show Background Grid</span>
                                <input 
                                    type="checkbox" 
                                    checked={tempSettings.modules.chart.showGrid}
                                    onChange={(e) => updateModule('chart', 'showGrid', e.target.checked)}
                                    className="w-5 h-5 accent-indigo-500 rounded focus:ring-0"
                                />
                            </div>
                        </section>
                    </div>
                )}

                {activeCategory === 'Watchlist' && (
                     <div className="space-y-8 max-w-lg">
                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Appearance</h3>
                            <div className="space-y-4">
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Header Font Size</label>
                                    <select 
                                        value={tempSettings.modules.watchlist.fontSizeHead}
                                        onChange={(e) => updateModule('watchlist', 'fontSizeHead', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    >
                                        <option value="small">Small (Compact)</option>
                                        <option value="medium">Medium (Standard)</option>
                                        <option value="large">Large (Readable)</option>
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Row Font Size</label>
                                    <select 
                                        value={tempSettings.modules.watchlist.fontSizeRow}
                                        onChange={(e) => updateModule('watchlist', 'fontSizeRow', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    >
                                        <option value="small">Small (Compact)</option>
                                        <option value="medium">Medium (Standard)</option>
                                        <option value="large">Large (Readable)</option>
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Row Height/Padding</label>
                                    <select 
                                        value={tempSettings.modules.watchlist.rowHeight}
                                        onChange={(e) => updateModule('watchlist', 'rowHeight', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    >
                                        <option value="compact">Compact (Tight)</option>
                                        <option value="standard">Standard (Comfortable)</option>
                                        <option value="relaxed">Relaxed (Spacious)</option>
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Font Family</label>
                                    <select 
                                        value={tempSettings.modules.watchlist.fontFamily}
                                        onChange={(e) => updateModule('watchlist', 'fontFamily', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    >
                                        <option value="sans">Sans-Serif (Standard)</option>
                                        <option value="mono">Monospace (Code)</option>
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Row Coloring</label>
                                    <select 
                                        value={tempSettings.modules.watchlist.rowStyle}
                                        onChange={(e) => updateModule('watchlist', 'rowStyle', e.target.value)}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    >
                                        <option value="plain">Solid (Single Color)</option>
                                        <option value="striped">Striped (Alternating)</option>
                                    </select>
                                </div>
                            </div>
                        </section>

                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Grid & Behavior</h3>
                            <div className="space-y-2">
                                <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/30 rounded border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
                                    <span className="text-sm text-slate-600 dark:text-slate-300">Show Horizontal Lines</span>
                                    <input 
                                        type="checkbox" 
                                        checked={tempSettings.modules.watchlist.showGridHorizontal}
                                        onChange={(e) => updateModule('watchlist', 'showGridHorizontal', e.target.checked)}
                                        className="w-5 h-5 accent-indigo-500 rounded focus:ring-0"
                                    />
                                </div>
                                <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/30 rounded border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
                                    <span className="text-sm text-slate-600 dark:text-slate-300">Show Vertical Lines</span>
                                    <input 
                                        type="checkbox" 
                                        checked={tempSettings.modules.watchlist.showGridVertical}
                                        onChange={(e) => updateModule('watchlist', 'showGridVertical', e.target.checked)}
                                        className="w-5 h-5 accent-indigo-500 rounded focus:ring-0"
                                    />
                                </div>
                                <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/30 rounded border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
                                    <span className="text-sm text-slate-600 dark:text-slate-300">Highlight Selected Row</span>
                                    <input 
                                        type="checkbox" 
                                        checked={tempSettings.modules.watchlist.highlightSelected}
                                        onChange={(e) => updateModule('watchlist', 'highlightSelected', e.target.checked)}
                                        className="w-5 h-5 accent-indigo-500 rounded focus:ring-0"
                                    />
                                </div>
                            </div>
                        </section>
                     </div>
                )}

                {activeCategory === 'System' && (
                    <div className="space-y-8 max-w-lg">
                        <section>
                            <h3 className="text-xs font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">Performance</h3>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/30 rounded border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
                                    <span className="text-sm text-slate-600 dark:text-slate-300">Enable UI Animations</span>
                                    <input 
                                        type="checkbox" 
                                        checked={tempSettings.modules.system.animations}
                                        onChange={(e) => updateModule('system', 'animations', e.target.checked)}
                                        className="w-5 h-5 accent-indigo-500 rounded focus:ring-0"
                                    />
                                </div>
                                
                                <div className="grid grid-cols-2 items-center">
                                    <label className="text-sm text-slate-600 dark:text-slate-300">Data Refresh Rate (s)</label>
                                    <input 
                                        type="number" min="1" max="60"
                                        value={tempSettings.modules.system.refreshRate}
                                        onChange={(e) => updateModule('system', 'refreshRate', parseInt(e.target.value))}
                                        className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-sm text-slate-800 dark:text-white focus:border-indigo-500 outline-none"
                                    />
                                </div>
                            </div>
                        </section>
                    </div>
                )}
            </div>

            <div className="h-16 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-end px-6 gap-3">
                <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white transition-colors">Cancel</button>
                <button onClick={handleSave} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-bold shadow-lg shadow-indigo-500/20 transition-all transform hover:scale-105">
                    Apply Changes
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
