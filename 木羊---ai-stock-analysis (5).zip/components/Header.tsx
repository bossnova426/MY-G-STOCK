import React from 'react';
import { LayoutGrid } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="h-8 border-b border-slate-800 bg-slate-950 fixed top-0 left-0 right-0 z-50 px-3 flex items-center justify-between select-none">
      <div className="flex items-center gap-2">
        <div className="w-5 h-5 bg-indigo-600 rounded flex items-center justify-center">
           <LayoutGrid className="w-3 h-3 text-white" />
        </div>
        <span className="text-sm font-bold text-slate-200 tracking-tight">
          GeminiQuant
        </span>
      </div>
      
      {/* Minimized Right Side */}
      <div className="flex items-center gap-4">
          <span className="text-[10px] text-slate-600 font-mono">v2.1.0-beta</span>
      </div>
    </header>
  );
};