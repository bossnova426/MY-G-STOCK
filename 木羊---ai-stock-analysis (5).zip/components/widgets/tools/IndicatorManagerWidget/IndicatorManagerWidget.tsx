
import React, { useState, useMemo } from 'react';
import { WidgetContext } from '../../../../../types';
import { indicatorService } from '../../../../../services/indicatorService';
import { eventBus, EVENTS } from '../../../../../services/eventBus';
import { Search, Star, Cloud, Cpu, Activity, Filter, Plus, Info, LayoutGrid, List as ListIcon, Check } from 'lucide-react';

export const IndicatorManagerWidget: React.FC<WidgetContext> = ({ command }) => {
    // ... (keep existing state: searchTerm, activeCategory, etc.)
    const [searchTerm, setSearchTerm] = useState('');
    const [activeCategory, setActiveCategory] = useState<string>('All');
    const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
    const [favorites, setFavorites] = useState<Set<string>>(new Set(['sma20', 'vol', 'macd'])); 

    const index = indicatorService.getIndex();

    const categories = useMemo(() => {
        const cats = new Set<string>(['All', 'Favorites']);
        index.forEach(i => {
            const root = i.category.split('/')[0];
            cats.add(root);
        });
        return Array.from(cats);
    }, [index]);

    const filteredIndicators = useMemo(() => {
        return index.filter(ind => {
            const matchesSearch = ind.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                  ind.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                  ind.tags?.some(t => t.includes(searchTerm.toLowerCase()));
            
            if (!matchesSearch) return false;

            if (activeCategory === 'All') return true;
            if (activeCategory === 'Favorites') return favorites.has(ind.id);
            return ind.category.startsWith(activeCategory);
        });
    }, [index, searchTerm, activeCategory, favorites]);

    const toggleFavorite = (id: string) => {
        setFavorites(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    };

    // Action: Add to Chart via Event Bus
    const handleAddToChart = (id: string) => {
        // Emit event so any active chart listens
        eventBus.emit(EVENTS.INDICATOR_ADDED, { id });
        // Visual feedback
        const btn = document.getElementById(`btn-add-${id}`);
        if(btn) {
            btn.innerHTML = 'Added';
            setTimeout(() => btn.innerHTML = 'Add', 1000);
        }
    };

    return (
        <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            {/* Header / Search */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shrink-0">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-sm font-bold uppercase tracking-wider flex items-center gap-2">
                        <Activity className="w-4 h-4 text-indigo-500" />
                        Formula Library ({index.length})
                    </h2>
                    <div className="flex bg-slate-100 dark:bg-slate-800 rounded p-0.5">
                        <button onClick={() => setViewMode('list')} className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-white dark:bg-slate-700 shadow' : 'text-slate-400'}`}><ListIcon className="w-3.5 h-3.5" /></button>
                        <button onClick={() => setViewMode('grid')} className={`p-1.5 rounded ${viewMode === 'grid' ? 'bg-white dark:bg-slate-700 shadow' : 'text-slate-400'}`}><LayoutGrid className="w-3.5 h-3.5" /></button>
                    </div>
                </div>
                
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                        type="text" 
                        placeholder="Search indicators (e.g., 'MA', 'RSI', 'Pattern')..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                    />
                </div>
            </div>

            <div className="flex-1 flex min-h-0">
                {/* Sidebar Categories */}
                <div className="w-40 border-r border-slate-200 dark:border-slate-800 overflow-y-auto custom-scrollbar bg-slate-50 dark:bg-slate-900/50 py-2">
                    {categories.map(cat => (
                        <button
                            key={cat}
                            onClick={() => setActiveCategory(cat)}
                            className={`w-full text-left px-4 py-2 text-xs font-medium transition-colors flex justify-between items-center ${activeCategory === cat ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 border-r-2 border-indigo-500' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                        >
                            {cat}
                            {activeCategory === cat && <span className="text-[10px] bg-indigo-200 dark:bg-indigo-800 px-1.5 rounded-full">{filteredIndicators.length}</span>}
                        </button>
                    ))}
                </div>

                {/* List Content */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-3">
                    {filteredIndicators.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400">
                            <Filter className="w-8 h-8 mb-2 opacity-20" />
                            <span className="text-xs">No indicators found.</span>
                        </div>
                    ) : (
                        <div className={viewMode === 'grid' ? 'grid grid-cols-2 gap-3' : 'flex flex-col gap-2'}>
                            {filteredIndicators.map(ind => (
                                <div 
                                    key={ind.id} 
                                    className={`
                                        group relative border border-slate-200 dark:border-slate-800 rounded-lg p-3 hover:border-indigo-500 hover:shadow-md transition-all bg-white dark:bg-slate-900
                                        ${viewMode === 'list' ? 'flex items-center gap-4' : 'flex flex-col gap-2'}
                                    `}
                                >
                                    {/* Icon / Source Badge */}
                                    <div className="shrink-0">
                                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${ind.source === 'remote' ? 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                                            {ind.source === 'remote' ? <Cloud className="w-4 h-4" /> : <Cpu className="w-4 h-4" />}
                                        </div>
                                    </div>

                                    {/* Content */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2">
                                            <h3 className="text-sm font-bold truncate">{ind.name}</h3>
                                            {ind.source === 'remote' && <span className="text-[9px] px-1 bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300 rounded border border-purple-200 dark:border-purple-800">Cloud</span>}
                                            {ind.version && <span className="text-[9px] text-slate-400">v{ind.version}</span>}
                                        </div>
                                        <div className="text-xs text-slate-500 truncate">{ind.category} • {ind.author || 'System'}</div>
                                        {viewMode === 'grid' && ind.description && (
                                            <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{ind.description}</p>
                                        )}
                                    </div>

                                    {/* Actions */}
                                    <div className={`flex items-center gap-2 ${viewMode === 'list' ? '' : 'justify-end pt-2 border-t border-slate-100 dark:border-slate-800 mt-2'}`}>
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); toggleFavorite(ind.id); }}
                                            className={`p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${favorites.has(ind.id) ? 'text-amber-400' : 'text-slate-300'}`}
                                        >
                                            <Star className="w-4 h-4 fill-current" />
                                        </button>
                                        <button 
                                            id={`btn-add-${ind.id}`}
                                            onClick={() => handleAddToChart(ind.id)}
                                            className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded text-xs font-bold transition-colors"
                                        >
                                            <Plus className="w-3.5 h-3.5" /> Add
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
            
            {/* Footer Status */}
            <div className="px-4 py-2 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-[10px] text-slate-500 flex justify-between">
                <span>Server Status: <span className="text-emerald-500 font-bold">Connected</span></span>
                <span>Library Version: 2024.05.20</span>
            </div>
        </div>
    );
};
