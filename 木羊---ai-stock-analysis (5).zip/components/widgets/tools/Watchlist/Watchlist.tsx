
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
    Search, Filter, MoreHorizontal, Plus, Settings, 
    ArrowUp, ArrowDown, Trash2, Edit2, Copy, 
    Check, X, GripVertical, FileText, ChevronRight, ChevronDown, 
    Maximize2, Minimize2, Pin
} from 'lucide-react';
import { createPortal } from 'react-dom';
import { CustomWatchlist, WatchlistItem, AppSettings, CustomColumn, StockProfile } from '../../../../../types';
import { AVAILABLE_METRICS, evaluateFormula } from '../../../../../constants';
import { eventBus, EVENTS } from '../../../../../services/eventBus';

interface WatchlistProps {
    availableLists: CustomWatchlist[];
    selectedListIds: string[];
    onSelectionChange: (ids: string[]) => void;
    exclusiveMode: boolean;
    onToggleExclusiveMode: (val: boolean) => void;
    customColumns: CustomColumn[];
    onAddCustomColumn: (col: CustomColumn) => void;
    onRemoveCustomColumn: (id: string) => void;
    onSymbolSelect: (symbol: string) => void;
    onAddStockToWatchlists: (symbol: string, listIds: string[]) => void;
    onRemoveStockFromWatchlist: (symbol: string, listId: string) => void;
    onAddWatchlist: (name: string) => void;
    onRenameWatchlist: (id: string, newName: string) => void;
    onDeleteWatchlist: (id: string) => void;
    onUpdateWatchlist: (id: string, updates: Partial<CustomWatchlist>) => void;
    settings: AppSettings;
    currentSymbol?: string;
    onOpenScreener?: (ids: string[]) => void;
    onBroadcastList?: (list: WatchlistItem[]) => void;
    hideNavigation?: boolean; // For embedded use in Screener
}

interface StockRowProps {
    stock: WatchlistItem;
    activeColumns: string[];
    flags: Record<string, string>;
    toggleFlag: (symbol: string, color: string) => void;
    onSelect: (symbol: string) => void;
    getStickyStyle: (index: number) => React.CSSProperties | undefined;
    pinnedIds: string[];
    onFlagContextMenu: (e: React.MouseEvent, symbol: string) => void;
    symbolDisplayMode: 'symbol' | 'name' | 'both';
    isSelected: boolean;
}

const StockRow: React.FC<StockRowProps> = ({
    stock, activeColumns, flags, toggleFlag, onSelect, getStickyStyle, pinnedIds, onFlagContextMenu, symbolDisplayMode, isSelected
}) => {
    const flagColor = flags[stock.symbol];
    
    // Helper for rendering cell values
    const renderCell = (colId: string) => {
        const val = stock[colId];
        
        if (colId === 'trend' && Array.isArray(val)) {
            // Simple sparkline
            const min = Math.min(...val);
            const max = Math.max(...val);
            const range = max - min || 1;
            const points = val.map((v, i) => `${(i / (val.length - 1)) * 40},${20 - ((v - min) / range) * 20}`).join(' ');
            return (
                <svg width="40" height="20" className="overflow-visible">
                    <polyline points={points} fill="none" stroke={val[val.length-1] >= val[0] ? '#10b981' : '#f43f5e'} strokeWidth="1.5" />
                </svg>
            );
        }

        if (colId === 'change' || colId === 'changePercent') {
            const num = parseFloat(val);
            const colorClass = num >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400';
            return <span className={`font-medium ${colorClass}`}>{num > 0 ? '+' : ''}{typeof num === 'number' ? num.toFixed(2) : val}{colId === 'changePercent' ? '%' : ''}</span>;
        }

        if (colId === 'price') {
             return <span className="font-bold text-slate-700 dark:text-slate-200">{typeof val === 'number' ? val.toFixed(2) : val}</span>;
        }

        if (colId === 'symbol' || colId === 'name') {
            return <span className="font-bold text-slate-700 dark:text-slate-200">{val}</span>;
        }

        if (typeof val === 'number') return val.toFixed(2);
        return val;
    };

    return (
        <div 
            onClick={() => onSelect(stock.symbol)}
            className={`
                flex items-center border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer group text-xs h-8
                ${isSelected ? 'bg-indigo-50 dark:bg-indigo-900/30' : ''}
            `}
        >
            {/* Flag Column */}
            <div 
                className={`w-8 flex items-center justify-center shrink-0 border-r border-slate-100 dark:border-slate-800 sticky left-0 z-20 ${isSelected ? 'bg-indigo-50 dark:bg-indigo-900/30' : 'bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50'}`}
                onContextMenu={(e) => onFlagContextMenu(e, stock.symbol)}
            >
                <div 
                    onClick={(e) => { e.stopPropagation(); toggleFlag(stock.symbol, 'red'); }}
                    className={`w-2 h-2 rounded-full cursor-pointer transition-all ${flagColor ? `bg-${flagColor}-500 shadow-sm scale-110` : 'bg-slate-200 dark:bg-slate-700 hover:bg-slate-300'}`}
                />
            </div>

            {/* Symbol/Name Column (Pinned) */}
            <div 
                className={`w-28 px-2 flex items-center border-r border-slate-100 dark:border-slate-800 sticky left-8 z-20 ${isSelected ? 'bg-indigo-50 dark:bg-indigo-900/30' : 'bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/50'} truncate`}
            >
                <div className="flex flex-col justify-center leading-none">
                    {(symbolDisplayMode === 'symbol' || symbolDisplayMode === 'both') && <span className="font-bold text-slate-700 dark:text-slate-200 truncate">{stock.symbol}</span>}
                    {(symbolDisplayMode === 'name' || symbolDisplayMode === 'both') && <span className="text-[10px] text-slate-500 truncate max-w-[80px]">{stock.name}</span>}
                </div>
            </div>

            {/* Dynamic Columns */}
            {activeColumns.map((colId) => (
                <div key={colId} className="w-20 px-2 flex items-center justify-end border-r border-slate-100 dark:border-slate-800 shrink-0 truncate font-mono text-slate-600 dark:text-slate-400">
                    {renderCell(colId)}
                </div>
            ))}
        </div>
    );
};

export const Watchlist: React.FC<WatchlistProps> = ({
    availableLists, selectedListIds, onSelectionChange, exclusiveMode, onToggleExclusiveMode,
    customColumns, onAddCustomColumn, onRemoveCustomColumn, onSymbolSelect,
    onAddStockToWatchlists, onRemoveStockFromWatchlist, onAddWatchlist, onRenameWatchlist, onDeleteWatchlist, onUpdateWatchlist,
    settings, currentSymbol, onOpenScreener, onBroadcastList, hideNavigation
}) => {
    // State
    const [activeColumns, setActiveColumns] = useState<string[]>(['price', 'changePercent', 'vol', 'trend']);
    const [flags, setFlags] = useState<Record<string, string>>({}); // symbol -> color
    const [searchTerm, setSearchTerm] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>(null);
    const [symbolDisplayMode, setSymbolDisplayMode] = useState<'symbol' | 'name' | 'both'>('symbol');
    
    // UI State
    const [columnMenuOpen, setColumnMenuOpen] = useState(false);
    const [contextMenu, setContextMenu] = useState<{ x: number, y: number, symbol: string | null } | null>(null);
    const [pinnedIds, setPinnedIds] = useState<string[]>(['symbol']); // 'symbol' is always pinned logically

    // Combine stocks from selected lists
    const combinedStocks = useMemo(() => {
        const activeLists = availableLists.filter(l => selectedListIds.includes(l.id));
        if (activeLists.length === 0) return [];

        if (exclusiveMode) {
            // Intersection
            if (activeLists.length === 1) return activeLists[0].stocks;
            const firstList = activeLists[0];
            return firstList.stocks.filter(s => activeLists.slice(1).every(l => l.stocks.some(os => os.symbol === s.symbol)));
        } else {
            // Union (Deduplicated)
            const map = new Map<string, WatchlistItem>();
            activeLists.forEach(l => {
                l.stocks.forEach(s => map.set(s.symbol, s));
            });
            return Array.from(map.values());
        }
    }, [availableLists, selectedListIds, exclusiveMode]);

    // Derived Display Data
    const displayStocks = useMemo(() => {
        let data = [...combinedStocks];
        
        // Filter
        if (searchTerm) {
            const lower = searchTerm.toLowerCase();
            data = data.filter(s => s.symbol.toLowerCase().includes(lower) || s.name.toLowerCase().includes(lower));
        }

        // Calculate Custom Columns
        if (customColumns.length > 0) {
            data = data.map(s => {
                const sNew = { ...s };
                customColumns.forEach(col => {
                    sNew[col.id] = evaluateFormula(col.formula, s.price, s.change, typeof s.vol === 'number' ? s.vol : parseFloat(String(s.vol).replace('M','')) * 1000000);
                });
                return sNew;
            });
        }

        // Sort
        if (sortConfig) {
            data.sort((a, b) => {
                const aVal = a[sortConfig.key];
                const bVal = b[sortConfig.key];
                if (typeof aVal === 'number' && typeof bVal === 'number') {
                    return sortConfig.direction === 'asc' ? aVal - bVal : bVal - aVal;
                }
                return 0;
            });
        }

        return data;
    }, [combinedStocks, searchTerm, customColumns, sortConfig]);

    // Broadcast logic
    useEffect(() => {
        if (onBroadcastList && displayStocks.length > 0) {
            onBroadcastList(displayStocks);
        }
    }, [displayStocks, onBroadcastList]); // Be careful with loop, usually broadcast on meaningful change

    // Handlers
    const handleSort = (key: string) => {
        setSortConfig(current => {
            if (current?.key === key) {
                return current.direction === 'asc' ? { key, direction: 'desc' } : null;
            }
            return { key, direction: 'asc' };
        });
    };

    const toggleFlag = (symbol: string, color: string) => {
        setFlags(prev => {
            if (prev[symbol] === color) {
                const next = { ...prev };
                delete next[symbol];
                return next;
            }
            return { ...prev, [symbol]: color };
        });
    };

    const handleRowContextMenu = (e: React.MouseEvent, symbol: string) => {
        e.preventDefault();
        setContextMenu({ x: e.clientX, y: e.clientY, symbol });
    };

    const handleSymbolClick = (symbol: string) => {
        onSymbolSelect(symbol);
        eventBus.emit(EVENTS.STOCK_SELECTED, { symbol });
    };

    const getStickyStyle = (index: number) => {
        // Simple sticky logic for first col
        return undefined; 
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-slate-900 overflow-hidden text-sm">
            {!hideNavigation && (
                <div className="p-2 border-b border-slate-200 dark:border-slate-800 flex gap-2 overflow-x-auto shrink-0 bg-slate-50 dark:bg-slate-950">
                    <button 
                        onClick={() => {
                            if(selectedListIds.includes('default')) return; // Simple exclusive
                            onSelectionChange(['default']);
                        }}
                        className={`px-3 py-1 rounded text-xs font-bold whitespace-nowrap transition-colors ${selectedListIds.includes('default') ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                        Default
                    </button>
                    {availableLists.filter(l => l.id !== 'default').map(l => (
                        <button 
                            key={l.id}
                            onClick={() => onSelectionChange([l.id])} // Simplified single select
                            className={`px-3 py-1 rounded text-xs font-bold whitespace-nowrap transition-colors ${selectedListIds.includes(l.id) ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                        >
                            {l.name}
                        </button>
                    ))}
                    <button onClick={() => onAddWatchlist('New List')} className="px-2 py-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400"><Plus className="w-3.5 h-3.5" /></button>
                </div>
            )}

            {/* Toolbar */}
            <div className="flex items-center justify-between p-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
                <div className="relative flex-1 max-w-[150px]">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                    <input 
                        type="text" 
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        placeholder="Filter..." 
                        className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded pl-7 pr-2 py-1 text-xs outline-none focus:border-indigo-500 transition-all"
                    />
                </div>
                <div className="flex items-center gap-1">
                    <button 
                        onClick={() => setSymbolDisplayMode(p => p === 'symbol' ? 'name' : p === 'name' ? 'both' : 'symbol')}
                        className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-400" 
                        title="Toggle Display Mode"
                    >
                        <FileText className="w-3.5 h-3.5" />
                    </button>
                    <button 
                        onClick={() => setColumnMenuOpen(true)}
                        className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-400"
                        title="Columns"
                    >
                        <Settings className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => onOpenScreener && onOpenScreener(selectedListIds)} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-400" title="Screen this list">
                        <Filter className="w-3.5 h-3.5" />
                    </button>
                </div>
            </div>

            {/* Header Row */}
            <div className="flex items-center border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-[10px] font-bold text-slate-500 uppercase shrink-0 h-8">
                <div className="w-8 border-r border-slate-200 dark:border-slate-800 text-center sticky left-0 z-20 bg-slate-50 dark:bg-slate-950">F</div>
                <div className="w-28 px-2 border-r border-slate-200 dark:border-slate-800 sticky left-8 z-20 bg-slate-50 dark:bg-slate-950 flex items-center cursor-pointer hover:text-indigo-500" onClick={() => handleSort('symbol')}>
                    Symbol {sortConfig?.key === 'symbol' && (sortConfig.direction === 'asc' ? <ArrowUp className="w-2.5 h-2.5 inline" /> : <ArrowDown className="w-2.5 h-2.5 inline" />)}
                </div>
                {activeColumns.map(colId => {
                    const def = AVAILABLE_METRICS.find(m => m.id === colId) || customColumns.find(c => c.id === colId);
                    return (
                        <div 
                            key={colId} 
                            className="w-20 px-2 border-r border-slate-200 dark:border-slate-800 text-right flex items-center justify-end cursor-pointer hover:text-indigo-500 shrink-0"
                            onClick={() => handleSort(colId)}
                        >
                            {def?.name || colId} {sortConfig?.key === colId && (sortConfig.direction === 'asc' ? <ArrowUp className="w-2.5 h-2.5 inline ml-1" /> : <ArrowDown className="w-2.5 h-2.5 inline ml-1" />)}
                        </div>
                    );
                })}
            </div>

            {/* List Body */}
            <div className="flex-1 overflow-y-auto custom-scrollbar relative">
                {displayStocks.map(item => (
                    <StockRow 
                        key={item.symbol} 
                        stock={item} 
                        activeColumns={activeColumns} 
                        flags={flags} 
                        toggleFlag={toggleFlag} 
                        onSelect={handleSymbolClick} 
                        getStickyStyle={getStickyStyle}
                        pinnedIds={pinnedIds}
                        onFlagContextMenu={handleRowContextMenu}
                        symbolDisplayMode={symbolDisplayMode}
                        isSelected={item.symbol === currentSymbol}
                    />
                ))}
                {displayStocks.length === 0 && (
                    <div className="p-4 text-center text-slate-400 text-xs italic">
                        Empty list. Add stocks or change filters.
                    </div>
                )}
            </div>

            {/* Column Menu Modal */}
            {columnMenuOpen && createPortal(
                <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setColumnMenuOpen(false)}>
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-80 rounded-lg shadow-xl p-4" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-3">
                            <h3 className="font-bold text-slate-700 dark:text-slate-200">Columns</h3>
                            <button onClick={() => setColumnMenuOpen(false)}><X className="w-4 h-4 text-slate-500" /></button>
                        </div>
                        <div className="max-h-60 overflow-y-auto custom-scrollbar space-y-1">
                            {[...AVAILABLE_METRICS, ...customColumns.map(c => ({ id: c.id, name: c.name }))].map(col => (
                                <label key={col.id} className="flex items-center gap-2 p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer">
                                    <input 
                                        type="checkbox" 
                                        checked={activeColumns.includes(col.id)}
                                        onChange={() => setActiveColumns(p => p.includes(col.id) ? p.filter(x => x !== col.id) : [...p, col.id])}
                                        className="rounded border-slate-300 accent-indigo-500"
                                    />
                                    <span className="text-xs text-slate-700 dark:text-slate-300">{col.name}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                </div>,
                document.body
            )}

            {/* Context Menu */}
            {contextMenu && createPortal(
                <div 
                    className="fixed bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl rounded-lg py-1 z-[9999] min-w-[120px] text-xs animate-in fade-in zoom-in-95"
                    style={{ top: contextMenu.y, left: contextMenu.x }}
                    onClick={() => setContextMenu(null)}
                >
                    <div className="px-3 py-1.5 font-bold text-slate-500 border-b border-slate-100 dark:border-slate-700/50 mb-1">{contextMenu.symbol}</div>
                    {['red', 'orange', 'yellow', 'green', 'blue', 'purple'].map(color => (
                        <button 
                            key={color} 
                            onClick={() => contextMenu.symbol && toggleFlag(contextMenu.symbol, color)}
                            className="flex items-center gap-2 w-full px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 text-left capitalize"
                        >
                            <span className={`w-2 h-2 rounded-full bg-${color}-500`}></span>
                            Flag {color}
                        </button>
                    ))}
                    <div className="border-t border-slate-100 dark:border-slate-700/50 my-1"></div>
                    <button onClick={() => contextMenu.symbol && onRemoveStockFromWatchlist(contextMenu.symbol, selectedListIds[0])} className="w-full px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 text-left text-rose-500 flex items-center gap-2">
                        <Trash2 className="w-3 h-3" /> Remove
                    </button>
                </div>,
                document.body
            )}
        </div>
    );
};
