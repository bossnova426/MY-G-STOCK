
import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { WidgetContext, WidgetPlugin } from '../../../../../types';
import { Plus, X, MoreHorizontal, Layout, Check, GripVertical } from 'lucide-react';

interface TabItem {
    id: string;
    type: string;
    title: string;
    config: any;
}

interface TabContainerConfig {
    tabs: TabItem[];
    activeTabId: string;
}

export const TabContainerWidget: React.FC<WidgetContext> = (props) => {
    const { widgetConfig, onUpdateConfig, pluginRegistry } = props;
    
    // --- State & Config Init ---
    const config: TabContainerConfig = useMemo(() => {
        // Initialize default state if missing
        if (!widgetConfig || !widgetConfig.tabs) {
            return {
                tabs: [],
                activeTabId: ''
            };
        }
        return widgetConfig as TabContainerConfig;
    }, [widgetConfig]);

    // --- UI State ---
    const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
    const [selectedForAdd, setSelectedForAdd] = useState<string[]>([]);
    
    // Drag & Drop State
    const [draggedTabId, setDraggedTabId] = useState<string | null>(null);
    
    // --- Handlers ---
    const updateConfig = (newConf: Partial<TabContainerConfig>) => {
        onUpdateConfig({ ...config, ...newConf });
    };

    const handleToggleSelect = (pluginId: string) => {
        setSelectedForAdd(prev => 
            prev.includes(pluginId) 
                ? prev.filter(id => id !== pluginId)
                : [...prev, pluginId]
        );
    };

    const handleConfirmAdd = () => {
        if (selectedForAdd.length === 0) return;

        const newTabs: TabItem[] = [];
        
        selectedForAdd.forEach((pluginId, index) => {
            const plugin = pluginRegistry[pluginId];
            if (plugin) {
                newTabs.push({
                    id: `tab-${Date.now()}-${index}-${Math.random().toString(36).substr(2, 5)}`,
                    type: pluginId,
                    title: plugin.title,
                    config: plugin.defaultConfig ? { ...plugin.defaultConfig } : {}
                });
            }
        });

        const updatedTabs = [...config.tabs, ...newTabs];
        updateConfig({
            tabs: updatedTabs,
            // Switch to the first of the newly added tabs
            activeTabId: newTabs[0].id 
        });
        
        closeAddMenu();
    };

    const closeAddMenu = () => {
        setIsAddMenuOpen(false);
        setSelectedForAdd([]);
    };

    const handleRemoveTab = (e: React.MouseEvent, tabId: string) => {
        e.stopPropagation();
        const newTabs = config.tabs.filter(t => t.id !== tabId);
        
        let newActiveId = config.activeTabId;
        if (config.activeTabId === tabId) {
            newActiveId = newTabs.length > 0 ? newTabs[newTabs.length - 1].id : '';
        }

        updateConfig({
            tabs: newTabs,
            activeTabId: newActiveId
        });
    };

    const handleSetActive = (tabId: string) => {
        updateConfig({ activeTabId: tabId });
    };

    const handleRenameTab = (tabId: string, currentName: string) => {
        const newName = prompt("Rename Tab:", currentName);
        if (newName && newName !== currentName) {
            // Update the specific tab's config
            handleTabConfigUpdate(tabId, { customTabName: newName });
        }
    };

    // --- Sub-Widget Config Handler ---
    const handleTabConfigUpdate = (tabId: string, newChildConfig: any) => {
        const updatedTabs = config.tabs.map(t => 
            t.id === tabId ? { ...t, config: { ...t.config, ...newChildConfig } } : t
        );
        updateConfig({ tabs: updatedTabs });
    };

    // --- Drag & Drop Handlers ---
    const handleDragStart = (e: React.DragEvent, id: string) => {
        setDraggedTabId(id);
        e.dataTransfer.effectAllowed = 'move';
        // Transparent drag image or default
    };

    const handleDragOver = (e: React.DragEvent, targetId: string) => {
        e.preventDefault(); // Allow drop
    };

    const handleDrop = (e: React.DragEvent, targetId: string) => {
        e.preventDefault();
        if (!draggedTabId || draggedTabId === targetId) return;

        const oldIndex = config.tabs.findIndex(t => t.id === draggedTabId);
        const newIndex = config.tabs.findIndex(t => t.id === targetId);
        
        if (oldIndex === -1 || newIndex === -1) return;

        const newTabs = [...config.tabs];
        const [moved] = newTabs.splice(oldIndex, 1);
        newTabs.splice(newIndex, 0, moved);
        
        updateConfig({ tabs: newTabs });
        setDraggedTabId(null);
    };

    // Filter available plugins to show in "Add" menu (excluding TabContainer itself to prevent infinite recursion, though technically possible)
    const availablePlugins = (Object.values(pluginRegistry || {}) as WidgetPlugin[]).filter(p => p.id !== 'TAB_CONTAINER');

    return (
        <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-hidden">
            {/* Main Content Area */}
            <div className="flex-1 min-h-0 relative">
                {config.tabs.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <Layout className="w-12 h-12 mb-2 opacity-20" />
                        <span className="text-xs">No active tabs</span>
                        <button 
                            onClick={() => setIsAddMenuOpen(true)}
                            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded text-xs font-bold hover:bg-indigo-500 transition-colors"
                        >
                            Add Widget
                        </button>
                    </div>
                ) : (
                    config.tabs.map(tab => {
                        const isActive = tab.id === config.activeTabId;
                        const plugin = pluginRegistry[tab.type];
                        if (!plugin) return null;

                        const childContext: WidgetContext = {
                            ...props,
                            widgetConfig: tab.config,
                            onUpdateConfig: (newConf) => handleTabConfigUpdate(tab.id, newConf)
                        };

                        return (
                            <div 
                                key={tab.id} 
                                className={`w-full h-full absolute inset-0 ${isActive ? 'z-10 visible' : 'z-0 invisible'}`}
                            >
                                <plugin.component {...childContext} />
                            </div>
                        );
                    })
                )}
                
                {/* Overlay Add Menu */}
                {isAddMenuOpen && (
                    <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center backdrop-blur-sm p-8" onClick={closeAddMenu}>
                        <div className="bg-white dark:bg-slate-900 w-full max-w-2xl max-h-full rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
                            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-950">
                                <h3 className="font-bold text-slate-800 dark:text-white">Add Widgets to Tab</h3>
                                <button onClick={closeAddMenu}><X className="w-5 h-5 text-slate-500" /></button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-4 grid grid-cols-2 sm:grid-cols-3 gap-3 custom-scrollbar">
                                {availablePlugins.map(p => {
                                    const isSelected = selectedForAdd.includes(p.id);
                                    return (
                                        <button 
                                            key={p.id}
                                            onClick={() => handleToggleSelect(p.id)}
                                            className={`flex flex-col items-center gap-2 p-4 rounded-lg border transition-all group text-center relative
                                                ${isSelected 
                                                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30' 
                                                    : 'border-slate-200 dark:border-slate-800 hover:border-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20'}
                                            `}
                                        >
                                            {isSelected && (
                                                <div className="absolute top-2 right-2 bg-indigo-600 text-white rounded-full p-0.5 shadow-sm animate-in fade-in zoom-in duration-200">
                                                    <Check className="w-3 h-3" />
                                                </div>
                                            )}
                                            <div className={`p-2 rounded-full transition-colors ${isSelected ? 'text-indigo-600 bg-white dark:bg-slate-800' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 group-hover:text-indigo-500'}`}>
                                                <p.icon className="w-6 h-6" />
                                            </div>
                                            <div>
                                                <div className={`text-xs font-bold ${isSelected ? 'text-indigo-700 dark:text-indigo-300' : 'text-slate-700 dark:text-slate-200'}`}>{p.title}</div>
                                                <div className="text-[10px] text-slate-400 mt-1 line-clamp-2">{p.description}</div>
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                            {/* Footer Actions */}
                            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end gap-2">
                                <button 
                                    onClick={closeAddMenu} 
                                    className="px-4 py-2 text-xs font-medium text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition-colors"
                                >
                                    Cancel
                                </button>
                                <button 
                                    onClick={handleConfirmAdd}
                                    disabled={selectedForAdd.length === 0}
                                    className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg text-xs font-bold shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-2"
                                >
                                    <Plus className="w-3.5 h-3.5" />
                                    Add {selectedForAdd.length > 0 ? `(${selectedForAdd.length})` : ''}
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Bottom Tab Bar */}
            <div className="h-9 flex items-center bg-slate-100 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 px-1 overflow-x-auto custom-scrollbar shrink-0 select-none">
                {config.tabs.map(tab => {
                    const isActive = tab.id === config.activeTabId;
                    const isDragging = draggedTabId === tab.id;
                    // Check if child config has a custom tab name, otherwise fallback to plugin title
                    const displayTitle = tab.config?.customTabName || tab.title;

                    return (
                        <div 
                            key={tab.id}
                            draggable
                            onDragStart={(e) => handleDragStart(e, tab.id)}
                            onDragOver={(e) => handleDragOver(e, tab.id)}
                            onDrop={(e) => handleDrop(e, tab.id)}
                            onClick={() => handleSetActive(tab.id)}
                            onDoubleClick={() => handleRenameTab(tab.id, displayTitle)}
                            className={`
                                group flex items-center gap-2 px-3 py-1.5 mr-1 rounded-t-md cursor-pointer border-b-2 transition-all min-w-[80px] max-w-[160px]
                                ${isActive 
                                    ? 'bg-white dark:bg-slate-900 border-indigo-500 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                                    : 'bg-transparent border-transparent text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-300'}
                                ${isDragging ? 'opacity-50 scale-95' : ''}
                            `}
                            title="Double-click to rename, Drag to reorder"
                        >
                            {/* Grip Icon for visual affordance on hover */}
                            <GripVertical className="w-2.5 h-2.5 text-slate-300 opacity-0 group-hover:opacity-100 cursor-grab active:cursor-grabbing" />
                            
                            <span className="text-xs font-medium truncate flex-1">{displayTitle}</span>
                            
                            {/* Close Button */}
                            <button 
                                onClick={(e) => handleRemoveTab(e, tab.id)}
                                className={`p-0.5 rounded hover:bg-rose-100 hover:text-rose-500 dark:hover:bg-rose-900/50 opacity-0 group-hover:opacity-100 transition-all ${isActive ? 'opacity-100' : ''}`}
                            >
                                <X className="w-3 h-3" />
                            </button>
                        </div>
                    );
                })}

                {/* Add Button */}
                <button 
                    onClick={() => setIsAddMenuOpen(true)}
                    className="flex items-center justify-center w-8 h-7 ml-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-indigo-500 transition-colors"
                    title="Add Tab"
                >
                    <Plus className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
};
