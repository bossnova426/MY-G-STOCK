
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { WidgetContext } from '../../../../types';
import { Play, Pause, Plus, Trash2, Edit, Settings, Bell, CheckSquare, Square, X, Folder, Layers, AlertCircle, Clock, Zap } from 'lucide-react';
import { createPortal } from 'react-dom';
import { TreeBrowser, TreeNode } from '../../../common/TreeBrowser';
import { INDICATOR_REGISTRY } from '../../../../services/indicatorService';

// --- Types for Local State ---
interface AlertRule {
    id: string;
    name: string;
    period: string; // 1D, 5m, etc.
    type: 'Simple' | 'Formula' | 'Combined';
    monitorTarget: string; // "Target Pool A" or "Stock Code"
    matchCount: number;
    isEnabled: boolean;
    condition?: string;
    targetScopeId?: string;
}

interface AlertLog {
    id: string;
    time: string;
    code: string;
    name: string;
    condition: string;
    price: number;
    changePercent: number;
}

const DEFAULT_RULES: AlertRule[] = [
    { id: '1', name: 'Simple Warning', period: '1D', type: 'Simple', monitorTarget: '000792', matchCount: 0, isEnabled: true },
    { id: '2', name: 'New High (N Days)', period: '1D', type: 'Formula', monitorTarget: 'Pool: High Growth', matchCount: 1236, isEnabled: true },
    { id: '3', name: 'POWER3 Momentum', period: '1D', type: 'Formula', monitorTarget: 'Pool: Power3', matchCount: 48, isEnabled: true },
    { id: '4', name: 'Earnings Surprise', period: '1D', type: 'Formula', monitorTarget: 'Pool: Earnings', matchCount: 5328, isEnabled: true },
    { id: '5', name: 'Fractal Breakout', period: '1D', type: 'Combined', monitorTarget: 'Pool: Fractal', matchCount: 154, isEnabled: false },
    { id: '6', name: 'Gap Up', period: '1D', type: 'Combined', monitorTarget: 'Pool: Gaps', matchCount: 5373, isEnabled: true },
    { id: '7', name: 'High Tight Flag', period: '1D', type: 'Combined', monitorTarget: 'Pool: HTF', matchCount: 5328, isEnabled: true },
];

export const AlertsWidget: React.FC<WidgetContext> = ({ 
    availableWatchlists, 
    onSymbolSelect,
    settings
}) => {
    // --- State ---
    const [rules, setRules] = useState<AlertRule[]>(DEFAULT_RULES);
    const [logs, setLogs] = useState<AlertLog[]>([]);
    const [isRunning, setIsRunning] = useState(false);
    const [selectedRuleIds, setSelectedRuleIds] = useState<Set<string>>(new Set());
    
    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
    
    // Simulation Ref
    const intervalRef = useRef<number | null>(null);

    // --- Simulation Logic ---
    useEffect(() => {
        if (isRunning) {
            intervalRef.current = window.setInterval(() => {
                // 1. Pick a random enabled rule
                const enabledRules = rules.filter(r => r.isEnabled);
                if (enabledRules.length === 0) return;
                const randomRule = enabledRules[Math.floor(Math.random() * enabledRules.length)];

                // 2. Pick a random stock (from available lists for realism)
                const randomList = availableWatchlists[Math.floor(Math.random() * availableWatchlists.length)];
                if (!randomList || randomList.stocks.length === 0) return;
                const randomStock = randomList.stocks[Math.floor(Math.random() * randomList.stocks.length)];

                // 3. Generate a trigger event
                const now = new Date();
                const timeStr = now.toTimeString().split(' ')[0];
                
                const newLog: AlertLog = {
                    id: `log-${Date.now()}`,
                    time: timeStr,
                    code: randomStock.symbol,
                    name: randomStock.name || randomStock.symbol,
                    condition: randomRule.name,
                    price: randomStock.price + (Math.random() - 0.5),
                    changePercent: randomStock.changePercent + (Math.random() * 0.2 - 0.1)
                };

                setLogs(prev => [newLog, ...prev].slice(0, 100)); // Keep last 100
                
                // Update match count
                setRules(prev => prev.map(r => r.id === randomRule.id ? { ...r, matchCount: r.matchCount + 1 } : r));

            }, 1500); // Trigger every 1.5s
        } else {
            if (intervalRef.current) clearInterval(intervalRef.current);
        }
        return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
    }, [isRunning, rules, availableWatchlists]);

    // --- Actions ---
    const toggleRuleSelection = (id: string) => {
        setSelectedRuleIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    };

    const handleDelete = () => {
        if (selectedRuleIds.size === 0) return;
        if (confirm(`Delete ${selectedRuleIds.size} rules?`)) {
            setRules(prev => prev.filter(r => !selectedRuleIds.has(r.id)));
            setSelectedRuleIds(new Set());
        }
    };

    const handleEdit = () => {
        if (selectedRuleIds.size !== 1) return;
        const id = Array.from(selectedRuleIds)[0];
        setEditingRuleId(id);
        setIsModalOpen(true);
    };

    const handleCreate = () => {
        setEditingRuleId(null);
        setIsModalOpen(true);
    };

    const handleSaveRule = (rule: AlertRule) => {
        if (editingRuleId) {
            setRules(prev => prev.map(r => r.id === editingRuleId ? rule : r));
        } else {
            setRules(prev => [...prev, rule]);
        }
        setIsModalOpen(false);
    };

    const handleLogClick = (log: AlertLog) => {
        onSymbolSelect(log.code);
    };

    return (
        <div className="flex w-full h-full bg-slate-900 text-slate-300 font-sans text-xs overflow-hidden select-none">
            
            {/* Main Content (Left) */}
            <div className="flex-1 flex flex-col min-w-0 border-r border-slate-800">
                
                {/* Top Section: Rule List */}
                <div className="flex-1 flex flex-col min-h-0 border-b border-slate-800 bg-slate-950">
                    {/* Table Header */}
                    <div className="flex items-center bg-slate-900 border-b border-slate-800 px-2 py-1 font-bold text-slate-500">
                        <div className="w-8 text-center">No.</div>
                        <div className="w-8 text-center">Sel</div>
                        <div className="flex-1 px-2">Condition Name</div>
                        <div className="w-12 text-center">Per</div>
                        <div className="w-20 text-center">Type</div>
                        <div className="w-24 px-2">Monitor</div>
                        <div className="w-16 text-right px-2">Count</div>
                    </div>
                    {/* Table Body */}
                    <div className="flex-1 overflow-y-auto custom-scrollbar">
                        {rules.map((rule, idx) => (
                            <div 
                                key={rule.id} 
                                className={`flex items-center px-2 py-1 border-b border-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer ${selectedRuleIds.has(rule.id) ? 'bg-slate-800' : ''}`}
                                onClick={() => toggleRuleSelection(rule.id)}
                            >
                                <div className="w-8 text-center text-slate-600">{idx + 1}</div>
                                <div className="w-8 flex justify-center">
                                    {selectedRuleIds.has(rule.id) ? <CheckSquare className="w-3.5 h-3.5 text-indigo-500" /> : <Square className="w-3.5 h-3.5 text-slate-600" />}
                                </div>
                                <div className="flex-1 px-2 text-white font-medium truncate">{rule.name}</div>
                                <div className="w-12 text-center text-slate-400">{rule.period}</div>
                                <div className="w-20 text-center text-indigo-400">{rule.type}</div>
                                <div className="w-24 px-2 truncate text-slate-400">{rule.monitorTarget}</div>
                                <div className="w-16 text-right px-2 text-emerald-500 font-mono">{rule.matchCount}</div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Bottom Section: Logs */}
                <div className="h-1/2 flex flex-col min-h-0 bg-slate-900">
                    <div className="bg-slate-800/50 border-y border-slate-800 px-2 py-1 font-bold text-slate-500 flex items-center">
                        <div className="w-20">Time</div>
                        <div className="w-20">Code</div>
                        <div className="w-24">Name</div>
                        <div className="flex-1">Trigger Condition</div>
                        <div className="w-16 text-right">Price</div>
                        <div className="w-16 text-right">Chg%</div>
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar">
                        {logs.map((log) => (
                            <div 
                                key={log.id} 
                                className="flex items-center px-2 py-0.5 hover:bg-slate-800 cursor-pointer border-b border-slate-800/30 group"
                                onClick={() => handleLogClick(log)}
                            >
                                <div className="w-20 font-mono text-slate-400">{log.time}</div>
                                <div className="w-20 font-mono text-indigo-300 group-hover:text-indigo-200">{log.code}</div>
                                <div className="w-24 text-slate-300">{log.name}</div>
                                <div className="flex-1 text-amber-500">{log.condition}</div>
                                <div className="w-16 text-right font-mono text-white">{log.price.toFixed(2)}</div>
                                <div className={`w-16 text-right font-mono ${log.changePercent >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                    {log.changePercent > 0 ? '+' : ''}{log.changePercent.toFixed(2)}%
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right Sidebar (Controls) */}
            <div className="w-20 bg-slate-950 border-l border-slate-800 flex flex-col gap-2 p-2 shrink-0">
                <button 
                    onClick={() => setIsRunning(!isRunning)}
                    className={`w-full py-2 rounded flex flex-col items-center justify-center gap-1 font-bold transition-all ${isRunning ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/50' : 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/50'}`}
                >
                    {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                    <span>{isRunning ? 'Stop' : 'Start'}</span>
                </button>

                <div className="h-2"></div>

                <button onClick={handleCreate} className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 flex flex-col items-center text-[10px]">
                    <Plus className="w-4 h-4 mb-0.5" /> New
                </button>
                <button onClick={handleEdit} disabled={selectedRuleIds.size !== 1} className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 flex flex-col items-center text-[10px] disabled:opacity-50">
                    <Edit className="w-4 h-4 mb-0.5" /> Modify
                </button>
                <button onClick={handleDelete} disabled={selectedRuleIds.size === 0} className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 flex flex-col items-center text-[10px] disabled:opacity-50">
                    <Trash2 className="w-4 h-4 mb-0.5" /> Delete
                </button>

                <div className="h-px bg-slate-800 my-1"></div>

                <button className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 flex flex-col items-center text-[10px]">
                    <Layers className="w-4 h-4 mb-0.5" /> Pools
                </button>
                <button className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 flex flex-col items-center text-[10px]">
                    <Zap className="w-4 h-4 mb-0.5" /> EA Mgr
                </button>
            </div>

            {/* Config Modal */}
            {isModalOpen && createPortal(
                <ConfigModal 
                    rule={rules.find(r => r.id === editingRuleId) || null} 
                    onClose={() => setIsModalOpen(false)} 
                    onSave={handleSaveRule} 
                    watchlists={availableWatchlists}
                />, 
                document.body
            )}
        </div>
    );
};

// --- Config Modal Component ---
interface ConfigModalProps {
    rule: AlertRule | null;
    onClose: () => void;
    onSave: (rule: AlertRule) => void;
    watchlists: any[];
}

const ConfigModal: React.FC<ConfigModalProps> = ({ rule, onClose, onSave, watchlists }) => {
    const [name, setName] = useState(rule?.name || '');
    const [activeTab, setActiveTab] = useState<'SIMPLE' | 'FORMULA'>('FORMULA');
    const [selectedTarget, setSelectedTarget] = useState(rule?.monitorTarget || 'All Stocks');
    
    // Mock Tree Data for Indicators
    const indicatorTreeData = useMemo(() => {
        const root: TreeNode[] = [];
        const cats = new Set(INDICATOR_REGISTRY.map(i => i.category.split('/')[0]));
        cats.forEach(cat => {
            root.push({
                id: cat,
                label: cat,
                type: 'folder',
                children: INDICATOR_REGISTRY.filter(i => i.category.startsWith(cat)).map(i => ({
                    id: i.id,
                    label: i.name,
                    type: 'item',
                    icon: AlertCircle,
                    color: 'text-emerald-500'
                }))
            });
        });
        return root;
    }, []);

    const handleSave = () => {
        if (!name) return alert("Please enter a name");
        const newRule: AlertRule = {
            id: rule?.id || `rule-${Date.now()}`,
            name,
            period: '1D',
            type: activeTab === 'SIMPLE' ? 'Simple' : 'Formula',
            monitorTarget: selectedTarget,
            matchCount: rule?.matchCount || 0,
            isEnabled: true
        };
        onSave(newRule);
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-[9999] flex items-center justify-center p-4">
            <div className="bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-[700px] h-[500px] rounded-lg shadow-2xl flex flex-col overflow-hidden text-sm">
                
                {/* Header */}
                <div className="flex justify-between items-center px-4 py-2 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950">
                    <span className="font-bold text-slate-800 dark:text-slate-200">Alert Configuration</span>
                    <button onClick={onClose}><X className="w-5 h-5 text-slate-500 hover:text-rose-500" /></button>
                </div>

                {/* Tabs */}
                <div className="flex gap-1 px-4 py-2 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
                    <button 
                        onClick={() => setActiveTab('SIMPLE')} 
                        className={`px-4 py-1 rounded-t-md text-xs font-bold border-b-2 transition-all ${activeTab === 'SIMPLE' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-800' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                        Simple Alert
                    </button>
                    <button 
                        onClick={() => setActiveTab('FORMULA')} 
                        className={`px-4 py-1 rounded-t-md text-xs font-bold border-b-2 transition-all ${activeTab === 'FORMULA' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-800' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                        Formula Alert
                    </button>
                </div>

                {/* Body */}
                <div className="flex-1 flex flex-col p-4 gap-4 bg-slate-50 dark:bg-slate-900 overflow-hidden">
                    
                    {/* Name Input */}
                    <div className="flex items-center gap-2">
                        <label className="w-20 text-right text-slate-600 dark:text-slate-400 font-medium">Alert Name:</label>
                        <input 
                            type="text" 
                            value={name} 
                            onChange={e => setName(e.target.value)}
                            className="flex-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 focus:border-indigo-500 outline-none"
                        />
                    </div>

                    <div className="flex-1 flex gap-4 min-h-0">
                        {/* Left: Library */}
                        <div className="w-1/3 border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800 flex flex-col">
                            <div className="px-2 py-1 bg-slate-100 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-500">
                                System Indicators
                            </div>
                            <div className="flex-1 overflow-y-auto">
                                <TreeBrowser 
                                    data={indicatorTreeData}
                                    onSelect={(node) => {
                                        if (node.type === 'item') {
                                            // Mock adding param
                                            setName(prev => prev ? prev : node.label);
                                        }
                                    }}
                                    enableSearch={false}
                                />
                            </div>
                        </div>

                        {/* Right: Params Placeholder */}
                        <div className="flex-1 border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800 p-4 flex flex-col justify-center items-center text-slate-400 gap-2">
                            <Settings className="w-8 h-8 opacity-20" />
                            <p>Parameter configuration would go here.</p>
                            <p className="text-xs italic">(Logic Builder omitted for this demo)</p>
                        </div>
                    </div>

                    {/* Scope Selector */}
                    <div className="flex items-center gap-2">
                        <CheckSquare className="w-4 h-4 text-indigo-500" />
                        <span className="text-slate-600 dark:text-slate-300 font-bold">Monitor Scope:</span>
                        <select 
                            value={selectedTarget}
                            onChange={e => setSelectedTarget(e.target.value)}
                            className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 text-xs outline-none"
                        >
                            <option>All Stocks (Shanghai/Shenzhen)</option>
                            {watchlists.map((w: any) => (
                                <option key={w.id} value={w.name}>{w.name}</option>
                            ))}
                        </select>
                        <span className="text-slate-400 ml-auto">5976 Stocks</span>
                    </div>

                    {/* Advanced Options */}
                    <div className="flex gap-4 p-2 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded">
                        <div className="flex items-center gap-1.5">
                            <span className="text-slate-500">Interval:</span>
                            <select className="bg-transparent border-b border-slate-400 dark:border-slate-600 text-xs outline-none">
                                <option>Real-time</option>
                                <option>1 Min</option>
                            </select>
                        </div>
                        <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span className="text-slate-500">Time:</span>
                            <input type="text" defaultValue="09:25" className="w-12 bg-transparent border-b border-slate-400 dark:border-slate-600 text-center" />
                            <span>-</span>
                            <input type="text" defaultValue="15:00" className="w-12 bg-transparent border-b border-slate-400 dark:border-slate-600 text-center" />
                        </div>
                        <div className="flex items-center gap-1.5 ml-auto">
                            <input type="checkbox" id="sound" />
                            <label htmlFor="sound" className="flex items-center gap-1 text-slate-600 dark:text-slate-300 cursor-pointer">
                                <Bell className="w-3.5 h-3.5" /> Sound
                            </label>
                        </div>
                    </div>

                </div>

                {/* Footer */}
                <div className="p-3 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 flex justify-end gap-2">
                    <button onClick={onClose} className="px-4 py-1.5 border border-slate-300 dark:border-slate-600 rounded text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800">Cancel</button>
                    <button onClick={handleSave} className="px-6 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded shadow-sm font-medium">Confirm</button>
                </div>
            </div>
        </div>
    );
};
