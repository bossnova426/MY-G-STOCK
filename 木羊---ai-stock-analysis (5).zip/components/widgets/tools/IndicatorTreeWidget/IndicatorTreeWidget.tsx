
import React, { useMemo } from 'react';
import { WidgetContext } from '../../../../../types';
import { TreeBrowser, TreeNode } from '../../../../common/TreeBrowser';
import { INDICATOR_REGISTRY } from '../../../../../services/indicatorService';
import { Activity, BarChart2, Calculator, Sigma } from 'lucide-react';

export const IndicatorTreeWidget: React.FC<WidgetContext> = ({ onAddCustomColumn }) => {
  
  // Transform Registry into Tree Structure
  const treeData = useMemo(() => {
    const root: TreeNode[] = [];
    const categoryMap = new Map<string, TreeNode>();

    // Helper to get or create folder
    const getFolder = (path: string[], parentArray: TreeNode[]): TreeNode[] => {
        if (path.length === 0) return parentArray;
        
        const currentName = path[0];
        let folder = parentArray.find(n => n.id === `cat-${currentName}` && n.type === 'folder');
        
        if (!folder) {
            folder = {
                id: `cat-${currentName}`,
                label: currentName,
                type: 'folder',
                children: [],
                icon: Sigma // Function icon for categories
            };
            parentArray.push(folder);
        }
        
        return getFolder(path.slice(1), folder.children!);
    };

    INDICATOR_REGISTRY.forEach(ind => {
        const parts = ind.category.split('/');
        const targetArray = getFolder(parts, root);
        
        targetArray.push({
            id: ind.id,
            label: ind.name,
            type: 'item',
            icon: ind.chartType === 'overlay' ? Activity : BarChart2,
            color: 'text-emerald-500',
            data: ind
        });
    });

    return root;
  }, []);

  const handleSelect = (node: TreeNode) => {
      if (node.type === 'item' && node.data) {
          // If clicked, maybe we want to allow adding it as a column?
          // For now, let's just log or maybe prompt to add
          if(confirm(`Add ${node.label} to Global Custom Columns?`)) {
              onAddCustomColumn({
                  id: `col-${node.id}-${Date.now()}`,
                  name: node.data.shortName,
                  formula: node.id // Simple ref
              });
          }
      }
  };

  return (
    <div className="h-full flex flex-col">
       <div className="bg-slate-900 p-2 text-[10px] text-amber-500 font-mono border-b border-slate-800">
           System Formula &gt; Technical
       </div>
       <div className="flex-1 min-h-0">
           <TreeBrowser 
             data={treeData} 
             onSelect={handleSelect}
             emptyMessage="No indicators found"
           />
       </div>
    </div>
  );
};
