
import React, { useState } from 'react';
import { WidgetContext } from '../../../../../types';
import { Layout, Plus, Edit3, Trash2, Check, X, GripVertical } from 'lucide-react';

export const WorkspaceManagerWidget: React.FC<WidgetContext> = ({ 
    workspaces, 
    activeWorkspaceId, 
    onSwitchWorkspace, 
    onAddWorkspace, 
    onRenameWorkspace, 
    onDeleteWorkspace 
}) => {
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editName, setEditName] = useState('');

    const startEdit = (id: string, currentName: string) => {
        setEditingId(id);
        setEditName(currentName);
    };

    const confirmEdit = () => {
        if (editingId && editName.trim()) {
            onRenameWorkspace(editingId, editName);
        }
        setEditingId(null);
    };

    const handleCreate = () => {
        const name = prompt("New Workspace Name:", `Workspace ${workspaces.length + 1}`);
        if (name) {
            onAddWorkspace(name);
        }
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-slate-900 overflow-hidden">
            {/* Header */}
            <div className="flex justify-between items-center px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <div className="flex items-center gap-2">
                    <Layout className="w-4 h-4 text-indigo-500" />
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wide">Workspaces</span>
                </div>
                <button 
                    onClick={handleCreate}
                    className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded shadow-sm transition-colors"
                    title="Create Workspace"
                >
                    <Plus className="w-3.5 h-3.5" />
                </button>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto p-2 space-y-2 custom-scrollbar">
                {workspaces.map(ws => {
                    const isActive = ws.id === activeWorkspaceId;
                    const isEditing = editingId === ws.id;

                    return (
                        <div 
                            key={ws.id}
                            className={`
                                group flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer relative
                                ${isActive 
                                    ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800' 
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-slate-600'}
                            `}
                            onClick={() => !isEditing && onSwitchWorkspace(ws.id)}
                        >
                            {/* Active Indicator Strip */}
                            {isActive && <div className="absolute left-0 top-2 bottom-2 w-1 bg-indigo-500 rounded-r"></div>}

                            <div className="flex items-center gap-3 flex-1 min-w-0 pl-2">
                                <div className={`p-2 rounded-md ${isActive ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600' : 'bg-slate-100 dark:bg-slate-700 text-slate-500'}`}>
                                    <Layout className="w-4 h-4" />
                                </div>
                                
                                {isEditing ? (
                                    <div className="flex items-center gap-1 flex-1" onClick={e => e.stopPropagation()}>
                                        <input 
                                            autoFocus
                                            type="text" 
                                            value={editName}
                                            onChange={e => setEditName(e.target.value)}
                                            onKeyDown={e => e.key === 'Enter' && confirmEdit()}
                                            className="w-full bg-white dark:bg-slate-900 border border-indigo-500 rounded px-2 py-1 text-xs text-slate-900 dark:text-white outline-none"
                                        />
                                        <button onClick={confirmEdit} className="p-1 text-emerald-500 hover:bg-emerald-50 rounded"><Check className="w-3.5 h-3.5" /></button>
                                        <button onClick={() => setEditingId(null)} className="p-1 text-rose-500 hover:bg-rose-50 rounded"><X className="w-3.5 h-3.5" /></button>
                                    </div>
                                ) : (
                                    <div className="flex flex-col min-w-0">
                                        <span className={`text-sm font-bold truncate ${isActive ? 'text-indigo-900 dark:text-indigo-100' : 'text-slate-700 dark:text-slate-200'}`}>
                                            {ws.name}
                                        </span>
                                        <span className="text-[10px] text-slate-400">
                                            {ws.widgets.length} Widgets
                                        </span>
                                    </div>
                                )}
                            </div>

                            {!isEditing && (
                                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
                                    <button 
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            startEdit(ws.id, ws.name);
                                        }}
                                        className="p-1.5 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded transition-colors"
                                        title="Rename"
                                    >
                                        <Edit3 className="w-3.5 h-3.5" />
                                    </button>
                                    {workspaces.length > 1 && (
                                        <button 
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                onDeleteWorkspace(ws.id);
                                            }}
                                            className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded transition-colors"
                                            title="Delete"
                                        >
                                            <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                    )}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
            
            {/* Footer Stats */}
            <div className="px-4 py-2 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-[10px] text-slate-500 text-center">
                Total {workspaces.length} Workspaces
            </div>
        </div>
    );
};
