
import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { ExtendedFilterGroup } from './useScreenerEngine';
import { ActiveFilter, FilterGroup } from '../../../../../types';
import { Plus, X, Save, GripVertical, Trash2, FolderOpen } from 'lucide-react';

interface FilterBuilderProps {
    groups: ExtendedFilterGroup[];
    filterCounts: Record<string, number>;
    groupCounts: Record<string, number>;
    onUpdateFilter: (groupId: string, filterId: string, updates: Partial<ActiveFilter>) => void;
    onRemoveFilter: (groupId: string, filterId: string) => void;
    onAddGroup: () => void;
    onRemoveGroup: (groupId: string) => void;
    onToggleGroupLogic: (groupId: string) => void;
    onToggleGroupOperator: (groupId: string) => void;
    onSaveGroupConfig: (group: FilterGroup) => void;
    onLoadGroupConfig: (group: any) => void; // Using any for saved format compatibility
    savedGroups: any[];
    onDeleteSavedGroup: (id: string) => void;
}

export const FilterBuilder: React.FC<FilterBuilderProps> = ({
    groups, filterCounts, groupCounts,
    onUpdateFilter, onRemoveFilter, onAddGroup, onRemoveGroup,
    onToggleGroupLogic, onToggleGroupOperator, onSaveGroupConfig,
    onLoadGroupConfig, savedGroups, onDeleteSavedGroup
}) => {
    const loadGroupButtonRef = React.useRef<HTMLButtonElement>(null);
    const [isLoadMenuOpen, setIsLoadMenuOpen] = useState(false);
    const [menuPos, setMenuPos] = useState<React.CSSProperties>({});

    const handleOpenMenu = (e: React.MouseEvent) => {
        if (loadGroupButtonRef.current) {
            const rect = loadGroupButtonRef.current.getBoundingClientRect();
            setMenuPos({ position: 'fixed', left: rect.left, top: rect.bottom + 4, width: 256, zIndex: 9999 });
            setIsLoadMenuOpen(!isLoadMenuOpen);
        }
    };

    return (
        <div className="max-w-3xl mx-auto space-y-0 pb-10">
            {groups.map((group, gIdx) => (
                <div key={group.id} className="relative pl-6 pb-6 last:pb-0">
                    {/* Connector Line */}
                    {gIdx < groups.length - 1 && (
                        <div className="absolute left-[23px] top-10 bottom-0 w-[2px] bg-indigo-100 dark:bg-slate-800 z-0"></div>
                    )}

                    {/* Operator Node */}
                    {gIdx > 0 && (
                        <div className="absolute left-[9px] -top-3 z-10">
                            <button 
                                onClick={() => onToggleGroupOperator(group.id)}
                                className="w-8 h-8 rounded-full border-2 border-slate-50 dark:border-slate-900 bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center text-[10px] font-bold text-slate-500 hover:text-indigo-600 hover:border-indigo-500 transition-colors"
                            >
                                {group.operator}
                            </button>
                        </div>
                    )}

                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-visible relative z-0 group/card ring-1 ring-transparent hover:ring-indigo-500/30 transition-all">
                        {/* Group Header */}
                        <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                            <div className="flex items-center gap-3">
                                <span className="text-xs font-bold text-slate-400">Group {gIdx + 1}</span>
                                <div className="flex bg-slate-100 dark:bg-slate-800 rounded p-0.5">
                                    <button 
                                        onClick={() => group.logic !== 'AND' && onToggleGroupLogic(group.id)}
                                        className={`px-3 py-1 text-[10px] font-bold rounded-sm transition-all ${group.logic === 'AND' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-white' : 'text-slate-400 hover:text-slate-600'}`}
                                    >
                                        Match ALL
                                    </button>
                                    <button 
                                        onClick={() => group.logic !== 'OR' && onToggleGroupLogic(group.id)}
                                        className={`px-3 py-1 text-[10px] font-bold rounded-sm transition-all ${group.logic === 'OR' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-white' : 'text-slate-400 hover:text-slate-600'}`}
                                    >
                                        Match ANY
                                    </button>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-mono font-bold text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                    {groupCounts[group.id] || 0}
                                </div>
                                <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 mx-1"></div>
                                <button onClick={() => onSaveGroupConfig(group)} className="p-1.5 text-slate-400 hover:text-indigo-500 rounded hover:bg-slate-50 dark:hover:bg-slate-800" title="Save Template"><Save className="w-3.5 h-3.5" /></button>
                                <button onClick={() => onRemoveGroup(group.id)} className="p-1.5 text-slate-400 hover:text-rose-500 rounded hover:bg-slate-50 dark:hover:bg-slate-800" title="Delete Group"><X className="w-3.5 h-3.5" /></button>
                            </div>
                        </div>

                        {/* Filters Container */}
                        <div className="p-2 pl-4 space-y-2 relative">
                            {group.filters.length > 0 && (
                                <div className="absolute left-[24px] top-4 bottom-8 w-[2px] bg-slate-100 dark:bg-slate-800 rounded-full"></div>
                            )}

                            {group.filters.length === 0 ? (
                                <div className="text-center py-8 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-lg text-slate-400 text-xs mx-2">
                                    Drag or add indicators from the library to start filtering
                                </div>
                            ) : (
                                group.filters.map((filter) => (
                                    <div key={filter.id} className="relative pl-8">
                                        {/* Tree Branch */}
                                        <div className="absolute left-[24px] top-1/2 -translate-y-1/2 w-4 h-[2px] bg-slate-100 dark:bg-slate-800"></div>
                                        <div className="absolute left-[21px] top-1/2 -translate-y-1/2 w-2 h-2 rounded-full border-2 border-slate-50 dark:border-slate-900 bg-indigo-500 z-10"></div>
                                        
                                        <div className="flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all group/filter">
                                            <GripVertical className="w-3 h-3 text-slate-300 cursor-move" />
                                            <div className="w-32 truncate">
                                                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{filter.name}</span>
                                            </div>
                                            <select 
                                                value={filter.operator}
                                                onChange={(e) => onUpdateFilter(group.id, filter.id, { operator: e.target.value as any })}
                                                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 text-xs outline-none focus:border-indigo-500 w-24 text-slate-600 dark:text-slate-300"
                                            >
                                                <option value=">">Greater &gt;</option>
                                                <option value="<">Less &lt;</option>
                                                <option value="=">Equals =</option>
                                                <option value="between">Between</option>
                                                <option value="contains">Contains</option>
                                            </select>
                                            <input 
                                                type="text" 
                                                value={filter.value}
                                                onChange={(e) => onUpdateFilter(group.id, filter.id, { value: e.target.value })}
                                                placeholder={filter.operator === 'between' ? 'min,max' : 'Value'}
                                                className="flex-1 min-w-0 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 text-xs outline-none focus:border-indigo-500 text-slate-800 dark:text-white"
                                            />
                                            <div className="px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 min-w-[50px] text-center">
                                                <span className="text-[10px] font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                                    {filterCounts[filter.id] ?? '-'}
                                                </span>
                                            </div>
                                            <button onClick={() => onRemoveFilter(group.id, filter.id)} className="p-1.5 text-slate-400 hover:text-rose-500 opacity-0 group-hover/filter:opacity-100 transition-opacity"><X className="w-3.5 h-3.5" /></button>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            ))}
            
            {/* Add Group Actions */}
            <div className="flex items-center gap-3 pl-[30px] pt-4 relative">
                {groups.length > 0 && <div className="absolute left-[23px] top-0 h-8 w-[2px] bg-indigo-100 dark:bg-slate-800"></div>}
                
                <button onClick={onAddGroup} className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-500 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all shadow-sm z-10">
                    <Plus className="w-4 h-4" /> Add Filter Group
                </button>
                
                <div className="relative z-10">
                    <button 
                        ref={loadGroupButtonRef}
                        onClick={handleOpenMenu}
                        className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-500 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all shadow-sm"
                    >
                        <FolderOpen className="w-4 h-4" /> Load Template
                    </button>
                    {isLoadMenuOpen && createPortal(
                        <div 
                            className="fixed bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-[9999] p-1 animate-in fade-in zoom-in-95 origin-bottom-left"
                            style={menuPos}
                            onClick={() => setIsLoadMenuOpen(false)}
                        >
                            <div className="text-[10px] font-bold text-slate-400 uppercase px-2 py-1.5">Saved Groups</div>
                            {savedGroups.length === 0 && <div className="px-2 py-2 text-xs text-slate-400 italic">No templates saved.</div>}
                            {savedGroups.map(sg => (
                                <div key={sg.id} onClick={() => { onLoadGroupConfig(sg); setIsLoadMenuOpen(false); }} className="flex justify-between items-center px-2 py-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer group">
                                    <span className="text-xs font-medium text-slate-700 dark:text-slate-200">{sg.name}</span>
                                    <button onClick={(e) => { e.stopPropagation(); onDeleteSavedGroup(sg.id); }} className="p-1 hover:bg-rose-100 hover:text-rose-500 rounded hidden group-hover:block"><Trash2 className="w-3 h-3" /></button>
                                </div>
                            ))}
                        </div>,
                        document.body
                    )}
                </div>
            </div>
        </div>
    );
};
