
import { useState, useEffect, useRef, useCallback } from 'react';
import { 
    FilterDefinition, FilterGroup, ActiveFilter, SavedScreen, 
    CustomWatchlist, RankingCriterion, WatchlistItem, AppSettings 
} from '../../../../../types';

// Extended FilterGroup to support inter-group logic
export interface ExtendedFilterGroup extends FilterGroup {
    operator: 'AND' | 'OR';
}

interface UseScreenerEngineProps {
    initialScope: string[];
    availableWatchlists: CustomWatchlist[];
    onSaveWatchlist?: (watchlist: CustomWatchlist) => void;
}

const TEMP_WATCHLIST_ID = 'screener-temp-results';
const TEMP_PREV_WATCHLIST_ID = 'screener-temp-prev';

export const useScreenerEngine = ({ initialScope, availableWatchlists, onSaveWatchlist }: UseScreenerEngineProps) => {
    // --- Builder State ---
    const [groups, setGroups] = useState<ExtendedFilterGroup[]>([
        { id: 'g1', logic: 'AND', operator: 'AND', filters: [] }
    ]);
    const [rankingCriteria, setRankingCriteria] = useState<RankingCriterion[]>([]);
    
    // --- Execution Settings ---
    const [sourceIds, setSourceIds] = useState<string[]>(initialScope);
    const [includeSuspended, setIncludeSuspended] = useState(false);
    const [dateMode, setDateMode] = useState<'TODAY' | 'PERIOD'>('TODAY');
    const [dateRange, setDateRange] = useState<{ start: string; end: string }>({
        start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        end: new Date().toISOString().split('T')[0]
    });
    const [targetOutputListId, setTargetOutputListId] = useState<string>(TEMP_WATCHLIST_ID);

    // --- Results State ---
    const [tempWatchlist, setTempWatchlist] = useState<CustomWatchlist>({
        id: TEMP_WATCHLIST_ID, name: 'Current Run', stocks: []
    });
    const [tempWatchlistPrev, setTempWatchlistPrev] = useState<CustomWatchlist>({
        id: TEMP_PREV_WATCHLIST_ID, name: 'Previous Run', stocks: []
    });
    const tempWatchlistRef = useRef(tempWatchlist);
    useEffect(() => { tempWatchlistRef.current = tempWatchlist; }, [tempWatchlist]);

    // --- Status State ---
    const [isExecuting, setIsExecuting] = useState(false);
    const [isStale, setIsStale] = useState(true);
    const [filterCounts, setFilterCounts] = useState<Record<string, number>>({});
    const [groupCounts, setGroupCounts] = useState<Record<string, number>>({});

    // --- Mock Data ---
    const [mockUniverse, setMockUniverse] = useState<any[]>([]);
    useEffect(() => {
        const sectors = ['Technology', 'Finance', 'Healthcare', 'Energy', 'Consumer'];
        const today = new Date().toISOString().split('T')[0];
        const randomDate = (start: Date, end: Date) => new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime())).toISOString().split('T')[0];

        const data = Array.from({length: 2500}).map((_, i) => {
            const isToday = Math.random() > 0.9;
            return {
                symbol: `STK-${1000 + i}`,
                name: `Stock ${1000 + i}`,
                price: Math.random() * 500 + 10,
                change: (Math.random() * 20) - 10,
                changePercent: (Math.random() * 10) - 5,
                vol: Math.floor(Math.random() * 5000000) + 100000,
                mkt_cap: Math.random() * 200 + 0.5,
                pe: Math.random() * 100 + 5,
                sector: sectors[Math.floor(Math.random() * sectors.length)],
                sector_l1: sectors[Math.floor(Math.random() * sectors.length)],
                last_signal_date: isToday ? today : randomDate(new Date(Date.now() - 30*24*60*60*1000), new Date()),
                trend: Array.from({length: 15}, () => Math.random() * 100) 
            };
        });
        setMockUniverse(data);
    }, []);

    // --- Logic Helpers ---
    const checkCondition = useCallback((stock: any, filter: ActiveFilter): boolean => {
        let stockVal = stock[filter.defId];
        if (filter.defId === 'pe_ratio') stockVal = stock.pe;
        else if (filter.defId === 'sector') stockVal = stock.sector_l1;
        
        if (stockVal === undefined || stockVal === null) {
            if (filter.defId === 'vol' && stock.vol !== undefined) stockVal = stock.vol;
            else return false; 
        }
        
        const val = parseFloat(filter.value as string);
        
        if (typeof stockVal === 'string') {
            const filterStr = String(filter.value).toLowerCase();
            const dataStr = stockVal.toLowerCase();
            if (filter.operator === '=') return dataStr === filterStr;
            if (filter.operator === 'contains') return dataStr.includes(filterStr);
            return true; 
        }

        if (typeof stockVal === 'number') {
            if (isNaN(val) && !filter.operator.includes('between')) return true; 
            switch (filter.operator) {
                case '>': return stockVal > val;
                case '<': return stockVal < val;
                case '=': return Math.abs(stockVal - val) < 0.001; 
                case 'between': { const parts = String(filter.value).split(','); const min = parseFloat(parts[0]); const max = parseFloat(parts[1]); if (isNaN(min) || isNaN(max)) return true; return stockVal >= min && stockVal <= max; }
                default: return true;
            }
        }
        return false;
    }, []);

    // --- Actions ---
    const runStrategy = useCallback(() => {
        setIsExecuting(true);
        let baseSet: any[] = [];
        
        if (sourceIds.includes('all')) {
            baseSet = [...mockUniverse];
        } else {
            const uniqueMap = new Map();
            sourceIds.forEach(id => {
                const list = availableWatchlists.find(w => w.id === id);
                if (list) list.stocks.forEach(s => uniqueMap.set(s.symbol, s));
            });
            baseSet = Array.from(uniqueMap.values());
        }

        const today = new Date().toISOString().split('T')[0];
        baseSet = baseSet.filter(s => {
            const date = s.last_signal_date || today; 
            return dateMode === 'TODAY' ? date === today : (date >= dateRange.start && date <= dateRange.end);
        });
        
        const newFilterCounts: Record<string, number> = {};
        const newGroupCounts: Record<string, number> = {};
        let currentResult = [...baseSet];

        groups.forEach((group, gIdx) => {
            const groupInput = group.operator === 'AND' ? currentResult : baseSet;
            let groupMatches: any[] = [];
            if (group.filters.length === 0) {
                groupMatches = [...groupInput];
            } else if (group.logic === 'AND') {
                let tempSet = [...groupInput];
                group.filters.forEach(filter => {
                    tempSet = tempSet.filter(stock => checkCondition(stock, filter));
                    newFilterCounts[filter.id] = tempSet.length;
                });
                groupMatches = tempSet;
            } else {
                const unionIds = new Set<string>();
                group.filters.forEach(filter => {
                    const matches = groupInput.filter(stock => checkCondition(stock, filter));
                    newFilterCounts[filter.id] = matches.length;
                    matches.forEach(m => unionIds.add(m.symbol));
                });
                groupMatches = groupInput.filter(s => unionIds.has(s.symbol));
            }
            newGroupCounts[group.id] = groupMatches.length;
            
            if (gIdx === 0) {
                currentResult = groupMatches;
            } else {
                if (group.operator === 'AND') {
                    const matchIds = new Set(groupMatches.map(s => s.symbol));
                    currentResult = currentResult.filter(s => matchIds.has(s.symbol));
                } else {
                    const existingIds = new Set(currentResult.map(s => s.symbol));
                    groupMatches.forEach(s => { if (!existingIds.has(s.symbol)) { currentResult.push(s); existingIds.add(s.symbol); } });
                }
            }
        });

        let finalResults = [...currentResult];
        if (rankingCriteria.length > 0) {
            finalResults = finalResults.map(s => {
                const enhanced = { ...s };
                let score = 0;
                rankingCriteria.forEach(crit => {
                    let field = crit.defId;
                    if (field === 'pe_ratio') field = 'pe';
                    if (field === 'sector') field = 'sector_l1';
                    let val = s[field] || 0;
                    if (typeof val !== 'number') val = 0;
                    const norm = Math.min(100, Math.max(0, val)); 
                    score += (crit.direction === 'asc' ? (100 - norm) : norm) * crit.weight;
                });
                enhanced._score = score;
                return enhanced;
            });
            finalResults.sort((a, b) => (b._score || 0) - (a._score || 0));
        }

        setFilterCounts(newFilterCounts);
        setGroupCounts(newGroupCounts);
        
        const watchlistItems: WatchlistItem[] = finalResults.map(s => ({
            ...s,
            vol: typeof s.vol === 'number' ? (s.vol / 1000000).toFixed(1) + 'M' : s.vol
        }));

        const currentStocks = tempWatchlistRef.current.stocks;
        if (currentStocks.length > 0) {
            setTempWatchlistPrev(prev => ({ ...prev, stocks: [...currentStocks], name: `Previous (${currentStocks.length})` }));
        }

        setTempWatchlist(prev => ({ ...prev, stocks: watchlistItems }));

        if (targetOutputListId !== TEMP_WATCHLIST_ID && onSaveWatchlist) {
            const targetList = availableWatchlists.find(l => l.id === targetOutputListId);
            if (targetList && !targetList.readOnly) {
                const existingSyms = new Set(targetList.stocks.map(s => s.symbol));
                const newItems = watchlistItems.filter(s => !existingSyms.has(s.symbol));
                if (newItems.length > 0) {
                    onSaveWatchlist({ ...targetList, stocks: [...targetList.stocks, ...newItems] });
                }
            }
        }

        setIsExecuting(false);
        setIsStale(false);
    }, [groups, dateRange, mockUniverse, rankingCriteria, checkCondition, dateMode, sourceIds, availableWatchlists, targetOutputListId, onSaveWatchlist]);

    useEffect(() => { setIsStale(true); }, [groups, dateRange, rankingCriteria, dateMode, sourceIds]);

    // --- Modification Handlers ---
    const addLibraryItem = (def: FilterDefinition, builderTab: 'FILTER' | 'RANK') => { 
        if (builderTab === 'RANK') {
            const newCriterion: RankingCriterion = {
                id: `rc-${Date.now()}`, defId: def.id, name: def.name,
                direction: 'desc', scope: 'global', weight: 1
            };
            setRankingCriteria(prev => [...prev, newCriterion]);
        } else {
            const newFilter: ActiveFilter = {
                id: `f-${Date.now()}`, defId: def.id, name: def.name,
                mode: 'threshold', operator: '>', scope: 'global', value: '', logic: 'AND'
            };
            setGroups(prev => {
                const newGroups = [...prev];
                newGroups[newGroups.length - 1].filters.push(newFilter);
                return newGroups;
            });
        }
    };

    const updateFilter = (groupId: string, filterId: string, updates: Partial<ActiveFilter>) => { 
        setGroups(prev => prev.map(g => g.id === groupId ? { ...g, filters: g.filters.map(f => f.id === filterId ? { ...f, ...updates } : f) } : g)); 
    };
    const removeFilter = (groupId: string, filterId: string) => { 
        setGroups(prev => prev.map(g => g.id === groupId ? { ...g, filters: g.filters.filter(f => f.id !== filterId) } : g)); 
    };
    const addGroup = () => setGroups(prev => [...prev, { id: `g-${Date.now()}`, logic: 'AND', operator: 'AND', filters: [] }]);
    const removeGroup = (groupId: string) => { if (groups.length <= 1) return; setGroups(prev => prev.filter(g => g.id !== groupId)); };
    const toggleGroupInternalLogic = (groupId: string) => { setGroups(prev => prev.map(g => g.id === groupId ? { ...g, logic: g.logic === 'AND' ? 'OR' : 'AND' } : g)); };
    const toggleGroupOperator = (groupId: string) => { setGroups(prev => prev.map(g => g.id === groupId ? { ...g, operator: g.operator === 'AND' ? 'OR' : 'AND' } : g)); };
    const updateRankingCriterion = (id: string, updates: Partial<RankingCriterion>) => { setRankingCriteria(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c)); };
    const removeRankingCriterion = (id: string) => { setRankingCriteria(prev => prev.filter(c => c.id !== id)); };

    const loadSavedScreen = (screen: SavedScreen) => {
        setGroups(screen.groups as ExtendedFilterGroup[]);
        setRankingCriteria(screen.rankingCriteria || []);
        setIsStale(true); 
        setFilterCounts({});
        setTempWatchlist(prev => ({...prev, stocks: []})); 
        setTempWatchlistPrev(prev => ({...prev, stocks: []}));
    };

    return {
        // State
        groups, rankingCriteria, sourceIds, includeSuspended, dateMode, dateRange,
        targetOutputListId, tempWatchlist, tempWatchlistPrev, isExecuting, isStale,
        filterCounts, groupCounts,
        
        // Setters
        setSourceIds, setIncludeSuspended, setDateMode, setDateRange, setTargetOutputListId,
        setGroups, // For advanced use
        
        // Handlers
        addLibraryItem, updateFilter, removeFilter, addGroup, removeGroup, 
        toggleGroupInternalLogic, toggleGroupOperator, updateRankingCriterion, 
        removeRankingCriterion, loadSavedScreen, runStrategy
    };
};
