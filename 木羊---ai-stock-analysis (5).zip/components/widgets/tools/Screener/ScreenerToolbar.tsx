
import React, { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Database, CheckSquare, Square, UploadCloud, RefreshCw, Loader2 } from 'lucide-react';
import { CustomWatchlist } from '../../../../../types';
import { TreeBrowser, TreeNode } from '../../../../common/TreeBrowser';

interface ScreenerToolbarProps {
    sourceIds: string[];
    onToggleSource: (id: string) => void;
    availableWatchlists: CustomWatchlist[];
    includeSuspended: boolean;
    setIncludeSuspended: (val: boolean) => void;
    dateMode: 'TODAY' | 'PERIOD';
    setDateMode: (val: 'TODAY' | 'PERIOD') => void;
    targetOutputListId: string;
    setTargetOutputListId: (val: string) => void;
    isStale: boolean;
    isExecuting: boolean;
    onExecute: () => void;
    TEMP_WATCHLIST_ID: string;
}

export const ScreenerToolbar: React.FC<ScreenerToolbarProps> = ({
    sourceIds, onToggleSource, availableWatchlists, includeSuspended, setIncludeSuspended,
    dateMode, setDateMode, targetOutputListId, setTargetOutputListId, isStale, isExecuting, onExecute, TEMP_WATCHLIST_ID
}) => {
    const sourceButtonRef = useRef<HTMLButtonElement>(null);
    const [isSourceMenuOpen, setIsSourceMenuOpen] = useState(false);
    const [sourceMenuPos, setSourceMenuPos] = useState<React.CSSProperties>({});

    const getSourceDisplayString = () => { 
        if (sourceIds.length === 0) return "No Selection"; 
        if (sourceIds.includes('all')) return "All Market Symbols" + (sourceIds.length > 1 ? ` (+${sourceIds.length - 1} lists)` : ""); 
        const names = sourceIds.map(id => availableWatchlists.find(l => l.id === id)?.name || "Unknown"); 
        return names.join(', '); 
    };

    // Build List Tree
    const listTreeData = React.useMemo(() => {
        const marketRoot: TreeNode = {
            id: 'root-market', label: 'Market Universe', type: 'folder', isExpanded: true, color: 'text-blue-500',
            children: [{ id: 'all', label: 'All Market Symbols', type: 'item', icon: sourceIds.includes('all') ? CheckSquare : Square, color: sourceIds.includes('all') ? 'text-indigo-500' : 'text-slate-400' }]
        };
        const listRoot: TreeNode = {
            id: 'root-lists', label: 'My Watchlists', type: 'folder', isExpanded: true, color: 'text-amber-500', children: []
        };
        availableWatchlists.forEach(list => {
            const parts = list.name.split('/');
            const displayName = parts.pop()!;
            let currentLevel = listRoot.children!;
            parts.forEach((folderName, idx) => {
                let folder = currentLevel.find(n => n.label === folderName && n.type === 'folder');
                if (!folder) {
                    folder = { id: `f-${folderName}-${idx}`, label: folderName, type: 'folder', children: [], color: 'text-yellow-500' };
                    currentLevel.push(folder);
                }
                currentLevel = folder.children!;
            });
            const isSelected = sourceIds.includes(list.id);
            currentLevel.push({
                id: list.id, label: displayName, type: 'item',
                icon: isSelected ? CheckSquare : Square,
                color: isSelected ? 'text-indigo-500' : 'text-slate-400',
                data: list
            });
        });
        return [marketRoot, listRoot];
    }, [availableWatchlists, sourceIds]);

    const handleOpenSourceMenu = () => {
        if (!sourceButtonRef.current) return;
        const rect = sourceButtonRef.current.getBoundingClientRect();
        setSourceMenuPos({ position: 'fixed', width: 288, zIndex: 9999, left: rect.left, top: rect.bottom + 4 });
        setIsSourceMenuOpen(!isSourceMenuOpen);
    };

    return (
        <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 shrink-0 space-y-3">
            {/* Row 1: Source Scope Settings */}
            <div>
                <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Scope Settings</span>
                    <div className="flex items-center gap-2">
                        <label className="flex items-center gap-1.5 cursor-pointer">
                            {includeSuspended ? <CheckSquare className="w-3 h-3 text-indigo-500" /> : <Square className="w-3 h-3 text-slate-300" />}
                            <input type="checkbox" checked={includeSuspended} onChange={e => setIncludeSuspended(e.target.checked)} className="hidden" />
                            <span className="text-[10px] text-slate-600 dark:text-slate-400">Suspended</span>
                        </label>
                    </div>
                </div>
                
                <div className="flex gap-2 relative">
                    <div className="flex-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 truncate cursor-default flex items-center">
                        <Database className="w-3 h-3 mr-2 text-slate-400" />
                        {getSourceDisplayString()}
                    </div>
                    
                    <button 
                        ref={sourceButtonRef}
                        onClick={handleOpenSourceMenu}
                        className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-medium text-slate-600 dark:text-slate-300 hover:border-indigo-500 hover:text-indigo-500 transition-colors shadow-sm whitespace-nowrap"
                    >
                        Select Range
                    </button>

                    {isSourceMenuOpen && createPortal(
                        <div 
                            className="fixed bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl z-[9999] overflow-hidden flex flex-col h-80 animate-in fade-in zoom-in-95 duration-100"
                            style={sourceMenuPos}
                            onClick={(e) => e.stopPropagation()}
                        >
                            <div className="p-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-[10px] text-slate-500 uppercase">
                                Select Data Sources
                            </div>
                            <div className="flex-1 overflow-hidden">
                                <TreeBrowser 
                                    data={listTreeData}
                                    onSelect={(node) => node.type === 'item' && onToggleSource(node.id)}
                                    enableSearch={false}
                                />
                            </div>
                        </div>,
                        document.body
                    )}
                </div>
            </div>

            {/* Row 2: Date & Execution */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/50">
                <div className="flex items-center gap-2">
                    <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-md">
                        <button 
                            onClick={() => setDateMode('TODAY')}
                            className={`px-2 py-1 text-[10px] font-bold uppercase rounded-sm transition-colors ${dateMode === 'TODAY' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            Today
                        </button>
                        <button 
                            onClick={() => setDateMode('PERIOD')}
                            className={`px-2 py-1 text-[10px] font-bold uppercase rounded-sm transition-colors ${dateMode === 'PERIOD' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            Period
                        </button>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                        {/* Output Target Selector */}
                        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                            <UploadCloud className="w-3 h-3 text-slate-400" />
                            <select 
                                value={targetOutputListId}
                                onChange={(e) => setTargetOutputListId(e.target.value)}
                                className="bg-transparent border-none outline-none text-[10px] font-medium text-slate-600 dark:text-slate-300 w-24 cursor-pointer dark:bg-slate-800"
                            >
                                <option value={TEMP_WATCHLIST_ID} className="dark:bg-slate-800 dark:text-slate-200">Temporary View</option>
                                {availableWatchlists.filter(l => !l.readOnly).map(l => (
                                    <option key={l.id} value={l.id} className="dark:bg-slate-800 dark:text-slate-200">+ {l.name.split('/').pop()}</option>
                                ))}
                            </select>
                        </div>

                        <div className={`text-xs font-medium px-2 py-1 rounded transition-colors ${isStale ? 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400' : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400'}`}>
                            {isStale ? 'Modified' : 'Ready'}
                        </div>
                        <button 
                            onClick={onExecute}
                            className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-md text-xs font-bold shadow-lg shadow-indigo-500/20 transition-all disabled:opacity-50"
                        >
                            {isExecuting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                            Execute
                        </button>
                </div>
            </div>
        </div>
    );
};
