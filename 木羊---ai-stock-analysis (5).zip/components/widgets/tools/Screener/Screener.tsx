
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { SavedScreen, CustomWatchlist, CustomColumn, AppSettings, SavedFilterGroup, FilterDefinition, RankingCriterion } from '../../../../../types';
import { FILTER_DEFINITIONS } from '../../../../../constants';
import { Sigma, Folder, List, Filter, Hash, FileText, Layers, TrendingUp, ArrowUp, ArrowDown, X, Save, Layout, History } from 'lucide-react';
import { TreeBrowser, TreeNode } from '../../../../common/TreeBrowser';
import { Watchlist } from '../Watchlist/Watchlist';

// New Imports
import { useScreenerEngine } from './useScreenerEngine';
import { FilterBuilder } from './FilterBuilder';
import { ScreenerToolbar } from './ScreenerToolbar';

const TEMP_WATCHLIST_ID = 'screener-temp-results';
const TEMP_PREV_WATCHLIST_ID = 'screener-temp-prev';

interface ScreenerProps {
  savedScreens: SavedScreen[];
  onSaveScreen: (screen: SavedScreen) => void;
  onSaveWatchlist: (watchlist: CustomWatchlist) => void;
  onNavigateToDashboard: () => void;
  customColumns: CustomColumn[];
  onAddCustomColumn: (col: CustomColumn) => void;
  onRemoveCustomColumn: (id: string) => void;
  availableWatchlists: CustomWatchlist[]; 
  settings?: AppSettings;
  onSymbolSelect?: (symbol: string) => void;
  onAddWatchlist?: (name: string) => void;
  onRenameWatchlist?: (id: string, newName: string) => void;
  onDeleteWatchlist?: (id: string) => void;
  onUpdateWatchlist?: (id: string, updates: Partial<CustomWatchlist>) => void;
  initialScope?: string[];
}

export const Screener: React.FC<ScreenerProps> = ({ 
    savedScreens, onSaveScreen, onSaveWatchlist, onNavigateToDashboard,
    customColumns, onAddCustomColumn, onRemoveCustomColumn, availableWatchlists,
    onSymbolSelect, onAddWatchlist, onRenameWatchlist, onDeleteWatchlist, onUpdateWatchlist,
    settings, initialScope = ['all']
}) => {
  // --- UI Layout State ---
  const [leftPaneWidth, setLeftPaneWidth] = useState(288);
  const [rightPaneWidth, setRightPaneWidth] = useState(450);
  const containerRef = useRef<HTMLDivElement>(null);
  const isResizing = useRef<'LEFT' | 'RIGHT' | null>(null);
  const [builderTab, setBuilderTab] = useState<'FILTER' | 'RANK'>('FILTER');
  const [activeResultView, setActiveResultView] = useState<'current' | 'previous'>('current');

  // --- Saved Template State ---
  const [savedFilterGroups, setSavedFilterGroups] = useState<SavedFilterGroup[]>(() => {
     try { return JSON.parse(localStorage.getItem('gemini_saved_filter_groups') || '[]'); } catch { return []; }
  });
  useEffect(() => { localStorage.setItem('gemini_saved_filter_groups', JSON.stringify(savedFilterGroups)); }, [savedFilterGroups]);

  // --- Engine Hook ---
  const engine = useScreenerEngine({ initialScope, availableWatchlists, onSaveWatchlist });

  // --- Resizing Logic ---
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing.current || !containerRef.current) return;
      const containerRect = containerRef.current.getBoundingClientRect();
      const relativeX = e.clientX - containerRect.left;
      if (isResizing.current === 'LEFT') setLeftPaneWidth(Math.max(200, Math.min(500, relativeX)));
      else if (isResizing.current === 'RIGHT') setRightPaneWidth(Math.max(300, Math.min(800, containerRect.width - relativeX)));
    };
    const handleMouseUp = () => { isResizing.current = null; document.body.style.cursor = 'default'; document.body.style.userSelect = 'auto'; };
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => { document.removeEventListener('mousemove', handleMouseMove); document.removeEventListener('mouseup', handleMouseUp); };
  }, []);

  const startResize = (direction: 'LEFT' | 'RIGHT') => {
      isResizing.current = direction;
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none'; 
  };

  // --- Tree Logic ---
  const indicatorTreeData = useMemo(() => {
      const root: TreeNode[] = [];
      const getFolder = (path: string[], parentArray: TreeNode[]): TreeNode[] => {
          if (path.length === 0) return parentArray;
          const currentName = path[0];
          let folder = parentArray.find(n => n.label === currentName && n.type === 'folder');
          if (!folder) {
              folder = { id: `cat-${currentName}-${path.length}`, label: currentName, type: 'folder', children: [], color: 'text-amber-500', icon: Folder };
              parentArray.push(folder);
          }
          return getFolder(path.slice(1), folder.children!);
      };

      FILTER_DEFINITIONS.forEach(def => {
          const parts = def.category.split('/');
          const targetArray = getFolder(parts, root);
          targetArray.push({
              id: def.id, label: def.name, type: 'item', data: { type: 'INDICATOR', def }, 
              icon: def.dataType === 'number' ? Hash : (def.dataType === 'select' ? List : Filter), color: 'text-indigo-500'
          });
      });

      const savedFolder: TreeNode = {
          id: 'cat-saved-strategies', label: '组合公式', type: 'folder', children: [], color: 'text-emerald-500', icon: Layers, isExpanded: true
      };
      
      savedScreens.forEach(screen => {
          savedFolder.children!.push({ id: `saved-${screen.id}`, label: screen.name, type: 'item', data: { type: 'SAVED_SCREEN', screen }, icon: FileText, color: 'text-slate-500' });
      });
      if (savedScreens.length === 0) savedFolder.children!.push({ id: 'empty-saved', label: '(Empty)', type: 'item', icon: FileText, color: 'text-slate-400', data: null });
      root.push(savedFolder);
      return root;
  }, [savedScreens]);

  const handleIndicatorSelect = (node: TreeNode) => {
      if (node.type === 'item' && node.data) {
          if (node.data.type === 'SAVED_SCREEN') {
              engine.loadSavedScreen(node.data.screen);
              setActiveResultView('current');
          } else if (node.data.type === 'INDICATOR') {
              engine.addLibraryItem(node.data.def, builderTab);
          }
      }
  };

  const handleSaveScreenLogic = () => {
      const name = prompt("Enter a name for this Strategy Combination:", "My Strategy");
      if (name) {
          onSaveScreen({
              id: `sc-${Date.now()}`,
              name,
              groups: engine.groups,
              rankingCriteria: engine.rankingCriteria,
              createdAt: new Date().toLocaleDateString()
          });
          alert("Full strategy combination saved!");
      }
  };

  // --- Handlers for Filter Builder ---
  const handleSaveGroupConfig = (group: any) => {
      const name = prompt("Enter a name for this filter combination:", "New Group Template");
      if (!name) return;
      setSavedFilterGroups(prev => [...prev, { id: `sg-${Date.now()}`, name, filters: group.filters }]);
  };
  
  const handleLoadGroupConfig = (savedGroup: any) => {
      const newFilters = savedGroup.filters.map((f: any) => ({ ...f, id: `f-${Date.now()}-${Math.random().toString(36).substr(2,9)}` }));
      engine.setGroups(prev => [...prev, { id: `g-${Date.now()}`, logic: 'AND', operator: 'AND', filters: newFilters }]);
  };

  const handleDeleteSavedGroup = (id: string) => {
      if(confirm("Delete this saved template?")) setSavedFilterGroups(prev => prev.filter(g => g.id !== id));
  };

  return (
    <div ref={containerRef} className="flex h-full w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-200 font-sans overflow-hidden transition-colors duration-300">
      
      {/* PANE 1: LEFT SIDEBAR */}
      <div className="bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col z-20 shrink-0 transition-colors" style={{ width: `${leftPaneWidth}px` }}>
        <div className="flex items-center px-4 py-3 border-b border-slate-200 dark:border-slate-800 shrink-0 bg-slate-50 dark:bg-slate-950">
            <Sigma className="w-4 h-4 text-indigo-500 mr-2" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">Formula System</span>
        </div>
        <div className="flex-1 overflow-hidden bg-white dark:bg-slate-900">
            <TreeBrowser data={indicatorTreeData} onSelect={handleIndicatorSelect} emptyMessage="No indicators found." />
        </div>
      </div>

      <div onMouseDown={() => startResize('LEFT')} className="w-[3px] bg-slate-100 dark:bg-slate-950 hover:bg-indigo-500 cursor-col-resize z-30 flex items-center justify-center group hover:w-[5px] transition-all -ml-[1px]">
          <div className="h-8 w-[1px] bg-slate-300 dark:bg-slate-700 group-hover:bg-white rounded-full"></div>
      </div>

      {/* PANE 2: MIDDLE */}
      <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 transition-colors relative min-w-0">
          
          <ScreenerToolbar 
              sourceIds={engine.sourceIds} onToggleSource={(id) => engine.setSourceIds(prev => id === 'all' ? (prev.includes('all') ? [] : ['all']) : (prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]))}
              availableWatchlists={availableWatchlists}
              includeSuspended={engine.includeSuspended} setIncludeSuspended={engine.setIncludeSuspended}
              dateMode={engine.dateMode} setDateMode={engine.setDateMode}
              targetOutputListId={engine.targetOutputListId} setTargetOutputListId={engine.setTargetOutputListId}
              isStale={engine.isStale} isExecuting={engine.isExecuting} onExecute={engine.runStrategy}
              TEMP_WATCHLIST_ID={TEMP_WATCHLIST_ID}
          />

          <div className="px-4 pt-4 pb-2 bg-slate-50 dark:bg-slate-950">
               <div className="flex items-center gap-1 bg-slate-200 dark:bg-slate-800 p-1 rounded-lg w-fit">
                   <button onClick={() => setBuilderTab('FILTER')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${builderTab === 'FILTER' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-white' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>Filter Rules</button>
                   <button onClick={() => setBuilderTab('RANK')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${builderTab === 'RANK' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-white' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>Ranking Rules</button>
               </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4">
              {builderTab === 'FILTER' ? (
                  <FilterBuilder 
                      groups={engine.groups}
                      filterCounts={engine.filterCounts}
                      groupCounts={engine.groupCounts}
                      onUpdateFilter={engine.updateFilter}
                      onRemoveFilter={engine.removeFilter}
                      onAddGroup={engine.addGroup}
                      onRemoveGroup={engine.removeGroup}
                      onToggleGroupLogic={engine.toggleGroupInternalLogic}
                      onToggleGroupOperator={engine.toggleGroupOperator}
                      onSaveGroupConfig={handleSaveGroupConfig}
                      onLoadGroupConfig={handleLoadGroupConfig}
                      savedGroups={savedFilterGroups}
                      onDeleteSavedGroup={handleDeleteSavedGroup}
                  />
              ) : (
                  <div className="space-y-2 max-w-3xl mx-auto">
                      {engine.rankingCriteria.length === 0 ? (
                         <div className="text-center py-10 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 mb-3"><TrendingUp className="w-6 h-6 text-slate-400" /></div>
                            <h3 className="text-sm font-bold text-slate-600 dark:text-slate-300">No Ranking Criteria</h3>
                            <p className="text-xs text-slate-400 mt-1 max-w-[200px] mx-auto">Add indicators from the library to score and sort your results.</p>
                         </div>
                      ) : (
                          engine.rankingCriteria.map(crit => (
                              <div key={crit.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-3 flex items-center gap-3 shadow-sm">
                                  <div className="bg-indigo-50 dark:bg-indigo-900/30 p-2 rounded text-indigo-600 dark:text-indigo-400 font-bold text-xs">#{engine.rankingCriteria.indexOf(crit) + 1}</div>
                                  <div className="flex-1">
                                      <div className="text-xs font-bold text-slate-700 dark:text-slate-200">{crit.name}</div>
                                      <div className="text-[10px] text-slate-400 mt-0.5">Def ID: {crit.defId}</div>
                                  </div>
                                  <div className="flex flex-col gap-1">
                                      <label className="text-[9px] font-bold text-slate-400 uppercase">Weight</label>
                                      <input type="range" min="1" max="10" value={crit.weight} onChange={(e) => engine.updateRankingCriterion(crit.id, { weight: parseInt(e.target.value) })} className="w-24 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
                                  </div>
                                  <div className="flex flex-col gap-1 items-end">
                                      <label className="text-[9px] font-bold text-slate-400 uppercase">Sort</label>
                                      <button onClick={() => engine.updateRankingCriterion(crit.id, { direction: crit.direction === 'asc' ? 'desc' : 'asc' })} className="flex items-center gap-1 px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded text-xs font-bold text-slate-600 dark:text-slate-300">
                                          {crit.direction === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                                          {crit.direction === 'asc' ? 'Asc' : 'Desc'}
                                      </button>
                                  </div>
                                  <button onClick={() => engine.removeRankingCriterion(crit.id)} className="p-2 text-slate-400 hover:text-rose-500"><X className="w-4 h-4" /></button>
                              </div>
                          ))
                      )}
                  </div>
              )}
          </div>
      </div>

      <div onMouseDown={() => startResize('RIGHT')} className="w-[3px] bg-slate-100 dark:bg-slate-950 hover:bg-indigo-500 cursor-col-resize z-30 flex items-center justify-center group hover:w-[5px] transition-all -ml-[1px]">
           <div className="h-8 w-[1px] bg-slate-300 dark:bg-slate-700 group-hover:bg-white rounded-full"></div>
      </div>

      {/* PANE 3: RIGHT SIDEBAR */}
      <div className="bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col z-20 shrink-0 transition-colors overflow-hidden" style={{ width: `${rightPaneWidth}px` }}>
          <div className="h-12 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between px-3 shrink-0">
               <div className="flex items-center gap-2">
                   <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
                       <button onClick={() => setActiveResultView('current')} className={`px-3 py-1 text-[10px] font-bold uppercase rounded-md transition-all flex items-center gap-1.5 ${activeResultView === 'current' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
                           <span>Latest</span>
                           <span className={`px-1.5 rounded-full text-[9px] ${activeResultView === 'current' ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300' : 'bg-slate-200 dark:bg-slate-900 text-slate-500'}`}>{engine.tempWatchlist.stocks.length}</span>
                       </button>
                       <button onClick={() => setActiveResultView('previous')} disabled={engine.tempWatchlistPrev.stocks.length === 0} className={`px-3 py-1 text-[10px] font-bold uppercase rounded-md transition-all flex items-center gap-1.5 ${activeResultView === 'previous' ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 disabled:opacity-50'}`} title="Previous Run Results">
                           <History className="w-3 h-3" />
                           <span>Previous</span>
                           {engine.tempWatchlistPrev.stocks.length > 0 && <span className={`px-1.5 rounded-full text-[9px] ${activeResultView === 'previous' ? 'bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300' : 'bg-slate-200 dark:bg-slate-900 text-slate-500'}`}>{engine.tempWatchlistPrev.stocks.length}</span>}
                       </button>
                   </div>
               </div>
               <div className="flex gap-1 relative">
                   <button onClick={handleSaveScreenLogic} className="p-1.5 text-slate-400 hover:text-indigo-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" title="Save Strategy"><Save className="w-4 h-4" /></button>
                   <button onClick={onNavigateToDashboard} className="p-1.5 text-slate-400 hover:text-indigo-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors" title="Go to Dashboard"><Layout className="w-4 h-4" /></button>
               </div>
          </div>

          <div className="flex-1 overflow-hidden relative">
              <Watchlist 
                  availableLists={[engine.tempWatchlist, engine.tempWatchlistPrev]}
                  selectedListIds={[activeResultView === 'current' ? TEMP_WATCHLIST_ID : TEMP_PREV_WATCHLIST_ID]}
                  onSelectionChange={() => {}}
                  exclusiveMode={false} onToggleExclusiveMode={() => {}}
                  customColumns={customColumns} onAddCustomColumn={onAddCustomColumn} onRemoveCustomColumn={onRemoveCustomColumn}
                  onSymbolSelect={(sym) => onSymbolSelect?.(sym)}
                  onAddStockToWatchlists={() => {}} onRemoveStockFromWatchlist={() => {}} 
                  onAddWatchlist={onAddWatchlist || (() => {})} onRenameWatchlist={onRenameWatchlist || (() => {})} onDeleteWatchlist={onDeleteWatchlist || (() => {})} onUpdateWatchlist={onUpdateWatchlist || (() => {})}
                  settings={settings} hideNavigation={true}
              />
          </div>
          
          <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex justify-center">
              <button onClick={handleSaveScreenLogic} className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-bold shadow-lg shadow-indigo-500/20 transition-all">Save Strategy</button>
          </div>
      </div>
    </div>
  );
};
