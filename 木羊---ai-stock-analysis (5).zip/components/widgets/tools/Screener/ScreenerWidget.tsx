
import React from 'react';
import { WidgetContext } from '../../../../types';
import { Screener } from './Screener';

export const ScreenerWidget: React.FC<WidgetContext> = ({ 
    savedScreens, 
    onSaveScreen, 
    onSaveWatchlist, 
    customColumns, 
    onAddCustomColumn, 
    onRemoveCustomColumn, 
    availableWatchlists, 
    settings,
    onSymbolSelect
}) => {
    // Adapter function for navigation - inside a widget we don't navigate away, maybe just log or no-op
    const handleNavigate = () => {
        // console.log("Already on dashboard"); 
    };

    return (
        <Screener 
            savedScreens={savedScreens}
            onSaveScreen={onSaveScreen}
            onSaveWatchlist={onSaveWatchlist}
            onNavigateToDashboard={handleNavigate}
            customColumns={customColumns}
            onAddCustomColumn={onAddCustomColumn}
            onRemoveCustomColumn={onRemoveCustomColumn}
            availableWatchlists={availableWatchlists}
            settings={settings}
            onSymbolSelect={onSymbolSelect}
        />
    );
};
