
import React, { useState, useEffect } from 'react';
import { WidgetContext, FormulaFile, BackendChartResponse } from '../../../../../types';
import { formulaService } from '../../../../../services/formulaService';
import { UniversalChart } from './UniversalChart';
import { Play, Save, FileCode, Plus, Search, Terminal, AlertCircle } from 'lucide-react';

export const FormulaEditorWidget: React.FC<WidgetContext> = ({ symbol, chartData }) => {
    // --- State ---
    const [formulas, setFormulas] = useState<FormulaFile[]>([]);
    const [activeId, setActiveId] = useState<string | null>(null);
    const [code, setCode] = useState<string>('');
    const [isDirty, setIsDirty] = useState(false);
    
    // Result State
    const [simulationResult, setSimulationResult] = useState<BackendChartResponse | null>(null);
    const [isRunning, setIsRunning] = useState(false);
    const [consoleOutput, setConsoleOutput] = useState<string[]>([]);

    // --- Init ---
    useEffect(() => {
        loadList();
    }, []);

    const loadList = async () => {
        const list = await formulaService.getFormulas();
        setFormulas(list);
        if (list.length > 0 && !activeId) {
            selectFormula(list[0]);
        }
    };

    const selectFormula = (file: FormulaFile) => {
        setActiveId(file.id);
        setCode(file.code);
        setIsDirty(false);
        setSimulationResult(null); // Clear previous run
        setConsoleOutput([`> Loaded ${file.name}`]);
    };

    const handleRun = async () => {
        if (!activeId) return;
        setIsRunning(true);
        setConsoleOutput(prev => [...prev, `> Compiling & Running on ${symbol}...`]);
        
        const result = await formulaService.runSimulation(code, symbol);
        
        setSimulationResult(result);
        if (result.logs) {
            setConsoleOutput(prev => [...prev, ...result.logs!]);
        }
        if (result.error) {
            setConsoleOutput(prev => [...prev, `ERROR: ${result.error}`]);
        }
        setIsRunning(false);
    };

    const handleSave = async () => {
        if (activeId) {
            await formulaService.saveFormula(activeId, code);
            setIsDirty(false);
            setConsoleOutput(prev => [...prev, `> Saved.`]);
        }
    };

    const activeFile = formulas.find(f => f.id === activeId);

    return (
        <div className="flex h-full bg-slate-900 text-slate-200 font-sans overflow-hidden">
            
            {/* 1. Sidebar (File Explorer) */}
            <div className="w-48 bg-slate-950 border-r border-slate-800 flex flex-col shrink-0">
                <div className="p-3 border-b border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">Explorer</span>
                    <button className="text-slate-400 hover:text-white"><Plus className="w-4 h-4" /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1">
                    {formulas.map(f => (
                        <button 
                            key={f.id}
                            onClick={() => selectFormula(f)}
                            className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-xs text-left transition-colors ${activeId === f.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-900'}`}
                        >
                            <FileCode className="w-3.5 h-3.5" />
                            <span className="truncate">{f.name}</span>
                        </button>
                    ))}
                </div>
            </div>

            {/* 2. Main Editor Area */}
            <div className="flex-1 flex flex-col min-w-0">
                
                {/* Toolbar */}
                <div className="h-10 border-b border-slate-800 bg-slate-900 flex items-center justify-between px-3 shrink-0">
                    <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-200">{activeFile?.name || 'Untitled'}</span>
                        {isDirty && <span className="w-2 h-2 rounded-full bg-amber-500" title="Unsaved Changes"></span>}
                    </div>
                    <div className="flex items-center gap-2">
                        <button 
                            onClick={handleSave}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded text-xs font-bold transition-colors"
                        >
                            <Save className="w-3.5 h-3.5" /> Save
                        </button>
                        <button 
                            onClick={handleRun}
                            disabled={isRunning}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-colors disabled:opacity-50"
                        >
                            {isRunning ? 'Running...' : <><Play className="w-3.5 h-3.5" /> Run</>}
                        </button>
                    </div>
                </div>

                {/* Split Pane: Code | Preview */}
                <div className="flex-1 flex overflow-hidden">
                    
                    {/* Code Editor (Simple Textarea for now) */}
                    <div className="w-1/2 border-r border-slate-800 flex flex-col">
                        <textarea 
                            value={code}
                            onChange={(e) => { setCode(e.target.value); setIsDirty(true); }}
                            className="flex-1 bg-slate-900 text-slate-300 font-mono text-sm p-4 outline-none resize-none leading-relaxed"
                            spellCheck={false}
                            placeholder="# Write your python strategy here..."
                        />
                        {/* Console / Logs */}
                        <div className="h-32 border-t border-slate-800 bg-black p-2 font-mono text-[10px] overflow-y-auto">
                            <div className="flex items-center gap-1 text-slate-500 mb-1">
                                <Terminal className="w-3 h-3" /> Output
                            </div>
                            {consoleOutput.map((line, i) => (
                                <div key={i} className="text-slate-400">{line}</div>
                            ))}
                        </div>
                    </div>

                    {/* Preview Panel */}
                    <div className="w-1/2 bg-slate-950 flex flex-col">
                        <div className="flex-1 relative">
                            {chartData.length > 0 ? (
                                <UniversalChart 
                                    data={simulationResult} 
                                    priceData={chartData} 
                                    height={500} 
                                />
                            ) : (
                                <div className="h-full flex items-center justify-center text-slate-600 text-xs">
                                    No base data available for {symbol}
                                </div>
                            )}
                            
                            {/* Overlay Loading State */}
                            {isRunning && (
                                <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-10">
                                    <div className="flex flex-col items-center gap-2">
                                        <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                                        <span className="text-xs text-indigo-400">Processing on backend...</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
