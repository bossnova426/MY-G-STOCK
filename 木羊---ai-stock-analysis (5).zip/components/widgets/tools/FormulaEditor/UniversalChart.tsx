
import React, { useEffect, useRef } from 'react';
import { createChart, ColorType, IChartApi, Time, CandlestickSeries, HistogramSeries, LineSeries, LineWidth } from 'lightweight-charts';
import { BackendChartResponse, StockDataPoint } from '../../../../../types';

interface UniversalChartProps {
    data: BackendChartResponse | null;
    priceData: StockDataPoint[]; // Underlying price (OHLC)
    height?: number;
}

export const UniversalChart: React.FC<UniversalChartProps> = ({ data, priceData, height = 300 }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const seriesRef = useRef<Map<string, any>>(new Map());

    // 1. Initialize Chart
    useEffect(() => {
        if (!containerRef.current) return;

        const chart = createChart(containerRef.current, {
            layout: {
                background: { type: ColorType.Solid, color: '#0f172a' }, // Dark Slate 900
                textColor: '#94a3b8',
            },
            grid: {
                vertLines: { color: '#1e293b' },
                horzLines: { color: '#1e293b' },
            },
            width: containerRef.current.clientWidth,
            height: height,
            timeScale: {
                borderColor: '#334155',
            }
        });

        // Add Main Candlestick Series (The Base)
        const mainSeries = chart.addSeries(CandlestickSeries, {
            upColor: '#10b981',
            downColor: '#f43f5e',
            borderVisible: false,
            wickUpColor: '#10b981',
            wickDownColor: '#f43f5e',
        });

        seriesRef.current.set('main_price', mainSeries);
        chartRef.current = chart;

        const handleResize = () => {
            if (containerRef.current && chartRef.current) {
                chartRef.current.applyOptions({ width: containerRef.current.clientWidth });
            }
        };
        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
            chart.remove();
            chartRef.current = null;
        };
    }, []);

    // 2. Render Price Data
    useEffect(() => {
        const mainSeries = seriesRef.current.get('main_price');
        if (mainSeries && priceData.length > 0) {
            const candles = priceData
                .filter(d => 
                    d.date && // Added date existence check
                    d.open !== undefined && d.open !== null && !isNaN(d.open) &&
                    d.high !== undefined && d.high !== null && !isNaN(d.high) &&
                    d.low !== undefined && d.low !== null && !isNaN(d.low) &&
                    d.close !== undefined && d.close !== null && !isNaN(d.close)
                )
                .map(d => ({
                    time: d.date as Time,
                    open: d.open,
                    high: d.high,
                    low: d.low,
                    close: d.close
                }));
            
            if (candles.length > 0) {
                mainSeries.setData(candles);
                chartRef.current?.timeScale().fitContent();
            }
        }
    }, [priceData]);

    // 3. THE UNIVERSAL RENDERER LOGIC
    // Parses the Backend JSON and draws layers
    useEffect(() => {
        if (!chartRef.current || !data) return;

        // Clean up previous dynamic series (except main_price)
        // Safely remove series and then delete from map to avoid iteration issues
        const keysToRemove: string[] = [];
        seriesRef.current.forEach((series, key) => {
            if (key !== 'main_price') {
                chartRef.current?.removeSeries(series);
                keysToRemove.push(key);
            }
        });
        keysToRemove.forEach(k => seriesRef.current.delete(k));

        // A. Render Plots (Lines, Histograms)
        data.plots.forEach(plot => {
            if (plot.panel === 'bottom') {
                // TODO: In a real app, you'd create a separate Chart instance for bottom panel
                // For this widget, we'll overlay or ignore. 
                // Let's overlay with a separate scale for now to keep it simple.
                console.warn("Multi-pane not fully implemented in simple preview, plotting on overlay");
            }

            let series: any;
            const commonOptions = {
                color: plot.color,
                lineWidth: (plot.width || 2) as LineWidth,
                title: plot.name,
                priceScaleId: plot.panel === 'bottom' ? 'left' : 'right' // Hack for simple overlay
            };

            if (plot.type === 'histogram') {
                series = chartRef.current!.addSeries(HistogramSeries, commonOptions);
            } else {
                series = chartRef.current!.addSeries(LineSeries, commonOptions);
            }

            // Map data to lightweight-charts format
            const seriesData = plot.data
                .filter(d => d.time && d.value !== null && !isNaN(d.value)) // Added strict time check
                .map(d => ({
                    time: d.time as Time,
                    value: d.value,
                    color: d.color // Histogram bars can have individual colors
                }));

            if (seriesData.length > 0) {
                series.setData(seriesData);
                seriesRef.current.set(plot.id, series);
            }
        });

        // B. Render Markers (Signals) on the Main Series
        if (data.markers && data.markers.length > 0) {
            const mainSeries = seriesRef.current.get('main_price');
            // CRITICAL FIX: Check if setMarkers function exists on the series object
            if (mainSeries && typeof mainSeries.setMarkers === 'function') {
                const lwcMarkers = data.markers
                    .filter(m => m.time) // Ensure marker has time
                    .map(m => ({
                        time: m.time as Time,
                        position: m.position,
                        color: m.color,
                        shape: m.shape,
                        text: m.text,
                        size: m.size || 1
                    }));
                mainSeries.setMarkers(lwcMarkers);
            }
        }

        // C. Render Segments (Drawings/Patterns)
        // Lightweight Charts doesn't have a native "Segment" primitive in the core API easily.
        // Trick: Use a LineSeries with broken data (nulls) to draw disconnected segments.
        if (data.segments && data.segments.length > 0) {
             data.segments.forEach((seg, idx) => {
                 const segLine = chartRef.current!.addSeries(LineSeries, {
                     color: seg.color,
                     lineWidth: (seg.width || 2) as LineWidth,
                     lineStyle: seg.style === 'dashed' ? 2 : 0,
                     lastValueVisible: false,
                     priceLineVisible: false,
                     crosshairMarkerVisible: false
                 });
                 
                 const p1 = { time: seg.x1 as Time, value: seg.y1 };
                 const p2 = { time: seg.x2 as Time, value: seg.y2 };
                 
                 // Sort by time
                 const lineData = [p1, p2].sort((a,b) => (a.time as string).localeCompare(b.time as string));
                 
                 segLine.setData(lineData);
                 seriesRef.current.set(`seg_${seg.id}_${idx}`, segLine);
             });
        }

    }, [data]);

    return (
        <div ref={containerRef} className="w-full h-full" />
    );
};
