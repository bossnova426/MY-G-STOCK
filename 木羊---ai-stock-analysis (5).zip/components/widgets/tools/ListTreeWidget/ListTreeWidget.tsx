
import React, { useMemo } from 'react';
import { WidgetContext } from '../../../../../types';
import { TreeBrowser, TreeNode } from '../../../../common/TreeBrowser';
import { Layers, Folder, Trash2, Edit2, PlusCircle, Box, Database, Share2, FolderPlus, Globe, PieChart, Grid, Factory, Landmark, BookOpen } from 'lucide-react';

export const ListTreeWidget: React.FC<WidgetContext> = ({ 
    availableWatchlists, 
    onDeleteWatchlist, 
    onRenameWatchlist, 
    onAddWatchlist,
}) => {

  // Parse flat watchlists into a folder tree based on naming convention "Folder/Subfolder/List"
  const treeData = useMemo(() => {
      const root: TreeNode[] = [
          { id: 'sys', label: 'System Boards', type: 'folder', icon: Database, color: 'text-blue-500', children: [], isExpanded: true },
          { id: 'usr', label: 'My Boards', type: 'folder', icon: Box, color: 'text-amber-500', children: [], isExpanded: true },
      ];

      availableWatchlists.forEach(list => {
          // Determine Root
          const isSystem = list.readOnly;
          const rootNode = isSystem ? root[0] : root[1];
          
          let targetChildren = rootNode.children!;
          
          // Check for folder path in name (e.g. "System/Markets/Shanghai")
          const parts = list.name.split('/');
          let pathParts = parts;
          if (isSystem && parts[0] === 'System') {
              pathParts = parts.slice(1);
          }
          
          const displayName = pathParts.pop()!; 
          
          // Build/Traverse Folders
          pathParts.forEach((folderName, idx) => {
              const folderId = `fld-${isSystem ? 's' : 'u'}-${pathParts.slice(0, idx+1).join('-')}`;
              let folder = targetChildren.find(n => n.label === folderName && n.type === 'folder');
              
              if (!folder) {
                  // Classify Icons based on Folder Name
                  let icon = isSystem ? Share2 : Folder;
                  let color = isSystem ? 'text-slate-500' : 'text-amber-400';
                  
                  if (folderName === 'Markets') {
                      icon = Globe;
                      color = 'text-indigo-500';
                  } else if (folderName === 'Blocks') {
                      icon = PieChart;
                      color = 'text-pink-500';
                  } else if (folderName === 'Concepts') {
                      icon = Grid;
                      color = 'text-purple-500';
                  } else if (folderName === 'Industries') {
                      icon = Factory;
                      color = 'text-orange-500';
                  } else if (folderName === 'TDX') {
                      icon = BookOpen;
                      color = 'text-slate-400';
                  } else if (folderName === 'SWS') {
                      icon = Landmark;
                      color = 'text-red-400';
                  }

                  folder = {
                      id: folderId,
                      label: folderName,
                      type: 'folder',
                      children: [],
                      icon: icon,
                      color: color
                  };
                  targetChildren.push(folder);
              }
              targetChildren = folder.children!;
          });

          // Add List Item
          targetChildren.push({
              id: list.id,
              label: displayName,
              type: 'item',
              icon: Layers,
              color: isSystem ? 'text-slate-400' : 'text-yellow-400',
              data: list
          });
      });

      return root;
  }, [availableWatchlists]);

  const handleSelect = (node: TreeNode) => {
      // Just select
  };

  // Context Menu or Action Button Handler
  const handleAction = (node: TreeNode) => {
      if (node.type === 'item' && node.data) {
          const list = node.data;
          if (list.readOnly) {
              alert("System lists cannot be modified.");
              return;
          }
          
          const action = prompt(`Manage Board: ${list.name}\nType 'rename' or 'delete'`, 'rename');
          if (action === 'delete') {
              if(confirm(`Delete "${list.name}"?`)) onDeleteWatchlist(list.id);
          } else if (action === 'rename') {
              const newName = prompt("New Name (use '/' for folders):", list.name);
              if (newName && newName !== list.name) onRenameWatchlist(list.id, newName);
          }
      }
  };

  const handleAdd = () => {
      const name = prompt("New Board Name (e.g. 'Strategies/Momentum'):", "New Folder/My Board");
      if(name) onAddWatchlist(name);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-200">
       {/* Toolbar */}
       <div className="flex justify-between items-center px-3 py-2 border-b border-slate-800 bg-slate-950">
           <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
               <Layers className="w-3.5 h-3.5" /> Board Manager
           </span>
           <div className="flex gap-1">
               <button 
                 onClick={handleAdd}
                 className="flex items-center gap-1.5 px-2 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium transition-colors"
                 title="Create New Board"
               >
                   <PlusCircle className="w-3.5 h-3.5" /> New Board
               </button>
           </div>
       </div>
       
       <div className="flex-1 min-h-0 overflow-hidden">
           <TreeBrowser 
             data={treeData} 
             onSelect={handleSelect}
             onAction={handleAction}
             emptyMessage="No boards found"
           />
       </div>
       
       {/* Footer Help */}
       <div className="px-3 py-2 text-[10px] text-slate-500 bg-slate-950 border-t border-slate-800">
           System data provided by KiteTDX
       </div>
    </div>
  );
};
