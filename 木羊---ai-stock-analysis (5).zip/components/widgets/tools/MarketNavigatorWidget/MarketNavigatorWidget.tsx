
import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { WidgetContext, CustomWatchlist } from '../../../../../types';
import { Search, Star, ChevronRight, Hash, TrendingUp, DollarSign, Box, Activity, Layers, Folder, Database, Globe, Cpu, Zap, LayoutGrid, Plus, MoreHorizontal, Edit2, Trash2, FolderPlus, Filter } from 'lucide-react';

// Helpers for color and icon generation based on string hash
const getSectionStyle = (name: string) => {
    const colors = [
        'text-rose-400', 'text-amber-400', 'text-emerald-400', 
        'text-blue-400', 'text-purple-400', 'text-cyan-400', 'text-indigo-400'
    ];
    const icons = [TrendingUp, Hash, DollarSign, Box, Activity, Layers, Globe, Cpu, Zap];
    
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    
    const cIndex = Math.abs(hash) % colors.length;
    const iIndex = Math.abs(hash) % icons.length;
    
    return { color: colors[cIndex], Icon: icons[iIndex] };
};

interface Section {
    id: string;
    title: string;
    items: CustomWatchlist[];
    isSystem: boolean;
}

export const MarketNavigatorWidget: React.FC<WidgetContext> = ({ availableWatchlists, onAddWatchlist, onRenameWatchlist, onDeleteWatchlist, onOpenScreener }) => {
  const [activeTab, setActiveTab] = useState<string>('ALL');
  const [filterText, setFilterText] = useState('');
  const [hoverItem, setHoverItem] = useState<string | null>(null);
  
  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, item: CustomWatchlist } | null>(null);

  // --- Data Processing ---
  const { sections, tabs } = useMemo(() => {
      const groups: Record<string, CustomWatchlist[]> = {};
      const roots: Set<string> = new Set();

      // 1. Group by Folder Path
      availableWatchlists.forEach(list => {
          const parts = list.name.split('/');
          let groupName = 'General';
          let rootName = 'Misc';

          if (parts.length > 1) {
              // Has hierarchy
              rootName = parts[0]; // Top level folder
              groupName = parts.slice(0, -1).join(' / '); // Full path
          } else {
              // Flat list
              rootName = list.readOnly ? 'System' : 'My Boards';
              groupName = rootName;
          }

          roots.add(rootName);

          if (!groups[groupName]) groups[groupName] = [];
          groups[groupName].push(list);
      });

      // 2. Convert to Array
      const sectionList: Section[] = Object.entries(groups).map(([title, items]) => ({
          id: title,
          title,
          items: items.sort((a, b) => a.name.localeCompare(b.name)),
          isSystem: items.some(i => i.readOnly) // Heuristic: if contains read-only, treat section as system-ish
      })).sort((a, b) => a.title.localeCompare(b.title));

      // 3. Build Tabs
      const tabList = ['ALL', 'USER', 'SYSTEM', ...Array.from(roots).sort()];

      return { sections: sectionList, tabs: tabList };
  }, [availableWatchlists]);

  // --- Filtering Logic ---
  const displaySections = useMemo(() => {
      return sections.filter(section => {
          // 1. Tab Filter
          let tabMatch = true;
          if (activeTab !== 'ALL') {
              if (activeTab === 'USER') {
                  tabMatch = section.items.some(i => !i.readOnly);
              } else if (activeTab === 'SYSTEM') {
                  tabMatch = section.items.some(i => i.readOnly);
              } else {
                  // Check if section title starts with the Tab name (Root folder)
                  tabMatch = section.title.startsWith(activeTab);
              }
          }

          if (!tabMatch) return false;

          // 2. Text Search
          if (filterText) {
              const lower = filterText.toLowerCase();
              const titleMatch = section.title.toLowerCase().includes(lower);
              const itemsMatch = section.items.some(i => i.name.toLowerCase().includes(lower));
              return titleMatch || itemsMatch;
          }

          return true;
      });
  }, [sections, activeTab, filterText]);

  // --- Actions ---
  const handleItemClick = (list: CustomWatchlist) => {
      // In a real app, this simulates navigation
      console.log("Navigating to:", list.id);
  };

  const handleContextMenu = (e: React.MouseEvent, item: CustomWatchlist) => {
      e.preventDefault();
      e.stopPropagation();
      setContextMenu({ x: e.clientX, y: e.clientY, item });
  };

  const handleAddBoard = (sectionTitle?: string) => {
      let defaultName = "New Board";
      if (sectionTitle && sectionTitle !== 'My Boards' && sectionTitle !== 'General' && sectionTitle !== 'System') {
          // If section is a path like "Strategies/Tech", pre-fill it
          defaultName = `${sectionTitle.replace(/ \/ /g, '/')}/New Board`;
      }
      const name = prompt("Create new board (use '/' for folders):", defaultName);
      if (name) {
          onAddWatchlist(name);
      }
  };

  const handleRename = () => {
      if (!contextMenu) return;
      const newName = prompt("Rename board:", contextMenu.item.name);
      if (newName && newName !== contextMenu.item.name) {
          onRenameWatchlist(contextMenu.item.id, newName);
      }
      setContextMenu(null);
  };

  const handleDelete = () => {
      if (!contextMenu) return;
      if (confirm(`Are you sure you want to delete "${contextMenu.item.name}"?`)) {
          onDeleteWatchlist(contextMenu.item.id);
      }
      setContextMenu(null);
  };

  const handleOpenInScreener = () => {
      if (!contextMenu) return;
      onOpenScreener([contextMenu.item.id]);
      setContextMenu(null);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900 text-slate-300 font-sans select-none overflow-hidden text-sm" onClick={() => setContextMenu(null)}>
      
      {/* 1. Top Quick Access Tabs */}
      <div className="flex flex-col border-b border-slate-700 bg-slate-800/50">
          <div className="flex items-center justify-between px-2 py-1">
              <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider flex items-center gap-1">
                  <LayoutGrid className="w-3 h-3" /> Navigator
              </div>
              <div className="flex items-center gap-2">
                  <div className="text-[9px] text-slate-600 font-mono">
                      {availableWatchlists.length} Boards
                  </div>
                  <button 
                    onClick={() => handleAddBoard()}
                    className="p-1 hover:bg-indigo-600 hover:text-white text-slate-400 rounded transition-colors"
                    title="Add New Board"
                  >
                      <Plus className="w-3.5 h-3.5" />
                  </button>
              </div>
          </div>
          
          <div className="flex flex-wrap gap-1 px-2 pb-2">
              {tabs.map(tab => {
                  const isActive = activeTab === tab;
                  const label = tab === 'USER' ? 'My Boards' : tab === 'SYSTEM' ? 'System' : tab === 'ALL' ? 'All' : tab;
                  const shortLabel = label.length > 12 ? label.substring(0, 10) + '..' : label;
                  
                  return (
                      <button
                          key={tab}
                          onClick={() => setActiveTab(tab)}
                          className={`
                              px-2 py-1 text-[10px] font-bold uppercase rounded-md transition-all border
                              ${isActive 
                                  ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm' 
                                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200 hover:border-slate-600'}
                          `}
                      >
                          {shortLabel}
                      </button>
                  );
              })}
          </div>
      </div>

      {/* 2. Main Directory Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-6 bg-slate-950">
          
          {/* Quick Filter */}
          <div className="relative mb-4">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
              <input 
                  type="text" 
                  value={filterText}
                  onChange={(e) => setFilterText(e.target.value)}
                  placeholder="Filter boards..." 
                  className="w-full bg-slate-900 border border-slate-800 rounded pl-8 pr-2 py-1.5 text-xs text-slate-200 focus:border-indigo-500 outline-none placeholder-slate-600 focus:bg-slate-800 transition-colors"
              />
          </div>

          {displaySections.length === 0 ? (
              <div className="text-center text-slate-500 text-xs py-8 italic">No boards found matching criteria.</div>
          ) : (
              displaySections.map(section => {
                  const { color, Icon } = getSectionStyle(section.title);
                  // Allow adding to this section if it's not purely system (heuristic)
                  // Or checking specifically against 'System'
                  const canAddToSection = !section.isSystem && !section.title.startsWith('System');

                  return (
                      <div key={section.id} className="animate-in fade-in duration-300">
                          {/* Section Header */}
                          <div className="flex items-center gap-2 mb-2 pb-1 border-b border-slate-800/50 group/header">
                              <Icon className={`w-3.5 h-3.5 ${color}`} />
                              <span className={`text-xs font-bold ${color} tracking-wide`}>
                                  {section.title.toUpperCase()}
                              </span>
                              <span className="text-[9px] text-slate-600 bg-slate-900 px-1.5 rounded-full border border-slate-800">
                                  {section.items.length}
                              </span>
                              
                              <div className="flex-1"></div>
                              
                              {canAddToSection && (
                                  <button 
                                    onClick={() => handleAddBoard(section.title)}
                                    className="opacity-0 group-hover/header:opacity-100 p-0.5 text-slate-500 hover:text-white hover:bg-slate-800 rounded transition-all"
                                    title="Add to this section"
                                  >
                                      <FolderPlus className="w-3.5 h-3.5" />
                                  </button>
                              )}
                          </div>
                          
                          {/* Grid Items */}
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                              {section.items.map(item => {
                                  // Display name logic: remove path prefix for cleaner look
                                  const displayName = item.name.split('/').pop();
                                  const isHover = hoverItem === item.id;
                                  const isMenuTarget = contextMenu?.item.id === item.id;
                                  
                                  return (
                                      <button
                                          key={item.id}
                                          onClick={() => handleItemClick(item)}
                                          onMouseEnter={() => setHoverItem(item.id)}
                                          onMouseLeave={() => setHoverItem(null)}
                                          onContextMenu={(e) => handleContextMenu(e, item)}
                                          className={`
                                              relative text-left px-2 py-1.5 rounded border transition-all truncate group/item
                                              ${isHover || isMenuTarget
                                                  ? 'bg-slate-800 text-white border-slate-700 shadow-sm z-10' 
                                                  : 'bg-slate-900/50 text-slate-400 border-transparent hover:text-slate-300'}
                                          `}
                                          title={item.name}
                                      >
                                          <div className="flex items-center gap-1.5 overflow-hidden">
                                              <span className={`w-1 h-1 rounded-full shrink-0 ${isHover ? 'bg-indigo-400' : 'bg-slate-600'}`}></span>
                                              <span className="text-xs truncate flex-1">{displayName}</span>
                                              <MoreHorizontal className={`w-3 h-3 text-slate-500 opacity-0 group-hover/item:opacity-100 ${isMenuTarget ? 'opacity-100' : ''}`} />
                                          </div>
                                      </button>
                                  );
                              })}
                          </div>
                      </div>
                  );
              })
          )}
          
          <div className="h-8"></div> {/* Bottom Spacer */}
      </div>

      {/* Context Menu Portal */}
      {contextMenu && createPortal(
          <div 
              className="fixed bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-[9999] py-1 min-w-[140px] flex flex-col text-slate-200 text-xs animate-in fade-in zoom-in-95"
              style={{ top: contextMenu.y, left: contextMenu.x }}
              onClick={(e) => e.stopPropagation()}
          >
              <div className="px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase border-b border-slate-700/50 mb-1 truncate max-w-[150px]">
                  {contextMenu.item.name.split('/').pop()}
              </div>
              <button onClick={handleOpenInScreener} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-700 hover:text-white transition-colors text-left">
                  <Filter className="w-3.5 h-3.5 text-emerald-400" /> Filter in Screener
              </button>
              {!contextMenu.item.readOnly && (
                  <>
                      <button onClick={handleRename} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-700 hover:text-white transition-colors text-left">
                          <Edit2 className="w-3.5 h-3.5 text-blue-400" /> Rename
                      </button>
                      <button onClick={handleDelete} className="flex items-center gap-2 px-3 py-2 hover:bg-slate-700 hover:text-rose-400 transition-colors text-left text-slate-400">
                          <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                  </>
              )}
          </div>,
          document.body
      )}
    </div>
  );
};
