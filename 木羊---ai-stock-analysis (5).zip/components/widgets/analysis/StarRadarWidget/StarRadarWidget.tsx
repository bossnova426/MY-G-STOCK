
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { StockDataPoint, WatchlistItem, CustomWatchlist, AppSettings } from '../../../../types';
import { generateStockData } from '../../../../services/mockDataService';
import { AVAILABLE_METRICS } from '../../../../constants'; 
import { Settings2, ZoomIn, ZoomOut, Move, RefreshCw, Play, Pause, Maximize, MousePointer2, Tag, Hash, Activity, ChevronDown, Folder, Database, LineChart, Calendar, Clock, Scaling } from 'lucide-react';
import { TreeBrowser, TreeNode } from '../../../common/TreeBrowser';

interface StarRadarProps {
  availableWatchlists: CustomWatchlist[];
  settings?: AppSettings;
}

interface Point {
  x: number;
  y: number;
  sizeVal: number; 
  date: string;
}

interface StockTrail {
  symbol: string;
  name: string;
  sector: string;
  color: string;
  points: Point[]; 
}

// Generate deterministic colors
const getColor = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const c = (hash & 0x00ffffff).toString(16).toUpperCase();
  return '#' + '00000'.substring(0, 6 - c.length) + c;
};

const BENCHMARKS = [
    { id: 'SPX', name: 'S&P 500' },
    { id: 'NDX', name: 'NASDAQ 100' },
    { id: 'DJI', name: 'Dow Jones' },
    { id: '000001.SS', name: 'Shanghai Comp' },
    { id: '399001.SZ', name: 'Shenzhen Comp' },
    { id: 'BTC', name: 'Bitcoin' },
];

const CONTEXT_PERIODS = [
    { label: '3M', days: 90 },
    { label: '6M', days: 180 },
    { label: '1Y', days: 365 },
    { label: '3Y', days: 1095 },
];

const DATA_FREQUENCIES = [
    { id: '1D', label: 'Daily', days: 1 },
    { id: '1W', label: 'Weekly', days: 5 },
    { id: '1M', label: 'Monthly', days: 21 },
    { id: '1Q', label: 'Quarterly', days: 63 },
    { id: '1Y', label: 'Yearly', days: 252 },
];

export const StarRadarWidget: React.FC<StarRadarProps> = ({ availableWatchlists, settings }) => {
  // --- Config State ---
  const [selectedListId, setSelectedListId] = useState<string>('default');
  const [xAxisKey, setXAxisKey] = useState<string>('change'); 
  const [yAxisKey, setYAxisKey] = useState<string>('vol');    
  const [sizeAxisKey, setSizeAxisKey] = useState<string>('fixed'); 
  
  const [frequency, setFrequency] = useState<string>('1D');
  const [trailLength, setTrailLength] = useState<number>(10); // Number of periods
  const [labelMode, setLabelMode] = useState<'symbol' | 'name' | 'none'>('symbol');
  
  // Market Context State
  const [benchmarkSymbol, setBenchmarkSymbol] = useState('SPX');
  const [contextPeriod, setContextPeriod] = useState(180); // Default 6M for better context

  // --- UI State ---
  const listBtnRef = useRef<HTMLButtonElement>(null);
  const [isListMenuOpen, setIsListMenuOpen] = useState(false);
  const [menuStyle, setMenuStyle] = useState<React.CSSProperties>({});

  // --- Viewport / Zoom State ---
  const containerRef = useRef<HTMLDivElement>(null);
  const [viewState, setViewState] = useState({
    scale: 1,
    offsetX: 0,
    offsetY: 0,
    isDragging: false,
    startX: 0,
    startY: 0
  });

  // --- Data Cache ---
  const [historyCache, setHistoryCache] = useState<Record<string, StockDataPoint[]>>({});
  const [marketIndexHistory, setMarketIndexHistory] = useState<StockDataPoint[]>([]);

  // Helper: Position Popover
  const toggleListMenu = () => {
      if (!isListMenuOpen && listBtnRef.current) {
          const rect = listBtnRef.current.getBoundingClientRect();
          setMenuStyle({
              position: 'fixed',
              top: rect.bottom + 4,
              left: rect.left,
              width: 250,
              zIndex: 9999
          });
      }
      setIsListMenuOpen(!isListMenuOpen);
  };

  // 1. Load Data
  const activeList = useMemo(() => 
    (availableWatchlists && availableWatchlists.length > 0) 
      ? (availableWatchlists.find(w => w.id === selectedListId) || availableWatchlists[0]) 
      : null, 
  [availableWatchlists, selectedListId]);

  const freqConfig = useMemo(() => DATA_FREQUENCIES.find(f => f.id === frequency) || DATA_FREQUENCIES[0], [frequency]);

  useEffect(() => {
    if (!activeList || !activeList.stocks) return;

    const newCache: Record<string, StockDataPoint[]> = {};
    // Calculate needed days: Trail Length * Frequency Days + Buffer
    // E.g. 10 * 21 (Monthly) = 210 days history needed
    const requiredDays = (trailLength + 5) * freqConfig.days + 100;

    activeList.stocks.forEach(stock => {
      // Simple cache check: if we have some data, assuming it's enough for mock. 
      // In real app, check length.
      if (!historyCache[stock.symbol] || historyCache[stock.symbol].length < requiredDays) {
        newCache[stock.symbol] = generateStockData(stock.symbol, requiredDays); 
      }
    });
    if (Object.keys(newCache).length > 0) {
      setHistoryCache(prev => ({ ...prev, ...newCache }));
    }
  }, [activeList, trailLength, freqConfig]);

  // Fetch Market Index (Ensure it covers the context period)
  useEffect(() => {
      setMarketIndexHistory(generateStockData(benchmarkSymbol, Math.max(contextPeriod, (trailLength * freqConfig.days) + 50)));
  }, [benchmarkSymbol, contextPeriod, trailLength, freqConfig]);

  // 2. Transform Data for Chart
  const chartData: StockTrail[] = useMemo(() => {
    if (!activeList || !activeList.stocks) return [];

    return activeList.stocks.map(stock => {
      const history = historyCache[stock.symbol];
      if (!history || history.length === 0) return null;

      // Resampling Logic
      // We want `trailLength` points, separated by `freqConfig.days`
      const points: Point[] = [];
      
      // Start from the most recent available date
      const latestIdx = history.length - 1;

      for (let i = 0; i < trailLength; i++) {
          const currentIdx = latestIdx - (i * freqConfig.days);
          const prevIdx = currentIdx - freqConfig.days;

          if (currentIdx < 0) break; // Not enough data

          const currentDay = history[currentIdx];
          const prevDay = prevIdx >= 0 ? history[prevIdx] : history[currentIdx]; // Fallback to same if start

          // Value Extractor with Frequency Awareness
          const getVal = (key: string) => {
              if (key === 'fixed') return 1;
              
              // 1. Check for specific period calculations
              if (key === 'change') {
                  // Percentage change over the period
                  if (prevDay.close === 0) return 0;
                  return ((currentDay.close - prevDay.close) / prevDay.close) * 100;
              }
              if (key === 'vol') {
                  // Approximate volume for the period (Daily Vol * Days)
                  // In real app, sum(volume[prevIdx...currentIdx])
                  return currentDay.volume * freqConfig.days; 
              }
              
              // 2. Fallback to point-in-time values
              if (key in currentDay) return currentDay[key];
              if (key in stock) return stock[key];
              if (key === 'price') return currentDay.close;
              
              return Math.random() * 100;
          };

          points.unshift({
              x: Number(getVal(xAxisKey)) || 0,
              y: Number(getVal(yAxisKey)) || 0,
              sizeVal: Number(getVal(sizeAxisKey)) || 1,
              date: currentDay.date
          });
      }

      // Allow single point trails (trailLength = 1)
      if (points.length < 1) return null;

      return {
        symbol: stock.symbol,
        name: stock.name || stock.symbol,
        sector: stock.sector || 'Misc',
        color: getColor(stock.sector || stock.symbol),
        points: points
      };
    }).filter(Boolean) as StockTrail[];
  }, [activeList, historyCache, xAxisKey, yAxisKey, sizeAxisKey, trailLength, freqConfig]);

  // 3. Determine Scale
  const bounds = useMemo(() => {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    let minSize = Infinity, maxSize = -Infinity;
    
    if (chartData.length === 0) return { minX: -10, maxX: 10, minY: -10, maxY: 10, minSize: 1, maxSize: 1 };

    chartData.forEach(trail => {
      trail.points.forEach(p => {
        if (p.x < minX) minX = p.x;
        if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.y > maxY) maxY = p.y;
        if (p.sizeVal < minSize) minSize = p.sizeVal;
        if (p.sizeVal > maxSize) maxSize = p.sizeVal;
      });
    });

    const paddingX = Math.abs(maxX - minX) * 0.1 || 1;
    const paddingY = Math.abs(maxY - minY) * 0.1 || 1;

    return {
      minX: minX - paddingX,
      maxX: maxX + paddingX,
      minY: minY - paddingY,
      maxY: maxY + paddingY,
      minSize,
      maxSize
    };
  }, [chartData]);

  // --- Interaction Handlers ---
  const handleWheel = (e: React.WheelEvent) => {
    e.stopPropagation();
    const scaleFactor = 0.1;
    const newScale = Math.max(0.5, Math.min(10, viewState.scale - Math.sign(e.deltaY) * scaleFactor));
    setViewState(prev => ({ ...prev, scale: newScale }));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setViewState(prev => ({ 
      ...prev, 
      isDragging: true, 
      startX: e.clientX - prev.offsetX, 
      startY: e.clientY - prev.offsetY 
    }));
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!viewState.isDragging) return;
    setViewState(prev => ({
      ...prev,
      offsetX: e.clientX - prev.startX,
      offsetY: e.clientY - prev.startY
    }));
  };

  const handleMouseUp = () => {
    setViewState(prev => ({ ...prev, isDragging: false }));
  };

  const resetView = () => {
    setViewState({ scale: 1, offsetX: 0, offsetY: 0, isDragging: false, startX: 0, startY: 0 });
  };

  // --- Tree Logic for Dropdown ---
  const listTreeData = useMemo(() => {
      if (!availableWatchlists) return [];
      const root: TreeNode[] = [];
      const sysRoot: TreeNode = { id: 'sys', label: 'System', type: 'folder', children: [], color: 'text-blue-500', isExpanded: true };
      const usrRoot: TreeNode = { id: 'usr', label: 'Custom', type: 'folder', children: [], color: 'text-amber-500', isExpanded: true };

      availableWatchlists.forEach(list => {
          const isSystem = list.readOnly;
          const targetRoot = isSystem ? sysRoot : usrRoot;
          const parts = list.name.split('/');
          const displayName = parts.pop()!;
          let current = targetRoot.children!;

          parts.forEach((folderName, idx) => {
              const folderId = `f-${isSystem?'s':'u'}-${parts.slice(0,idx+1).join('-')}`;
              let folder = current.find(n => n.id === folderId);
              if (!folder) {
                  folder = {
                      id: folderId,
                      label: folderName,
                      type: 'folder',
                      children: [],
                      color: isSystem ? 'text-blue-400' : 'text-amber-400'
                  };
                  current.push(folder);
              }
              current = folder.children!;
          });

          current.push({
              id: list.id,
              label: displayName,
              type: 'item',
              icon: selectedListId === list.id ? Activity : Folder,
              color: selectedListId === list.id ? 'text-indigo-500' : 'text-slate-400',
              data: list
          });
      });

      if (sysRoot.children!.length > 0) root.push(sysRoot);
      if (usrRoot.children!.length > 0) root.push(usrRoot);
      return root;
  }, [availableWatchlists, selectedListId]);

  const handleListSelect = (node: TreeNode) => {
      if (node.type === 'item') {
          setSelectedListId(node.id);
          setIsListMenuOpen(false);
      }
  };

  // --- Projection Helpers ---
  const mapX = (val: number) => ((val - bounds.minX) / (bounds.maxX - bounds.minX)) * 100;
  const mapY = (val: number) => 100 - ((val - bounds.minY) / (bounds.maxY - bounds.minY)) * 100;
  
  const getRadius = (val: number) => {
      if (sizeAxisKey === 'fixed') return 3;
      const minR = 2, maxR = 10; // Slightly larger range for visibility
      if (bounds.maxSize === bounds.minSize) return 4;
      return minR + ((val - bounds.minSize) / (bounds.maxSize - bounds.minSize)) * (maxR - minR);
  };

  const metricOptions = useMemo(() => {
      const groups: Record<string, any[]> = { 'Basic': [], 'Technical': [], 'Fundamental': [] };
      AVAILABLE_METRICS.forEach(m => {
          if (m.id === 'price' || m.id === 'change' || m.id === 'vol') groups['Basic'].push(m);
          else if (['pe', 'eps', 'mkt_cap'].some(k => m.id.includes(k))) groups['Fundamental'].push(m);
          else groups['Technical'].push(m);
      });
      return groups;
  }, []);

  if (!activeList) {
      return (
          <div className="flex items-center justify-center h-full bg-white dark:bg-slate-950 text-slate-400 text-xs">
              <span>No watchlist available. Please add a watchlist to view the radar.</span>
          </div>
      );
  }

  return (
    <div 
        className="flex flex-col h-full bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-200 select-none overflow-hidden rounded-xl border border-slate-200 dark:border-slate-800 transition-colors"
        onClick={() => setIsListMenuOpen(false)}
    >
      
      {/* 1. Adaptive Toolbar */}
      <div className="flex flex-wrap items-center gap-2 p-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 z-10 text-xs">
        
        {/* X Axis */}
        <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 mr-2 uppercase">X</span>
            <select 
                value={xAxisKey} 
                onChange={e => setXAxisKey(e.target.value)}
                className="bg-transparent border-none outline-none text-slate-700 dark:text-slate-200 text-xs font-medium cursor-pointer w-24"
            >
                {Object.entries(metricOptions).map(([grp, opts]) => (
                    <optgroup key={grp} label={grp} className="dark:bg-slate-800">
                        {(opts as any[]).map(opt => <option key={opt.id} value={opt.id}>{opt.name}</option>)}
                    </optgroup>
                ))}
            </select>
        </div>

        {/* Y Axis */}
        <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 mr-2 uppercase">Y</span>
            <select 
                value={yAxisKey} 
                onChange={e => setYAxisKey(e.target.value)}
                className="bg-transparent border-none outline-none text-slate-700 dark:text-slate-200 text-xs font-medium cursor-pointer w-24"
            >
                {Object.entries(metricOptions).map(([grp, opts]) => (
                    <optgroup key={grp} label={grp} className="dark:bg-slate-800">
                        {(opts as any[]).map(opt => <option key={opt.id} value={opt.id}>{opt.name}</option>)}
                    </optgroup>
                ))}
            </select>
        </div>

        {/* Size Axis */}
        <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 shadow-sm">
            <Scaling className="w-3 h-3 text-slate-400 mr-1.5" />
            <select 
                value={sizeAxisKey} 
                onChange={e => setSizeAxisKey(e.target.value)}
                className="bg-transparent border-none outline-none text-slate-700 dark:text-slate-200 text-xs font-medium cursor-pointer w-20"
            >
                <option value="fixed">Fixed</option>
                {Object.entries(metricOptions).map(([grp, opts]) => (
                    <optgroup key={grp} label={grp} className="dark:bg-slate-800">
                        {(opts as any[]).map(opt => <option key={opt.id} value={opt.id}>{opt.name}</option>)}
                    </optgroup>
                ))}
            </select>
        </div>

        {/* Frequency Selector (Updated Color) */}
        <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 shadow-sm">
            <Clock className="w-3 h-3 text-slate-400 mr-1.5" />
            <select 
                value={frequency} 
                onChange={e => setFrequency(e.target.value)}
                className="bg-transparent border-none outline-none text-slate-700 dark:text-slate-200 text-xs font-medium cursor-pointer w-16"
            >
                {DATA_FREQUENCIES.map(f => (
                    <option key={f.id} value={f.id}>{f.label}</option>
                ))}
            </select>
        </div>

        {/* List Selector with Tree Popup */}
        <button 
            ref={listBtnRef}
            onClick={(e) => { e.stopPropagation(); toggleListMenu(); }}
            className="flex items-center gap-2 px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md shadow-sm hover:border-indigo-500 transition-colors max-w-[140px]"
        >
            <Database className="w-3.5 h-3.5 text-indigo-500" />
            <span className="text-xs font-medium text-slate-700 dark:text-slate-200 truncate flex-1 text-left">
                {activeList.name.split('/').pop()}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
        </button>

        {isListMenuOpen && createPortal(
            <div 
                style={menuStyle}
                className="fixed bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl flex flex-col animate-in fade-in zoom-in-95"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="p-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-bold text-[10px] text-slate-500 uppercase shrink-0">
                    Select Data Source
                </div>
                <div className="h-64 relative">
                    <TreeBrowser 
                        data={listTreeData}
                        onSelect={handleListSelect}
                        enableSearch={true}
                        emptyMessage="No lists available"
                        selectedId={selectedListId}
                    />
                </div>
            </div>,
            document.body
        )}

        {/* Label Toggle */}
        <button 
            onClick={() => setLabelMode(prev => prev === 'symbol' ? 'name' : prev === 'name' ? 'none' : 'symbol')}
            className="flex items-center gap-1 px-2 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md text-slate-600 dark:text-slate-300 hover:text-indigo-500 shadow-sm transition-colors"
            title="Toggle Labels"
        >
            <Tag className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold uppercase w-8 text-center">{labelMode === 'none' ? 'OFF' : labelMode === 'name' ? 'NAME' : 'SYM'}</span>
        </button>

        <div className="flex-1"></div>

        {/* View Controls */}
        <div className="flex items-center gap-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md p-0.5 shadow-sm">
            <button onClick={() => setViewState(p => ({...p, scale: p.scale * 1.1}))} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500"><ZoomIn className="w-3.5 h-3.5" /></button>
            <button onClick={() => setViewState(p => ({...p, scale: p.scale * 0.9}))} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500"><ZoomOut className="w-3.5 h-3.5" /></button>
            <button onClick={resetView} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500"><Maximize className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      {/* 2. Main Canvas */}
      <div 
        ref={containerRef}
        className="flex-1 relative overflow-hidden cursor-move bg-slate-50 dark:bg-slate-900/50"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
          {/* Grid Background */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-20 dark:opacity-10"
            style={{ 
                backgroundSize: `${50 * viewState.scale}px ${50 * viewState.scale}px`,
                backgroundPosition: `${viewState.offsetX}px ${viewState.offsetY}px`,
                backgroundImage: `linear-gradient(to right, ${settings?.theme === 'dark' ? '#94a3b8' : '#cbd5e1'} 1px, transparent 1px), linear-gradient(to bottom, ${settings?.theme === 'dark' ? '#94a3b8' : '#cbd5e1'} 1px, transparent 1px)`
            }}
          />

          {/* SVG Layer */}
          <svg className="w-full h-full pointer-events-none">
              <g transform={`translate(${viewState.offsetX}, ${viewState.offsetY}) scale(${viewState.scale}) transform-origin(center)`}>
                  
                  {/* Zero Lines (Axes) */}
                  {bounds.minX < 0 && bounds.maxX > 0 && (
                      <line x1={`${mapX(0)}%`} y1="0" x2={`${mapX(0)}%`} y2="100%" stroke={settings?.theme === 'dark' ? '#475569' : '#94a3b8'} strokeWidth="0.5" strokeDasharray="4 4" />
                  )}
                  {bounds.minY < 0 && bounds.maxY > 0 && (
                      <line x1="0" y1={`${mapY(0)}%`} x2="100%" y2={`${mapY(0)}%`} stroke={settings?.theme === 'dark' ? '#475569' : '#94a3b8'} strokeWidth="0.5" strokeDasharray="4 4" />
                  )}

                  {/* Stock Trails */}
                  {chartData.map((stock) => {
                      const points = stock.points;
                      const lastPoint = points[points.length - 1];
                      if (!lastPoint) return null;

                      return (
                          <g key={stock.symbol}>
                              {/* 1. Connection Lines (Draw first so they are behind bubbles) */}
                              {points.map((p, i) => {
                                  if (i === 0) return null;
                                  const prev = points[i-1];
                                  const opacity = (i / points.length) * 0.4; // Fainter lines
                                  return (
                                      <line 
                                        key={`line-${i}`}
                                        x1={`${mapX(prev.x)}%`} y1={`${mapY(prev.y)}%`}
                                        x2={`${mapX(p.x)}%`} y2={`${mapY(p.y)}%`}
                                        stroke={stock.color}
                                        strokeWidth={0.5 / viewState.scale}
                                        strokeOpacity={opacity}
                                        strokeLinecap="round"
                                      />
                                  );
                              })}

                              {/* 2. Bubbles for *Every* Point in Trail */}
                              {points.map((p, i) => {
                                  const isHead = i === points.length - 1;
                                  // Opacity increases towards the head
                                  const opacity = 0.2 + ((i / points.length) * 0.8); 
                                  
                                  return (
                                      <circle 
                                        key={`dot-${i}`}
                                        cx={`${mapX(p.x)}%`} 
                                        cy={`${mapY(p.y)}%`} 
                                        r={getRadius(p.sizeVal) / viewState.scale} 
                                        fill={stock.color} 
                                        fillOpacity={isHead ? 1.0 : opacity * 0.6} // Trail is semi-transparent
                                        stroke={isHead ? (settings?.theme === 'dark' ? '#020617' : '#ffffff') : 'none'} 
                                        strokeWidth={isHead ? 1 / viewState.scale : 0}
                                      />
                                  );
                              })}

                              {/* Label (Only on Head) */}
                              {labelMode !== 'none' && (
                                  <text 
                                    x={`${mapX(lastPoint.x)}%`} 
                                    y={`${mapY(lastPoint.y)}%`} 
                                    dx={(getRadius(lastPoint.sizeVal) / viewState.scale) + (4 / viewState.scale)} 
                                    dy={1 / viewState.scale} 
                                    fill={stock.color} 
                                    fontSize={10 / viewState.scale} 
                                    fontWeight="bold"
                                    opacity="0.9"
                                    style={{ textShadow: settings?.theme === 'dark' ? '0px 0px 2px black' : '0px 0px 2px white' }}
                                  >
                                      {labelMode === 'symbol' ? stock.symbol : stock.name}
                                  </text>
                              )}
                          </g>
                      );
                  })}
              </g>
          </svg>
      </div>

      {/* 3. Market Context Chart (Bottom Panel) */}
      <div className="h-24 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 relative flex flex-col">
          {/* Bottom Bar Header */}
          <div className="flex items-center justify-between px-2 py-1 border-b border-slate-100 dark:border-slate-800/50 bg-slate-50 dark:bg-slate-900/50">
              <div className="flex items-center gap-2">
                  <div className="text-[9px] font-bold text-slate-400 uppercase flex items-center gap-1">
                      <Activity className="w-3 h-3" /> Market Trend
                  </div>
                  {/* Benchmark Selector */}
                  <select 
                      value={benchmarkSymbol}
                      onChange={e => setBenchmarkSymbol(e.target.value)}
                      className="bg-transparent text-[10px] font-bold text-indigo-600 dark:text-indigo-400 outline-none border-none cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800 rounded px-1"
                  >
                      {BENCHMARKS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
              </div>

              <div className="flex items-center gap-2">
                  {/* Period Selector (Context Window) */}
                  <div className="flex bg-slate-200 dark:bg-slate-800 rounded p-0.5">
                      {CONTEXT_PERIODS.map(p => (
                          <button
                              key={p.label}
                              onClick={() => setContextPeriod(p.days)}
                              className={`px-1.5 py-0.5 text-[9px] font-bold rounded-sm transition-colors ${contextPeriod === p.days ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                          >
                              {p.label}
                          </button>
                      ))}
                  </div>
              </div>
          </div>
          
          <div className="flex-1 w-full relative group">
              {marketIndexHistory.length > 0 && (
                  <svg className="w-full h-full" preserveAspectRatio="none">
                      {/* Calculate Path for Index */}
                      {(() => {
                          const prices = marketIndexHistory.slice(-contextPeriod).map(d => d.close);
                          if (prices.length === 0) return null;

                          const minP = Math.min(...prices);
                          const maxP = Math.max(...prices);
                          const range = maxP - minP;
                          const w = 100 / prices.length;
                          
                          const d = prices.map((p, i) => 
                              `${i===0 ? 'M' : 'L'} ${i * w}% ${100 - ((p - minP) / range) * 80 - 10}%`
                          ).join(' ');

                          // Highlight Active Trail Range
                          // Calculate how many *days* the current trail covers
                          const trailDays = trailLength * freqConfig.days;
                          
                          // Width of highlight region relative to contextPeriod
                          const highlightPct = Math.min(100, (trailDays / contextPeriod) * 100);
                          const startPct = 100 - highlightPct;

                          return (
                              <>
                                  {/* Full Trend Line (Context) */}
                                  <path d={d} fill="none" stroke={settings?.theme === 'dark' ? '#475569' : '#cbd5e1'} strokeWidth="1" vectorEffect="non-scaling-stroke" opacity="0.5" />
                                  
                                  {/* Active Window Highlight Zone */}
                                  <rect x={`${startPct}%`} y="0" width={`${highlightPct}%`} height="100%" fill="currentColor" className="text-indigo-500" fillOpacity="0.05" />
                                  
                                  {/* Active Trend Segment (The tail visible in Radar) */}
                                  {/* We redraw the segment of the line that corresponds to the trail */}
                                  <path 
                                    d={prices.map((p, i) => {
                                        // Only draw points that are within the last `trailDays`
                                        const totalPts = prices.length;
                                        const ptIdx = i;
                                        // Is this point within the last `trailDays`?
                                        // We have `totalPts` representing `contextPeriod` days approx.
                                        // Simple approximation: index > totalPts - trailDays
                                        // Since data is generated daily, index matches day count roughly.
                                        if (ptIdx >= totalPts - trailDays) {
                                            const x = i * w;
                                            const y = 100 - ((p - minP) / range) * 80 - 10;
                                            return `${i === totalPts - trailDays ? 'M' : 'L'} ${x}% ${y}%`;
                                        }
                                        return '';
                                    }).join(' ')} 
                                    fill="none" 
                                    stroke="currentColor" 
                                    className="text-indigo-500" 
                                    strokeWidth="1.5" 
                                    vectorEffect="non-scaling-stroke" 
                                  />
                              </>
                          );
                      })()}
                  </svg>
              )}
          </div>

          {/* History Slider Control overlaying the chart */}
          <div className="absolute bottom-1 right-2 left-2 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-[9px] text-slate-400 whitespace-nowrap">Trail: {trailLength} {freqConfig.label}</span>
              <input 
                  type="range" min="1" max="20" 
                  value={trailLength} 
                  onChange={e => setTrailLength(Number(e.target.value))}
                  className="w-full h-1 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
          </div>
      </div>
    </div>
  );
};
