
import React from 'react';
import { FundamentalData, AppSettings } from '../../../../types';
import { I18N } from '../../../../constants';

interface StatsTableProps {
    data: FundamentalData | null;
    settings?: AppSettings;
}

export const StatsTable: React.FC<StatsTableProps> = ({ data, settings }) => {
  const lang = settings?.language || 'en';
  const t = I18N[lang];

  if (!data) {
      return (
          <div className="h-full flex items-center justify-center text-slate-500 text-xs">
              {t.loading}
          </div>
      );
  }

  const stats = [
    { label: t.marketCap, value: data.marketCap },
    { label: t.peRatio, value: data.peRatio },
    { label: t.eps, value: data.eps },
    { label: t.beta, value: data.beta },
    { label: t.divYield, value: data.divYield },
    { label: t.nextEarnings, value: data.nextEarnings },
    { label: t.high52, value: data.high52 },
    { label: t.low52, value: data.low52 },
  ];

  return (
    <div className="h-full p-4 overflow-y-auto custom-scrollbar">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-slate-800/40 p-3 rounded-lg border border-slate-700/50">
            <div className="text-xs text-slate-500 uppercase font-semibold mb-1">{stat.label}</div>
            <div className="text-sm font-mono text-slate-200">{stat.value}</div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-slate-800">
        <h4 className="text-xs font-semibold text-slate-400 mb-2 uppercase">Performance</h4>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-500">YTD Return</span>
              <span className="text-emerald-400">+12.4%</span>
            </div>
            <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 w-[12%]"></div>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-500">1 Year</span>
              <span className="text-emerald-400">+24.1%</span>
            </div>
            <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 w-[24%]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsTable;
