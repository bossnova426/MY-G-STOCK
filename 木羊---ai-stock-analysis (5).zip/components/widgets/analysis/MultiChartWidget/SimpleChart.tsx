
import React, { useEffect, useRef } from 'react';
import { createChart, ColorType, IChartApi, ISeriesApi, Time, CandlestickSeries } from 'lightweight-charts';
import { StockDataPoint, AppSettings } from '../../../../types';

interface SimpleChartProps {
    data: StockDataPoint[];
    symbol: string;
    name?: string;
    settings?: AppSettings;
    onClick?: () => void;
    isUp: boolean;
}

export const SimpleChart: React.FC<SimpleChartProps> = ({ data, symbol, name, settings, onClick, isUp }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);

    useEffect(() => {
        if (!containerRef.current) return;

        const isDark = settings?.theme === 'dark';
        const upColor = settings?.modules.chart.upColor || '#10b981';
        const downColor = settings?.modules.chart.downColor || '#f43f5e';
        const textColor = isDark ? '#64748b' : '#94a3b8';
        const bgColor = isDark ? '#0f172a' : '#ffffff';

        const chart = createChart(containerRef.current, {
            layout: {
                background: { type: ColorType.Solid, color: 'transparent' }, // Transparent to blend with cell
                textColor: textColor,
                attributionLogo: false,
            },
            grid: {
                vertLines: { visible: false },
                horzLines: { visible: false },
            },
            rightPriceScale: {
                visible: true,
                borderVisible: false,
                scaleMargins: { top: 0.1, bottom: 0.1 },
            },
            timeScale: {
                visible: false,
                borderVisible: false,
            },
            crosshair: {
                vertLine: { visible: false, labelVisible: false },
                horzLine: { visible: false, labelVisible: false },
            },
            handleScroll: false,
            handleScale: false,
            width: containerRef.current.clientWidth,
            height: containerRef.current.clientHeight,
        });

        const series = chart.addSeries(CandlestickSeries, {
            upColor: upColor,
            downColor: downColor,
            borderVisible: false,
            wickUpColor: upColor,
            wickDownColor: downColor,
        });

        seriesRef.current = series;
        chartRef.current = chart;

        const handleResize = () => {
            if (containerRef.current && chartRef.current) {
                chartRef.current.applyOptions({
                    width: containerRef.current.clientWidth,
                    height: containerRef.current.clientHeight,
                });
            }
        };

        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
            chart.remove();
        };
    }, [settings]);

    // Update Data
    useEffect(() => {
        if (seriesRef.current && data && data.length > 0) {
            const chartData = data
                .filter(d => 
                    d.date && 
                    d.open !== undefined && d.open !== null && !isNaN(Number(d.open)) &&
                    d.high !== undefined && d.high !== null && !isNaN(Number(d.high)) &&
                    d.low !== undefined && d.low !== null && !isNaN(Number(d.low)) &&
                    d.close !== undefined && d.close !== null && !isNaN(Number(d.close))
                )
                .map(d => ({
                    time: d.date as Time,
                    open: Number(d.open),
                    high: Number(d.high),
                    low: Number(d.low),
                    close: Number(d.close),
                }));
            
            if (chartData.length > 0) {
                seriesRef.current.setData(chartData);
                chartRef.current?.timeScale().fitContent();
            }
        }
    }, [data]);

    const lastPrice = data && data.length > 0 ? data[data.length - 1].close : 0;
    const changePct = data && data.length > 1 
        ? ((data[data.length - 1].close - data[data.length - 2].close) / data[data.length - 2].close) * 100 
        : 0;
    
    const colorClass = changePct >= 0 ? 'text-emerald-500' : 'text-rose-500';

    return (
        <div 
            className="flex flex-col w-full h-full border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden hover:border-indigo-500 transition-colors cursor-pointer group relative"
            onClick={onClick}
        >
            {/* Header Overlay */}
            <div className="absolute top-0 left-0 right-0 p-2 flex justify-between items-start z-10 bg-gradient-to-b from-white/90 to-transparent dark:from-slate-900/90 pointer-events-none">
                <div>
                    <div className="font-bold text-xs text-slate-800 dark:text-slate-200">{symbol}</div>
                    <div className="text-[10px] text-slate-500 truncate max-w-[100px]">{name}</div>
                </div>
                <div className={`text-right ${colorClass}`}>
                    <div className="font-mono text-xs font-bold">{typeof lastPrice === 'number' ? lastPrice.toFixed(2) : '0.00'}</div>
                    <div className="text-[9px]">{typeof changePct === 'number' ? (changePct > 0 ? '+' : '') + changePct.toFixed(2) : '0.00'}%</div>
                </div>
            </div>

            {/* Chart Canvas */}
            <div ref={containerRef} className="flex-1 w-full" />
        </div>
    );
};
