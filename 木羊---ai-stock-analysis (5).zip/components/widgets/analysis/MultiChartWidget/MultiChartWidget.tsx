
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { WidgetContext, StockDataPoint, WatchlistItem } from '../../../../types';
import { SimpleChart } from './SimpleChart';
import { dataService } from '../../../../services/dataAdapter';
import { ChevronLeft, ChevronRight, Grid3x3, LayoutGrid, Maximize2, Settings, List, Link as LinkIcon } from 'lucide-react';

export const MultiChartWidget: React.FC<WidgetContext> = ({ 
    availableWatchlists, 
    widgetConfig, 
    onUpdateConfig, 
    onSymbolSelect,
    settings,
    activeList: activeListFromContext 
}) => {
    // --- Config ---
    const rows = widgetConfig?.rows || 2;
    const cols = widgetConfig?.cols || 2;
    const selectedListId = widgetConfig?.watchlistId || 'default';
    const sourceMode = widgetConfig?.sourceMode || 'static'; // 'static' | 'linked'
    
    // --- State ---
    const [startIndex, setStartIndex] = useState(0);
    const [gridData, setGridData] = useState<Record<string, StockDataPoint[]>>({});
    const [showSettings, setShowSettings] = useState(false);
    
    const containerRef = useRef<HTMLDivElement>(null);

    // --- Derived Data ---
    const pageSize = rows * cols;
    
    const visibleStocks = useMemo(() => {
        let source: WatchlistItem[] = [];
        if (sourceMode === 'linked' && activeListFromContext) {
             source = activeListFromContext;
        } else {
             const list = availableWatchlists.find(w => w.id === selectedListId) || availableWatchlists[0];
             source = list?.stocks || [];
        }
        return source.slice(startIndex, startIndex + pageSize);
    }, [sourceMode, activeListFromContext, availableWatchlists, selectedListId, startIndex, pageSize]);

    const totalCount = useMemo(() => {
        if (sourceMode === 'linked' && activeListFromContext) return activeListFromContext.length;
        const list = availableWatchlists.find(w => w.id === selectedListId);
        return list?.stocks.length || 0;
    }, [sourceMode, activeListFromContext, availableWatchlists, selectedListId]);

    // --- Data Fetching ---
    useEffect(() => {
        let isMounted = true;
        const fetchBatch = async () => {
            const newData: Record<string, StockDataPoint[]> = {};
            
            // Only fetch what we don't have (or implementing a cache strategy)
            const promises = visibleStocks.map(async (stock) => {
                if (gridData[stock.symbol]) return; 
                try {
                    const history = await dataService.getHistory(stock.symbol, 60); 
                    if (isMounted) newData[stock.symbol] = history;
                } catch (e) {
                    console.error(`Failed to load ${stock.symbol}`, e);
                }
            });

            await Promise.all(promises);
            if (isMounted && Object.keys(newData).length > 0) {
                setGridData(prev => ({ ...prev, ...newData }));
            }
        };

        if (visibleStocks.length > 0) {
            fetchBatch();
        }

        return () => { isMounted = false; };
    }, [visibleStocks]);

    // --- Navigation Handlers ---
    const handleNext = () => {
        if (startIndex + pageSize < totalCount) {
            setStartIndex(prev => prev + pageSize);
        }
    };

    const handlePrev = () => {
        if (startIndex - pageSize >= 0) {
            setStartIndex(prev => prev - pageSize);
        } else {
            setStartIndex(0);
        }
    };

    const handleWheel = (e: React.WheelEvent) => {
        // Prevent default page scroll if we can scroll locally
        if (e.deltaY > 0) {
            handleNext();
        } else {
            handlePrev();
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'ArrowDown' || e.key === 'PageDown') {
            e.preventDefault();
            handleNext();
        } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
            e.preventDefault();
            handlePrev();
        }
    };

    // --- Config Handlers ---
    const handleConfigChange = (key: string, val: any) => {
        onUpdateConfig({ 
            rows, 
            cols, 
            watchlistId: selectedListId, 
            sourceMode,
            [key]: val 
        });
        // Reset index if data source changes
        if (key === 'watchlistId' || key === 'sourceMode') setStartIndex(0);
    };

    return (
        <div 
            className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 outline-none group"
            onWheel={handleWheel}
            onKeyDown={handleKeyDown}
            tabIndex={0} // Make focusable for keyboard events
            ref={containerRef}
        >
            {/* Toolbar */}
            <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-10 shrink-0">
                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setShowSettings(!showSettings)}
                        className={`p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${showSettings ? 'text-indigo-500' : 'text-slate-400'}`}
                    >
                        <Settings className="w-4 h-4" />
                    </button>
                    
                    {/* Source Indicator */}
                    <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-xs border border-transparent hover:border-indigo-500 transition-all cursor-pointer" onClick={() => setShowSettings(true)}>
                        {sourceMode === 'linked' ? (
                            <>
                                <LinkIcon className="w-3.5 h-3.5 text-emerald-500" />
                                <span className="font-bold text-slate-700 dark:text-slate-200">Linked</span>
                            </>
                        ) : (
                            <>
                                <List className="w-3.5 h-3.5 text-slate-500" />
                                <span className="font-medium text-slate-600 dark:text-slate-300 truncate max-w-[100px]">
                                    {availableWatchlists.find(w => w.id === selectedListId)?.name.split('/').pop()}
                                </span>
                            </>
                        )}
                        <span className="text-slate-400 text-[10px] ml-1 border-l border-slate-300 dark:border-slate-600 pl-2">
                            {startIndex + 1}-{Math.min(startIndex + pageSize, totalCount)} / {totalCount}
                        </span>
                    </div>
                </div>

                <div className="flex items-center gap-1">
                    <button onClick={handlePrev} disabled={startIndex === 0} className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 disabled:opacity-30">
                        <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button onClick={handleNext} disabled={startIndex + pageSize >= totalCount} className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 disabled:opacity-30">
                        <ChevronRight className="w-4 h-4" />
                    </button>
                </div>
            </div>

            {/* Quick Settings Panel */}
            {showSettings && (
                <div className="px-3 py-2 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-col gap-2 text-xs animate-in slide-in-from-top-2">
                    {/* Source Toggle */}
                    <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-bold uppercase text-[10px]">Data Source</span>
                        <div className="flex bg-slate-200 dark:bg-slate-800 rounded p-0.5">
                            <button 
                                onClick={() => handleConfigChange('sourceMode', 'static')}
                                className={`px-2 py-1 rounded text-[10px] font-bold transition-all ${sourceMode === 'static' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow' : 'text-slate-500'}`}
                            >
                                Static List
                            </button>
                            <button 
                                onClick={() => handleConfigChange('sourceMode', 'linked')}
                                className={`px-2 py-1 rounded text-[10px] font-bold transition-all ${sourceMode === 'linked' ? 'bg-white dark:bg-slate-700 text-emerald-500 shadow' : 'text-slate-500'}`}
                            >
                                Linked (Auto)
                            </button>
                        </div>
                    </div>

                    {sourceMode === 'static' && (
                        <div className="flex items-center gap-2">
                            <span className="text-slate-500 w-12">List:</span>
                            <select 
                                value={selectedListId}
                                onChange={(e) => handleConfigChange('watchlistId', e.target.value)}
                                className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 outline-none"
                            >
                                {availableWatchlists.map(w => (
                                    <option key={w.id} value={w.id}>
                                        {w.name}
                                    </option>
                                ))}
                            </select>
                        </div>
                    )}

                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                            <span className="text-slate-500">Rows:</span>
                            <input 
                                type="number" min="1" max="5" 
                                value={rows} 
                                onChange={e => handleConfigChange('rows', parseInt(e.target.value))}
                                className="w-10 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-0.5 text-center outline-none"
                            />
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-slate-500">Cols:</span>
                            <input 
                                type="number" min="1" max="6" 
                                value={cols} 
                                onChange={e => handleConfigChange('cols', parseInt(e.target.value))}
                                className="w-10 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-0.5 text-center outline-none"
                            />
                        </div>
                        
                        {/* Presets */}
                        <div className="flex gap-1 ml-auto border-l border-slate-200 dark:border-slate-700 pl-2">
                            <button onClick={() => { handleConfigChange('rows', 2); handleConfigChange('cols', 2); }} className="p-1 text-slate-400 hover:text-indigo-500" title="2x2"><LayoutGrid className="w-3.5 h-3.5" /></button>
                            <button onClick={() => { handleConfigChange('rows', 3); handleConfigChange('cols', 3); }} className="p-1 text-slate-400 hover:text-indigo-500" title="3x3"><Grid3x3 className="w-3.5 h-3.5" /></button>
                            <button onClick={() => { handleConfigChange('rows', 4); handleConfigChange('cols', 4); }} className="p-1 text-slate-400 hover:text-indigo-500" title="4x4"><Maximize2 className="w-3.5 h-3.5" /></button>
                        </div>
                    </div>
                </div>
            )}

            {/* Grid Container */}
            <div className="flex-1 p-2 overflow-hidden relative">
                {visibleStocks.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-slate-400 text-xs flex-col gap-2">
                        <List className="w-8 h-8 opacity-20" />
                        <span>{sourceMode === 'linked' ? 'Waiting for broadcast selection...' : 'No stocks in selected watchlist.'}</span>
                    </div>
                ) : (
                    <div 
                        className="w-full h-full grid gap-2"
                        style={{
                            gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
                            gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
                        }}
                    >
                        {visibleStocks.map(stock => (
                            <div key={stock.symbol} className="min-h-0 min-w-0">
                                <SimpleChart 
                                    symbol={stock.symbol}
                                    name={stock.name}
                                    data={gridData[stock.symbol] || []}
                                    settings={settings}
                                    onClick={() => onSymbolSelect(stock.symbol)}
                                    isUp={stock.change >= 0}
                                />
                            </div>
                        ))}
                    </div>
                )}
                
                {/* Overlay Hint */}
                <div className="absolute bottom-4 right-4 bg-black/50 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    Use Wheel / Keys to Scroll
                </div>
            </div>
        </div>
    );
};
