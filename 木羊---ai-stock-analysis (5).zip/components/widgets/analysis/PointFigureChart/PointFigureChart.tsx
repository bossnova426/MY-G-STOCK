
import React, { useMemo } from 'react';
import { StockDataPoint } from '../../../../types';

interface PointFigureProps {
  data: StockDataPoint[];
  boxSize?: number;
  reversal?: number;
}

export const PointFigureChart: React.FC<PointFigureProps> = ({ data, boxSize, reversal = 3 }) => {
  // Simple P&F Logic
  const { columns, dynamicBoxSize } = useMemo(() => {
    if (!data || data.length === 0) return { columns: [], dynamicBoxSize: 1 };

    // Auto-calculate box size if not provided (approx 1% of avg price)
    const avgPrice = data.reduce((acc, d) => acc + d.close, 0) / data.length;
    const calcBoxSize = boxSize || Math.max(0.5, Math.floor(avgPrice * 0.01));

    const cols: { type: 'X' | 'O'; boxes: number[]; date: string }[] = [];
    let currentTrend: 'X' | 'O' | null = null;
    let currentPrice = data[0].close;
    let currentColumnData: number[] = [];

    // Align initial price to box grid
    currentPrice = Math.floor(currentPrice / calcBoxSize) * calcBoxSize;
    let lastBoxPrice = currentPrice;
    
    // Very simplified P&F Algo for Visualization
    for (let i = 1; i < data.length; i++) {
        const close = data[i].close;
        const diff = close - lastBoxPrice;
        const boxesChanged = Math.floor(Math.abs(diff) / calcBoxSize);

        if (boxesChanged === 0) continue;

        const direction = diff > 0 ? 'X' : 'O';

        if (currentTrend === null) {
            currentTrend = direction;
            currentColumnData = Array.from({length: boxesChanged}, (_, k) => 
               direction === 'X' ? lastBoxPrice + (k+1)*calcBoxSize : lastBoxPrice - (k+1)*calcBoxSize
            );
            lastBoxPrice = currentColumnData[currentColumnData.length - 1];
            cols.push({ type: direction, boxes: currentColumnData, date: data[i].date });
        } else if (currentTrend === direction) {
            // Continue trend
            const newBoxes = Array.from({length: boxesChanged}, (_, k) => 
               direction === 'X' ? lastBoxPrice + (k+1)*calcBoxSize : lastBoxPrice - (k+1)*calcBoxSize
            );
            currentColumnData.push(...newBoxes);
            // Update the existing column in place (React logic would imply new array but for calc we simplify)
            cols[cols.length-1].boxes = currentColumnData;
            lastBoxPrice = newBoxes[newBoxes.length - 1];
        } else {
            // Check reversal
            if (boxesChanged >= reversal) {
                currentTrend = direction;
                // Move one box over
                // New column starts from previous high/low adjusted
                // P&F rules are strict, simplified here for UI demo
                currentColumnData = Array.from({length: boxesChanged}, (_, k) => 
                   direction === 'X' ? lastBoxPrice + (k+1)*calcBoxSize : lastBoxPrice - (k+1)*calcBoxSize
                );
                lastBoxPrice = currentColumnData[currentColumnData.length - 1];
                cols.push({ type: direction, boxes: currentColumnData, date: data[i].date });
            }
        }
    }

    // Limit columns for view
    return { columns: cols.slice(-30), dynamicBoxSize: calcBoxSize };
  }, [data, boxSize, reversal]);

  // Determine grid scale
  const allPrices = columns.flatMap(c => c.boxes);
  const maxPrice = Math.max(...allPrices, 0) + dynamicBoxSize;
  const minPrice = Math.min(...allPrices, maxPrice);
  const range = maxPrice - minPrice;
  const totalBoxesHigh = Math.ceil(range / dynamicBoxSize);
  
  return (
    <div className="w-full h-full p-4 overflow-x-auto custom-scrollbar flex flex-col">
       <div className="flex justify-between text-xs text-slate-500 mb-2">
           <span>Box Size: {dynamicBoxSize.toFixed(2)}</span>
           <span>Reversal: {reversal}</span>
           <span>Method: Traditional</span>
       </div>
       <div className="flex-1 min-h-[250px] relative bg-slate-900/50 border border-slate-800 rounded grid" 
            style={{ 
                gridTemplateColumns: `repeat(${columns.length}, minmax(20px, 1fr))`,
                padding: '20px' 
            }}>
            {/* Grid Lines Overlay - Simulated via CSS background would be better, but explicit columns here */}
            {columns.map((col, idx) => (
                <div key={idx} className="flex flex-col justify-end relative h-full border-r border-slate-800/30">
                    <div className="absolute top-0 w-full text-center text-[9px] text-slate-600 -mt-4 opacity-50">{col.date}</div>
                    <div className="relative w-full h-full">
                        {col.boxes.map((price, bIdx) => {
                            // Calculate position from bottom percentage
                            const bottomPct = ((price - minPrice) / range) * 100;
                            return (
                                <div 
                                    key={bIdx}
                                    className={`absolute w-full flex items-center justify-center text-[10px] font-bold ${col.type === 'X' ? 'text-emerald-500' : 'text-rose-500'}`}
                                    style={{ 
                                        bottom: `${bottomPct}%`, 
                                        height: `${100/totalBoxesHigh}%`,
                                        maxHeight: '20px'
                                    }}
                                >
                                    {col.type}
                                </div>
                            );
                        })}
                    </div>
                </div>
            ))}
       </div>
    </div>
  );
};

export default PointFigureChart;
