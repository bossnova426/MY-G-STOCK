
import React from 'react';
import { AnalysisResult, AppSettings } from '../../../../types';
import { TrendingUp, TrendingDown, AlertTriangle, Target, Activity } from 'lucide-react';
import { I18N } from '../../../../constants';

interface AnalysisPanelProps {
  analysis: AnalysisResult | null;
  loading: boolean;
  onRefresh: () => void;
  settings?: AppSettings;
}

export const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ analysis, loading, onRefresh, settings }) => {
  const lang = settings?.language || 'en';
  const t = I18N[lang];

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center space-y-4 animate-pulse">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 text-sm">{t.loading}</p>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-6">
        <Activity className="w-12 h-12 text-slate-600 mb-4" />
        <p className="text-slate-400 mb-4">{t.noData}</p>
        <button 
          onClick={onRefresh}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors text-sm font-medium"
        >
          {t.regenerate}
        </button>
      </div>
    );
  }

  const isBuy = analysis.technicalSignal === 'BUY';
  const isSell = analysis.technicalSignal === 'SELL';
  const signalColor = isBuy ? 'text-emerald-400' : isSell ? 'text-rose-400' : 'text-yellow-400';
  const SignalIcon = isBuy ? TrendingUp : isSell ? TrendingDown : Activity;

  return (
    <div className="h-full flex flex-col overflow-y-auto pr-2 custom-scrollbar">
      
      {/* Header Signal */}
      <div className="flex items-center justify-between mb-6 p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
        <div>
          <h3 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">{t.technicalSignal}</h3>
          <div className={`flex items-center gap-2 text-2xl font-bold ${signalColor}`}>
            <SignalIcon className="w-6 h-6" />
            <span>{analysis.technicalSignal}</span>
          </div>
        </div>
        <div className="text-right">
          <h3 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">{t.confidence}</h3>
          <div className="text-xl font-bold text-white">{analysis.confidenceScore}%</div>
        </div>
      </div>

      {/* Summary */}
      <div className="mb-6">
        <h3 className="text-slate-200 font-semibold mb-2 flex items-center gap-2">
          <Activity className="w-4 h-4 text-indigo-400" /> {t.summary}
        </h3>
        <p className="text-slate-300 text-sm leading-relaxed bg-slate-800/30 p-3 rounded-lg border border-slate-700/30">
          {analysis.summary}
        </p>
      </div>

      {/* Key Levels */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800/30 p-3 rounded-lg border border-slate-700/30">
          <h4 className="text-emerald-400 text-xs font-bold uppercase mb-2 flex items-center gap-1">
            <Target className="w-3 h-3" /> {t.support}
          </h4>
          <div className="flex flex-wrap gap-2">
            {analysis.keyLevels.support.map((val, i) => (
              <span key={i} className="px-2 py-1 bg-emerald-500/10 text-emerald-300 text-xs rounded font-mono">
                ${val}
              </span>
            ))}
          </div>
        </div>
        <div className="bg-slate-800/30 p-3 rounded-lg border border-slate-700/30">
          <h4 className="text-rose-400 text-xs font-bold uppercase mb-2 flex items-center gap-1">
            <Target className="w-3 h-3" /> {t.resistance}
          </h4>
          <div className="flex flex-wrap gap-2">
            {analysis.keyLevels.resistance.map((val, i) => (
              <span key={i} className="px-2 py-1 bg-rose-500/10 text-rose-300 text-xs rounded font-mono">
                ${val}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Risks */}
      <div>
        <h3 className="text-slate-200 font-semibold mb-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" /> {t.risks}
        </h3>
        <ul className="space-y-2">
          {analysis.risks.map((risk, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-slate-400">
              <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-amber-500 flex-shrink-0"></span>
              {risk}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-8 pt-4 border-t border-slate-800">
          <button 
            onClick={onRefresh}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all text-sm font-semibold shadow-lg shadow-indigo-900/20"
          >
            {t.regenerate}
          </button>
      </div>

    </div>
  );
};

export default AnalysisPanel;
