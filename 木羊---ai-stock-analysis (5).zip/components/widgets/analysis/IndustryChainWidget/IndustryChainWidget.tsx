
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { WidgetContext, StockDataPoint, WatchlistItem } from '../../../../types';
import { Filter, Layers, ArrowDownWideNarrow, FlaskConical, PlayCircle, X, ChevronDown, Check, Save, ArrowDown, ArrowUp, BarChart2, Activity, Folder, Hash } from 'lucide-react';
import { TreeBrowser, TreeNode } from '../../../common/TreeBrowser';
import { INDICATOR_REGISTRY, getIndicatorById } from '../../../../services/indicatorService';

// --- Data Models ---
type NodeType = 'CATEGORY' | 'STOCK';

interface Node {
    id: string;
    name: string;
    change: number;
    volumeRatio: number;
    price: number;
    rps: number;      // Relative Price Strength
    score: number;    // Multi-factor Score
    children?: Node[];
    type: NodeType;
    depth: number;
    [key: string]: any; // Allow dynamic access
}

type StandardType = 'CONCEPT' | 'TDX' | 'SWS' | 'CSI';

// Helper to get value for any metric ID (Mocking missing data)
const getNodeValue = (node: Node, metricId: string): number => {
    // 1. Direct property match
    if (typeof node[metricId] === 'number') return node[metricId];
    
    // 2. Mapped aliases
    if (metricId === 'changePercent') return node.change;
    if (metricId === 'vol') return node.volumeRatio;
    
    // 3. Deterministic Mock for other indicators (e.g. RSI, MACD)
    // This ensures sorting/filtering works consistently even for fake data
    let hash = 0;
    const seed = node.id + metricId;
    for (let i = 0; i < seed.length; i++) {
        hash = seed.charCodeAt(i) + ((hash << 5) - hash);
    }
    // Normalize to plausible range 0-100
    return Math.abs(hash % 100);
};

// --- Components ---

// Metric Selector Component using TreeBrowser
const MetricSelector: React.FC<{
    value: string;
    onChange: (val: string) => void;
    treeData: TreeNode[];
    className?: string;
}> = ({ value, onChange, treeData, className }) => {
    const [isOpen, setIsOpen] = useState(false);
    const buttonRef = useRef<HTMLButtonElement>(null);
    const [menuPos, setMenuPos] = useState<React.CSSProperties>({});

    const handleToggle = () => {
        if (!isOpen && buttonRef.current) {
            const rect = buttonRef.current.getBoundingClientRect();
            setMenuPos({
                position: 'fixed',
                top: rect.bottom + 4,
                left: rect.left,
                width: 220,
                zIndex: 9999,
                maxHeight: 300
            });
        }
        setIsOpen(!isOpen);
    };

    const selectedDef = getIndicatorById(value);
    const label = selectedDef ? selectedDef.shortName : value;

    return (
        <>
            <button 
                ref={buttonRef}
                onClick={handleToggle}
                className={`flex items-center justify-between gap-1 px-2 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-[10px] font-bold uppercase hover:border-indigo-500 transition-all ${className}`}
            >
                <span className="truncate">{label}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            {isOpen && createPortal(
                <div 
                    className="fixed bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95"
                    style={menuPos}
                    onClick={() => setIsOpen(false)} // Close on background click
                >
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-1 h-64">
                        <TreeBrowser 
                            data={treeData}
                            onSelect={(node) => {
                                if (node.type === 'item') {
                                    onChange(node.id);
                                    setIsOpen(false);
                                }
                            }}
                            selectedId={value}
                            enableSearch={true}
                            emptyMessage="No metric found"
                        />
                    </div>
                </div>,
                document.body
            )}
            {isOpen && <div className="fixed inset-0 z-[9998]" onClick={() => setIsOpen(false)} />}
        </>
    );
};

const FilterHeader: React.FC<{
    title: string;
    count: number;
    filterVal: number;
    setFilterVal: (v: number) => void;
    color: string;
    metric: string;
    setMetric: (m: string) => void;
    treeData: TreeNode[];
}> = ({ title, count, filterVal, setFilterVal, color, metric, setMetric, treeData }) => (
    <div className="flex flex-col gap-2 p-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 shrink-0 sticky top-0 z-10 h-[66px]">
        <div className="flex justify-between items-center">
            <span className={`text-[10px] font-bold uppercase ${color} truncate max-w-[120px]`} title={title}>{title}</span>
            <span className="text-[9px] bg-slate-200 dark:bg-slate-800 px-1.5 rounded-full text-slate-500">
                {count}
            </span>
        </div>
        <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-1.5 py-0.5">
            <Filter className="w-2.5 h-2.5 text-slate-400 shrink-0" />
            <div className="flex-1 min-w-[50px]">
                <MetricSelector 
                    value={metric} 
                    onChange={setMetric} 
                    treeData={treeData} 
                    className="border-none bg-transparent px-0 py-0 h-full w-full shadow-none text-indigo-600 dark:text-indigo-400" 
                />
            </div>
            <span className="text-[9px] text-slate-400 font-bold">&gt;</span>
            <input 
                type="number" 
                value={filterVal}
                onChange={(e) => setFilterVal(Number(e.target.value))}
                className="w-12 bg-transparent text-[10px] font-bold outline-none text-slate-700 dark:text-slate-200 text-right"
                step="1"
            />
        </div>
    </div>
);

const NodeCard: React.FC<{
    node: Node;
    isSelected: boolean;
    isDimmed: boolean;
    onClick: () => void;
    metric: string; // This is the Visual/Sort metric, not necessarily the filter metric
}> = ({ node, isSelected, isDimmed, onClick, metric }) => {
    const isUp = node.change >= 0;
    
    // Background intensity based on the primary metric if possible, defaulting to change for color direction
    // For specialized metrics like RPS, higher is better (usually), but change gives standard red/green
    const intensity = Math.min(0.8, 0.1 + Math.abs(node.change) / 10); 
    const bgColor = isUp ? `rgba(239, 68, 68, ${intensity})` : `rgba(34, 197, 94, ${intensity})`;
    
    // Dynamic Value Display
    const val = getNodeValue(node, metric);
    const def = getIndicatorById(metric);
    
    let displayValue = '';
    let displayLabel = '';
    
    if (typeof val === 'number') {
        if (metric === 'change' || metric === 'changePercent') {
            displayValue = `${val > 0 ? '+' : ''}${val.toFixed(2)}%`;
        } else if (def?.unit) {
            displayValue = `${val.toFixed(2)}${def.unit}`;
            displayLabel = def.shortName;
        } else {
            displayValue = val.toFixed(2);
            displayLabel = def ? def.shortName : metric;
        }
    } else {
        displayValue = String(val);
    }

    return (
        <div 
            onClick={onClick}
            className={`
                relative rounded border cursor-pointer transition-all flex flex-col justify-center p-2 mb-1 shrink-0
                ${isSelected ? 'ring-2 ring-indigo-500 z-10 scale-[1.02]' : 'border-transparent hover:border-slate-300 dark:hover:border-slate-600'}
                ${isDimmed ? 'opacity-40 grayscale' : 'opacity-100'}
            `}
            style={{ backgroundColor: !isSelected ? bgColor : undefined }}
        >
            {isSelected && <div className="absolute inset-0 bg-indigo-500/10 rounded pointer-events-none" />}

            <div className="flex justify-between items-center gap-2">
                <span className={`text-[11px] font-bold leading-tight truncate ${isSelected ? 'text-indigo-700 dark:text-indigo-300' : 'text-slate-900 dark:text-white'}`}>
                    {node.name}
                </span>
                <span className={`text-[10px] font-mono font-bold ${metric === 'change' ? (node.change >= 0 ? 'text-rose-600 dark:text-rose-300' : 'text-emerald-700 dark:text-emerald-300') : 'text-slate-800 dark:text-slate-100'}`}>
                    {displayLabel && <span className="text-[9px] opacity-70 mr-1">{displayLabel}</span>}
                    {displayValue}
                </span>
            </div>
            
            {/* Secondary info line (Always show Change if not primary) */}
            <div className="flex justify-between items-center mt-1 opacity-80">
                 {metric !== 'change' && (
                     <span className={`text-[9px] ${node.change >= 0 ? 'text-rose-700 dark:text-rose-200' : 'text-emerald-700 dark:text-emerald-200'}`}>
                         {node.change > 0 ? '+' : ''}{node.change.toFixed(2)}%
                     </span>
                 )}
                 {metric !== 'volumeRatio' && node.type === 'STOCK' && (
                     <span className="text-[9px] text-slate-700 dark:text-slate-300">V:{node.volumeRatio.toFixed(1)}</span>
                 )}
            </div>
        </div>
    );
};

export const IndustryChainWidget: React.FC<WidgetContext> = ({ 
    onSymbolSelect, settings, savedScreens, onAddWatchlist, onSaveWatchlist, onBroadcastList, 
    availableWatchlists 
}) => {
    const [standard, setStandard] = useState<StandardType>('TDX');
    const [rawData, setRawData] = useState<Node[]>([]);
    
    // --- Metric & Sorting (Global Visualization) ---
    const [activeMetric, setActiveMetric] = useState<string>('change');
    
    // --- Selection Path State ---
    const [selectionPath, setSelectionPath] = useState<(string | null)[]>([]);
    const [selectedStock, setSelectedStock] = useState<Node | null>(null);

    // --- Filter State (Per Level) ---
    // Maps Depth -> Threshold Value
    const [filters, setFilters] = useState<Record<number, number>>({ 0: -999, 1: -999, 2: -999, 3: -999, 4: -999 });
    // Maps Depth -> Metric Type (New Feature)
    const [filterMetrics, setFilterMetrics] = useState<Record<number, string>>({ 0: 'change', 1: 'change', 2: 'change', 3: 'change', 4: 'change' });

    const scrollContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const mapToNodes = (): Node[] => {
            const groups: Record<string, Node> = {};
            
            if (!availableWatchlists) return [];

            // Map selected standard to folder names in availableWatchlists
            const targetFolderMap: Record<string, string> = {
                'TDX': 'TDX', 
                'SWS': 'SWS', 
                'CONCEPT': 'Concepts',
                'CSI': 'Markets' // Use Markets or another identifier if relevant
            };
            const targetFolder = targetFolderMap[standard];

            availableWatchlists.forEach(list => {
                if (!list.readOnly) return; 
                
                const parts = list.name.split('/');
                if (parts.length < 3) return; 
                
                const matchesStandard = parts.includes(targetFolder);
                if (!matchesStandard) return;

                const name = parts[parts.length - 1]; 
                
                if (!groups[name]) {
                    const children = list.stocks.map((s, idx) => ({
                        id: s.symbol, 
                        name: s.name || s.symbol, 
                        change: s.changePercent || 0,
                        volumeRatio: 1.0, // Mock if missing
                        price: s.price || 0, 
                        rps: 50, 
                        score: 50, 
                        type: 'STOCK' as NodeType, 
                        depth: 1
                    }));

                    // Aggregate change for category
                    let avgChange = 0;
                    if (children.length > 0) {
                        avgChange = children.reduce((sum, s) => sum + s.change, 0) / children.length;
                    }

                    groups[name] = {
                        id: list.id, 
                        name: name, 
                        change: avgChange, 
                        volumeRatio: 1.0, 
                        price: 0, 
                        rps: 50, 
                        score: 50, 
                        type: 'CATEGORY', 
                        depth: 0,
                        children
                    };
                }
            });
            return Object.values(groups);
        };

        setRawData(mapToNodes());
        setSelectionPath([null, null, null, null, null]); 
        setSelectedStock(null);
        // Reset filters conservatively
        setFilters({ 0: -999, 1: -999, 2: -999, 3: -999, 4: -999 });
        setFilterMetrics({ 0: activeMetric, 1: activeMetric, 2: activeMetric, 3: activeMetric, 4: activeMetric });
    }, [standard, availableWatchlists]);

    // Reset filters when GLOBAL metric changes to avoid confusing states (optional, but good UX for "Reset")
    useEffect(() => {
        let defaultVal = -999;
        if (activeMetric === 'rps') defaultVal = 80;
        else if (activeMetric === 'volumeRatio') defaultVal = 1;
        else if (activeMetric === 'score') defaultVal = 60;
        else defaultVal = -20;

        setFilters({ 0: defaultVal, 1: defaultVal, 2: defaultVal, 3: defaultVal, 4: defaultVal });
        // Also sync the filter metrics to the new global metric initially
        setFilterMetrics({ 0: activeMetric, 1: activeMetric, 2: activeMetric, 3: activeMetric, 4: activeMetric });
    }, [activeMetric]);

    // --- Prepare Tree Data for Selectors ---
    const metricTreeData = useMemo(() => {
        const root: TreeNode[] = [];
        const getFolder = (path: string[], parentArray: TreeNode[]): TreeNode[] => {
            if (path.length === 0) return parentArray;
            const currentName = path[0];
            let folder = parentArray.find(n => n.label === currentName && n.type === 'folder');
            if (!folder) {
                folder = { id: `cat-${currentName}`, label: currentName, type: 'folder', children: [], icon: Folder };
                parentArray.push(folder);
            }
            return getFolder(path.slice(1), folder.children!);
        };

        INDICATOR_REGISTRY.forEach(ind => {
            const parts = ind.category.split('/');
            const targetArray = getFolder(parts, root);
            targetArray.push({
                id: ind.id,
                label: ind.name,
                type: 'item',
                icon: Hash,
                color: 'text-indigo-500'
            });
        });
        
        // Add defaults if missing
        ['change', 'price', 'volumeRatio'].forEach(basic => {
             // Basic folder
             const basicFolder = getFolder(['Market', 'Basic'], root);
             if (!basicFolder.find(n => n.id === basic)) {
                 basicFolder.push({ id: basic, label: basic === 'volumeRatio' ? 'Volume Ratio' : basic.charAt(0).toUpperCase() + basic.slice(1), type: 'item', icon: Hash, color: 'text-emerald-500' });
             }
        });

        return root;
    }, []);

    // --- Core Logic: Recursively Filter & Sort Tree ---
    const processedHierarchy = useMemo(() => {
        const pruneAndSort = (nodes: Node[], depth: number): Node[] => {
            const threshold = filters[depth] !== undefined ? filters[depth] : -9999;
            const filterMetric = filterMetrics[depth] || activeMetric; // Use per-level metric or fallback
            
            // 1. Filter current level nodes based on LEVEL METRIC
            const validNodes = nodes.filter(n => {
                const val = getNodeValue(n, filterMetric);
                return val >= threshold;
            });

            // 2. Map & Recurse (Prune children)
            const prunedNodes = validNodes.map(node => {
                if (node.children) {
                    const validChildren = pruneAndSort(node.children, depth + 1);
                    // Strict Funnel: A parent exists only if it has valid children.
                    if (validChildren.length > 0) {
                        return { ...node, children: validChildren };
                    }
                    return null;
                }
                return node; // Stock (Leaf)
            }).filter((n): n is Node => n !== null);

            // 3. Sort current level based on GLOBAL VISUAL METRIC
            return prunedNodes.sort((a, b) => {
                const valA = getNodeValue(a, activeMetric);
                const valB = getNodeValue(b, activeMetric);
                return valB - valA;
            });
        };

        return pruneAndSort(rawData, 0);
    }, [rawData, activeMetric, filters, filterMetrics]);

    // --- Funnel Logic: Cascading Columns ---
    const columns = useMemo(() => {
        // Depth logic is simpler now since we assume flat 2-level (Category -> Stocks) for the imported lists
        // But code supports deeper if needed.
        let categoryDepth = 0; 
        
        const totalCols = categoryDepth + 2; 
        const generatedCols: { depth: number; title: string; nodes: Node[] }[] = [];
        
        // Col 0
        let currentLevelNodes = processedHierarchy;
        let colTitle = 'Category';
        if (standard === 'CONCEPT') colTitle = 'Concept';
        else if (standard === 'TDX') colTitle = 'Industry';
        else if (standard === 'SWS') colTitle = 'Sector';

        generatedCols.push({ depth: 0, title: colTitle, nodes: currentLevelNodes });
        
        // Subsequent Cols
        for (let d = 1; d < totalCols; d++) {
            const selectedParentId = selectionPath[d-1];
            let potentialParents: Node[] = [];
            
            if (selectedParentId) {
                const p = currentLevelNodes.find(n => n.id === selectedParentId);
                potentialParents = p ? [p] : [];
            } else {
                potentialParents = currentLevelNodes; // Funnel Mode
            }
            
            let nextLevelNodes = potentialParents.flatMap(p => p.children || []);
            
            let title = `Level ${d + 1}`;
            if (d === totalCols - 1) title = 'Constituents';

            generatedCols.push({ depth: d, title, nodes: nextLevelNodes });
            currentLevelNodes = nextLevelNodes;
        }
        
        return generatedCols;
    }, [processedHierarchy, selectionPath, standard]);

    // --- Linked List Broadcasting ---
    useEffect(() => {
        if (onBroadcastList) {
            // Find the last column (Constituents)
            const lastCol = columns[columns.length - 1];
            if (lastCol && lastCol.nodes.length > 0 && lastCol.nodes[0].type === 'STOCK') {
                const stockList: WatchlistItem[] = lastCol.nodes.map(n => ({
                    symbol: n.name.split(' ')[0], // Simulating extracting symbol
                    name: n.name,
                    price: n.price,
                    change: n.change,
                    changePercent: n.change,
                    vol: n.volumeRatio.toFixed(1),
                    sector: 'Industry Result'
                }));
                // Debounce
                const timer = setTimeout(() => {
                    onBroadcastList(stockList);
                }, 300);
                return () => clearTimeout(timer);
            }
        }
    }, [columns, onBroadcastList]);

    const handleNodeClick = (node: Node, depth: number) => {
        if (node.type === 'STOCK') {
            setSelectedStock(node);
            onSymbolSelect(node.id); // Use ID as symbol
        } else {
            const newPath = [...selectionPath];
            if (newPath[depth] === node.id) {
                newPath[depth] = null;
            } else {
                newPath[depth] = node.id;
            }
            for (let i = depth + 1; i < newPath.length; i++) {
                newPath[i] = null;
            }
            setSelectionPath(newPath);
            setSelectedStock(null);
        }
    };

    const handleFilterChange = (depth: number, val: number) => {
        setFilters(prev => ({ ...prev, [depth]: val }));
    };

    const handleFilterMetricChange = (depth: number, m: string) => {
        setFilterMetrics(prev => ({ ...prev, [depth]: m }));
    };

    const handleSaveResults = () => {
        const stocks: WatchlistItem[] = [];
        const traverse = (nodes: Node[]) => {
            nodes.forEach(n => {
                if (n.type === 'STOCK') {
                    stocks.push({
                        symbol: n.id,
                        name: n.name,
                        price: n.price,
                        change: n.change,
                        changePercent: n.change,
                        vol: n.volumeRatio.toFixed(1),
                        sector: 'Funnel Result'
                    });
                } else if (n.children) {
                    traverse(n.children);
                }
            });
        };
        traverse(processedHierarchy);

        if (stocks.length === 0) {
            alert("No stocks match the current filters.");
            return;
        }

        const name = prompt(`Save ${stocks.length} stocks to Watchlist?`, `Funnel Result ${new Date().toLocaleTimeString()}`);
        if (name && onSaveWatchlist) {
            onSaveWatchlist({
                id: `wl-${Date.now()}`,
                name: `Saved/${name}`,
                stocks
            });
        }
    };

    const COL_WIDTH = "min-w-[170px] w-[220px] flex-shrink-0";

    return (
        <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-200 font-sans select-none overflow-hidden">
            
            {/* Toolbar */}
            <div className="h-10 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 flex items-center px-3 justify-between shrink-0 z-20 relative">
                <div className="flex items-center gap-3">
                    {/* Standard Selector */}
                    <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded p-0.5">
                        <Layers className="w-3.5 h-3.5 ml-1 text-indigo-500" />
                        <select 
                            value={standard} 
                            onChange={e => setStandard(e.target.value as StandardType)}
                            className="bg-transparent text-[10px] font-bold uppercase outline-none cursor-pointer px-1 py-0.5"
                        >
                            <option value="CONCEPT">Concept</option>
                            <option value="TDX">TDX</option>
                            <option value="SWS">SWS</option>
                            <option value="CSI">CSI</option>
                        </select>
                    </div>

                    {/* Metric Selector (Global Sort) */}
                    <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded p-0.5 border border-slate-200 dark:border-slate-700">
                        <Activity className="w-3.5 h-3.5 ml-1 text-amber-500" />
                        <span className="text-[10px] text-slate-400 font-bold px-1">Heatmap:</span>
                        <div className="min-w-[80px]">
                            <MetricSelector 
                                value={activeMetric} 
                                onChange={setActiveMetric} 
                                treeData={metricTreeData} 
                                className="border-none bg-transparent px-1 py-0.5 h-full w-full shadow-none text-indigo-600 dark:text-indigo-400"
                            />
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <button 
                        onClick={handleSaveResults}
                        className="flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-[10px] font-bold shadow-sm transition-colors"
                        title="Save filtered results to Watchlist"
                    >
                        <Save className="w-3 h-3" />
                        Save Result
                    </button>
                </div>
            </div>

            {/* Scrolling Columns Container */}
            <div className="flex-1 flex overflow-x-auto custom-scrollbar bg-slate-100 dark:bg-slate-950/50" ref={scrollContainerRef}>
                
                {columns.map((col, idx) => (
                    <div key={`col-${col.depth}`} className={`${COL_WIDTH} flex flex-col border-r border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50`}>
                        <FilterHeader 
                            title={col.title}
                            color={['text-indigo-500', 'text-pink-500', 'text-amber-500', 'text-cyan-500', 'text-emerald-500'][col.depth % 5]}
                            count={col.nodes.length} 
                            filterVal={filters[col.depth] || -999} 
                            setFilterVal={(v) => handleFilterChange(col.depth, v)} 
                            metric={filterMetrics[col.depth] || activeMetric}
                            setMetric={(m) => handleFilterMetricChange(col.depth, m)}
                            treeData={metricTreeData}
                        />
                        <div className="flex-1 overflow-y-auto p-1 custom-scrollbar">
                            {col.nodes.length === 0 ? (
                                <div className="p-4 text-center text-[10px] text-slate-400 opacity-50 flex flex-col items-center gap-2">
                                    <ArrowDownWideNarrow className="w-6 h-6" />
                                    <span>No items match {getIndicatorById(filterMetrics[col.depth] || activeMetric)?.shortName} &gt; {filters[col.depth]}</span>
                                </div>
                            ) : (
                                col.nodes.map(node => {
                                    // Is this node selected?
                                    const isSelected = node.type === 'CATEGORY' 
                                        ? selectionPath[idx] === node.id
                                        : selectedStock?.id === node.id;
                                    
                                    const hasSelectionInCol = node.type === 'CATEGORY' 
                                        ? !!selectionPath[idx] 
                                        : !!selectedStock;
                                        
                                    const isDimmed = hasSelectionInCol && !isSelected;

                                    return (
                                        <NodeCard 
                                            key={node.id} 
                                            node={node} 
                                            onClick={() => handleNodeClick(node, col.depth)}
                                            isSelected={isSelected}
                                            isDimmed={isDimmed}
                                            metric={activeMetric} // Visual metric
                                        />
                                    );
                                })
                            )}
                        </div>
                    </div>
                ))}

            </div>
        </div>
    );
};
