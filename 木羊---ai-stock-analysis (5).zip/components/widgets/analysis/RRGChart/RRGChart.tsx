
import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Label } from 'recharts';

interface RRGItem {
  symbol: string;
  ratio: number; // JdK RS-Ratio (X-Axis) - Relative Strength vs Benchmark
  momentum: number; // JdK RS-Momentum (Y-Axis) - ROC of Relative Strength
  sector: string;
}

interface RRGChartProps {
  data: any[]; // Raw stock data to mock RRG from
}

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-800 border border-slate-700 p-2 rounded shadow-xl text-xs">
        <p className="font-bold text-slate-200">{data.symbol}</p>
        <p className="text-slate-400">Ratio: {data.ratio.toFixed(2)}</p>
        <p className="text-slate-400">Mom: {data.momentum.toFixed(2)}</p>
      </div>
    );
  }
  return null;
};

// Custom shape for the scatter point (with trail effect simulated by size/opacity logic in a real app)
const RenderNode = (props: any) => {
    const { cx, cy, payload } = props;
    let color = '#94a3b8'; // default
    
    // Color based on quadrant
    if (payload.ratio > 100 && payload.momentum > 100) color = '#10b981'; // Leading (Green)
    else if (payload.ratio > 100 && payload.momentum < 100) color = '#f59e0b'; // Weakening (Yellow)
    else if (payload.ratio < 100 && payload.momentum < 100) color = '#f43f5e'; // Lagging (Red)
    else color = '#3b82f6'; // Improving (Blue)

    return (
        <g>
            <circle cx={cx} cy={cy} r={6} fill={color} stroke="#0f172a" strokeWidth={1} fillOpacity={0.9} />
            <text x={cx} y={cy - 10} textAnchor="middle" fill="#fff" fontSize={10} fontWeight="bold">{payload.symbol}</text>
        </g>
    );
};

export const RRGChart: React.FC<RRGChartProps> = ({ data }) => {
  // Mock RRG Data Generation based on input list or randoms
  const rrgData: RRGItem[] = [
    { symbol: 'NVDA', ratio: 104.5, momentum: 102.3, sector: 'Tech' },
    { symbol: 'AMD', ratio: 101.2, momentum: 98.5, sector: 'Tech' },
    { symbol: 'AAPL', ratio: 98.5, momentum: 101.8, sector: 'Tech' },
    { symbol: 'MSFT', ratio: 102.1, momentum: 100.5, sector: 'Tech' },
    { symbol: 'GOOG', ratio: 97.2, momentum: 99.1, sector: 'Tech' },
    { symbol: 'TSLA', ratio: 95.5, momentum: 96.2, sector: 'Auto' },
    { symbol: 'META', ratio: 103.8, momentum: 104.1, sector: 'Tech' },
    { symbol: 'XLE', ratio: 105.2, momentum: 97.5, sector: 'Energy' }, // Weakening
    { symbol: 'XLF', ratio: 99.1, momentum: 103.5, sector: 'Finance' }, // Improving
  ];

  return (
    <div className="w-full h-full flex flex-col overflow-hidden">
       <div className="flex justify-between items-center px-4 pt-2 shrink-0">
           <div className="text-[10px] text-slate-500">Benchmark: SPX 500</div>
           <div className="flex gap-2 text-[10px]">
               <span className="text-emerald-400">● Leading</span>
               <span className="text-amber-400">● Weakening</span>
               <span className="text-rose-400">● Lagging</span>
               <span className="text-blue-400">● Improving</span>
           </div>
       </div>
       <div className="flex-1 min-h-0">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis 
                type="number" 
                dataKey="ratio" 
                name="RS-Ratio" 
                domain={[94, 106]} 
                tick={{fontSize: 10, fill: '#64748b'}}
                stroke="#334155"
            />
            <YAxis 
                type="number" 
                dataKey="momentum" 
                name="RS-Momentum" 
                domain={[94, 106]} 
                tick={{fontSize: 10, fill: '#64748b'}} 
                stroke="#334155"
            />
            <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
            
            {/* Quadrant Lines */}
            <ReferenceLine x={100} stroke="#475569" strokeWidth={1} />
            <ReferenceLine y={100} stroke="#475569" strokeWidth={1} />

            {/* Labels for Quadrants */}
            <ReferenceLine y={105} x={105} stroke="none" label={<Label value="LEADING" fill="#10b981" fontSize={24} opacity={0.1} />} />
            <ReferenceLine y={95} x={105} stroke="none" label={<Label value="WEAKENING" fill="#f59e0b" fontSize={24} opacity={0.1} />} />
            <ReferenceLine y={95} x={95} stroke="none" label={<Label value="LAGGING" fill="#f43f5e" fontSize={24} opacity={0.1} />} />
            <ReferenceLine y={105} x={95} stroke="none" label={<Label value="IMPROVING" fill="#3b82f6" fontSize={24} opacity={0.1} />} />

            <Scatter name="Stocks" data={rrgData} shape={<RenderNode />} />
          </ScatterChart>
        </ResponsiveContainer>
       </div>
    </div>
  );
};

export default RRGChart;
