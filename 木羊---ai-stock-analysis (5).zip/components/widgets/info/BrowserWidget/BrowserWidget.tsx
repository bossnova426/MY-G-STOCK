
import React, { useState, useEffect, useRef } from 'react';
import { WidgetContext } from '../../../../types';
import { RefreshCw, Play, Pause, Globe, AlertCircle, Link, ExternalLink, Settings, X, Save, Info, Tag } from 'lucide-react';

const detectMarket = (symbol: string): string => {
    // Basic heuristic for China markets
    if (symbol.startsWith('6')) return 'sh';
    if (symbol.startsWith('0') || symbol.startsWith('3')) return 'sz';
    if (symbol.startsWith('8') || symbol.startsWith('4')) return 'bj';
    // Fallback for US/HK or others
    if (/^[A-Z]+$/.test(symbol)) return 'us'; 
    return 'sh';
};

const extractNameFromUrl = (url: string): string => {
    try {
        if (!url) return '';
        // Handle simplified inputs like "google.com"
        const safeUrl = url.startsWith('http') ? url : `https://${url}`;
        const hostname = new URL(safeUrl).hostname;
        // Remove www. and get first part
        const clean = hostname.replace(/^www\./, '');
        const parts = clean.split('.');
        if (parts.length > 0) {
             // Capitalize first letter
             return parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
        }
        return '';
    } catch (e) {
        return '';
    }
};

export const BrowserWidget: React.FC<WidgetContext> = ({ 
    symbol, 
    profile, 
    widgetConfig, 
    onUpdateConfig 
}) => {
    // --- Config State ---
    const [urlTemplate, setUrlTemplate] = useState(widgetConfig?.urlTemplate || 'https://www.bing.com/search?q=xxxxxx+stock');
    const [refreshInterval, setRefreshInterval] = useState<number>(widgetConfig?.refreshInterval || 0); // Minutes
    const [isAutoRefresh, setIsAutoRefresh] = useState(false);
    const [isSyncEnabled, setIsSyncEnabled] = useState(widgetConfig?.isSyncEnabled ?? true);
    const [tabName, setTabName] = useState(widgetConfig?.customTabName || '');
    
    // --- UI State ---
    const [showSettings, setShowSettings] = useState(false);

    // --- Internal State ---
    const [currentUrl, setCurrentUrl] = useState('');
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const timerRef = useRef<number | null>(null);

    // --- Logic: Parse URL Template ---
    const parseUrl = (template: string, sym: string, name: string) => {
        let url = template;
        const market = detectMarket(sym);
        
        // Replace placeholders from the legacy software spec
        url = url.replace(/xxxxxx/g, sym);
        url = url.replace(/!!/g, market);
        url = url.replace(/##STOCKNAME##/g, encodeURIComponent(name));
        
        return url;
    };

    // Sync Logic
    useEffect(() => {
        if (isSyncEnabled) {
            const newUrl = parseUrl(urlTemplate, symbol, profile.name);
            setCurrentUrl(newUrl);
            // If we are auto-syncing and tab name is empty, try to set it from the new URL
            if (!tabName) {
                const autoName = extractNameFromUrl(newUrl);
                if (autoName) {
                    setTabName(autoName);
                    // We need to persist this auto-name so the tab container sees it
                    onUpdateConfig({ urlTemplate, refreshInterval, isSyncEnabled, customTabName: autoName });
                }
            }
        } else if (!currentUrl) {
             // Initial load even if sync off
             const newUrl = parseUrl(urlTemplate, symbol, profile.name);
             setCurrentUrl(newUrl);
        }
    }, [urlTemplate, symbol, profile, isSyncEnabled]);

    // Persist Config
    const handleSaveConfig = (overrides?: any) => {
        onUpdateConfig({
            urlTemplate,
            refreshInterval,
            isSyncEnabled,
            customTabName: overrides?.customTabName !== undefined ? overrides.customTabName : tabName,
            ...overrides
        });
    };

    // Auto Refresh Logic
    useEffect(() => {
        if (isAutoRefresh && refreshInterval > 0) {
            timerRef.current = window.setInterval(() => {
                if (iframeRef.current) {
                    // Reload iframe
                    iframeRef.current.src = iframeRef.current.src;
                }
            }, refreshInterval * 1000 * 60); // Convert min to ms
        } else {
            if (timerRef.current) clearInterval(timerRef.current);
        }
        return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }, [isAutoRefresh, refreshInterval]);

    const handleGo = () => {
        const fullUrl = parseUrl(urlTemplate, symbol, profile.name);
        setCurrentUrl(fullUrl);
        
        // Auto-name logic: if tab name is empty, try to extract from URL
        let newName = tabName;
        if (!newName) {
            newName = extractNameFromUrl(fullUrl);
            if (newName) {
                setTabName(newName);
            }
        }
        
        handleSaveConfig({ customTabName: newName });
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-slate-900 overflow-hidden text-xs relative group">
            
            {/* Settings Panel (Overlay or Top Bar) */}
            {showSettings && (
                <div className="p-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-col gap-3 shrink-0 animate-in slide-in-from-top-2 z-20 shadow-md">
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-500 uppercase text-[10px] flex items-center gap-1">
                            <Settings className="w-3 h-3" /> Configuration
                        </span>
                        <button onClick={() => setShowSettings(false)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded text-slate-500 transition-colors">
                            <X className="w-3.5 h-3.5" />
                        </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        {/* URL Input */}
                        <div className="sm:col-span-2 relative">
                            <Link className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                            <input 
                                type="text" 
                                value={urlTemplate}
                                onChange={(e) => setUrlTemplate(e.target.value)}
                                onBlur={() => handleSaveConfig()}
                                onKeyDown={(e) => e.key === 'Enter' && handleGo()}
                                placeholder="https://example.com"
                                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md pl-8 pr-2 py-1.5 text-xs outline-none focus:border-indigo-500 text-slate-700 dark:text-slate-200"
                            />
                        </div>
                        
                        {/* Tab Name Input */}
                        <div className="relative flex gap-2">
                            <div className="relative flex-1">
                                <Tag className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                                <input 
                                    type="text" 
                                    value={tabName}
                                    onChange={(e) => setTabName(e.target.value)}
                                    onBlur={() => handleSaveConfig()}
                                    placeholder="Tab Name"
                                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md pl-8 pr-2 py-1.5 text-xs outline-none focus:border-indigo-500 text-slate-700 dark:text-slate-200"
                                />
                            </div>
                            <button 
                                onClick={handleGo}
                                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-md text-xs font-bold transition-colors"
                            >
                                Go
                            </button>
                        </div>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                        <div className="flex items-center justify-between text-[10px] text-slate-500">
                            <div className="flex items-center gap-4">
                                <label className="flex items-center gap-1.5 cursor-pointer select-none hover:text-slate-700 dark:hover:text-slate-300 transition-colors">
                                    <input 
                                        type="checkbox" 
                                        checked={isSyncEnabled} 
                                        onChange={(e) => { setIsSyncEnabled(e.target.checked); handleSaveConfig({ isSyncEnabled: e.target.checked }); }}
                                        className="rounded border-slate-300 dark:border-slate-600 accent-indigo-500" 
                                    />
                                    <span>Sync with Symbol</span>
                                </label>
                                
                                <div className="h-3 w-px bg-slate-300 dark:bg-slate-700"></div>

                                <div className="flex items-center gap-1.5">
                                    <span>Auto Refresh:</span>
                                    <input 
                                        type="number" 
                                        min="0"
                                        value={refreshInterval} 
                                        onChange={(e) => setRefreshInterval(Number(e.target.value))}
                                        className="w-10 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-center outline-none py-0.5"
                                    />
                                    <span>min</span>
                                    <button 
                                        onClick={() => setIsAutoRefresh(!isAutoRefresh)}
                                        disabled={refreshInterval <= 0}
                                        className={`ml-1 p-1 rounded transition-colors ${isAutoRefresh ? 'text-indigo-500 bg-indigo-50 dark:bg-indigo-900/30' : 'text-slate-400 hover:text-slate-600'} disabled:opacity-50`}
                                        title={isAutoRefresh ? "Pause Refresh" : "Start Auto Refresh"}
                                    >
                                        {isAutoRefresh ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-2 p-2 bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-200 rounded border border-amber-100 dark:border-amber-900/30">
                            <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                            <div className="text-[10px] leading-tight">
                                <strong>Connection Refused?</strong> Major sites (Baidu, Google) block embedding via <code>X-Frame-Options</code>. Use the <ExternalLink className="w-2.5 h-2.5 inline mx-0.5" /> icon below to open in a new tab.
                            </div>
                        </div>
                    
                        <div className="text-[9px] text-slate-400 truncate bg-slate-100 dark:bg-slate-800/50 p-1.5 rounded">
                            Replace: <code className="text-slate-600 dark:text-slate-300 font-bold">xxxxxx</code> (Code), <code className="text-slate-600 dark:text-slate-300 font-bold">!!</code> (Mkt), <code className="text-slate-600 dark:text-slate-300 font-bold">##STOCKNAME##</code>
                        </div>
                    </div>
                </div>
            )}

            {/* Iframe Content */}
            <div className="flex-1 bg-white relative w-full h-full min-h-0">
                {currentUrl ? (
                    <>
                        <iframe 
                            ref={iframeRef}
                            src={currentUrl}
                            className="w-full h-full border-none block"
                            sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                            title="Browser Widget"
                        />
                        {/* Fallback link if blocked */}
                        <a 
                            href={currentUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="absolute bottom-2 right-2 p-2 bg-slate-900/80 text-white rounded-full opacity-0 group-hover:opacity-50 hover:!opacity-100 transition-all z-10"
                            title="Open in New Tab (Fix Connection Refused)"
                        >
                            <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                    </>
                ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 p-4 text-center">
                        <Globe className="w-12 h-12 mb-2 opacity-20" />
                        <span>Enter a URL to browse.</span>
                        <button 
                            onClick={() => setShowSettings(true)}
                            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded text-xs font-bold hover:bg-indigo-500 transition-colors"
                        >
                            Configure Browser
                        </button>
                    </div>
                )}

                {/* Toggle Settings Button (Visible on hover when settings closed) */}
                {!showSettings && currentUrl && (
                    <button 
                        onClick={() => setShowSettings(true)}
                        className="absolute top-2 right-2 p-1.5 bg-slate-900/10 hover:bg-slate-900/80 text-slate-500 hover:text-white rounded-md shadow-sm backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all z-20"
                        title="Configure Browser"
                    >
                        <Settings className="w-3.5 h-3.5" />
                    </button>
                )}
            </div>
        </div>
    );
};
