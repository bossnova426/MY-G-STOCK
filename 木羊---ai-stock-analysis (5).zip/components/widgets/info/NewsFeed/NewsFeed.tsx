
import React from 'react';
import { WidgetContext } from '../../../../types';

export const NewsFeed: React.FC<WidgetContext> = ({ news }) => (
    <div className="h-full overflow-y-auto custom-scrollbar p-3 space-y-3">
        {news.map(item => (
            <div key={item.id} className="p-3 bg-slate-800/30 rounded border border-slate-700/50 hover:bg-slate-800/50 transition-colors cursor-pointer">
                <div className="text-[10px] text-indigo-400 mb-1 flex justify-between">
                    <span>{item.source}</span>
                    <span className="text-slate-500">{item.time}</span>
                </div>
                <h4 className="text-sm text-slate-200 leading-snug">{item.title}</h4>
            </div>
        ))}
        {news.length === 0 && <div className="text-center text-slate-500 text-xs py-4">No recent news for this symbol.</div>}
    </div>
);
