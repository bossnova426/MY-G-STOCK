
import React, { useMemo, useRef, useEffect } from 'react';
import { StockProfile, AppSettings } from '../../../../../types';

interface PriceVolumeDistributionProps {
  profile: StockProfile;
  settings?: AppSettings;
}

interface PriceLevel {
    price: number;
    volume: number;
    percent: number;
    type: 'buy' | 'sell' | 'neutral'; // Dominant side
    widthPercent: number; // For bar width
}

export const PriceVolumeDistribution: React.FC<PriceVolumeDistributionProps> = ({ profile, settings }) => {
  const upColor = settings?.modules.chart.upColor || '#10b981';
  const downColor = settings?.modules.chart.downColor || '#f43f5e';
  const scrollRef = useRef<HTMLDivElement>(null);

  // Mock Data Generation logic to simulate Price Distribution
  const data = useMemo(() => {
      const levels: PriceLevel[] = [];
      const currentPrice = profile.price;
      const prevClose = currentPrice - profile.change;
      
      // Generate 20 price levels centered around current price
      // In a real app, this comes from an API aggregation
      const range = currentPrice * 0.02; // +/- 2% range
      const step = range / 10; // approximate step
      
      const startPrice = currentPrice + (step * 8); // Start slightly above
      
      let totalVolume = 0;
      
      // 1. Generate Raw Levels
      for(let i=0; i < 20; i++) {
          const p = startPrice - (i * step);
          // Random volume with a bell curve-ish bias towards current price
          const distance = Math.abs(p - currentPrice);
          const volumeBase = Math.max(1000, 100000 - (distance * 1000000)); 
          const volume = Math.floor(volumeBase * (0.5 + Math.random()));
          
          totalVolume += volume;
          
          levels.push({
              price: parseFloat(p.toFixed(2)),
              volume,
              percent: 0,
              type: p >= prevClose ? 'buy' : 'sell', // Simplified logic: Price > PrevClose = Red (or Green depending on market)
              widthPercent: 0
          });
      }

      // 2. Normalize Data
      const maxVolume = Math.max(...levels.map(l => l.volume));
      
      return levels.map(l => ({
          ...l,
          percent: (l.volume / totalVolume) * 100,
          widthPercent: (l.volume / maxVolume) * 100
      }));
  }, [profile.symbol, profile.price]);

  // Scroll to center initially
  useEffect(() => {
      if (scrollRef.current) {
          // Attempt to center the scroll
          const rowHeight = 24; // approx px
          scrollRef.current.scrollTop = (data.length * rowHeight) / 2 - (scrollRef.current.clientHeight / 2);
      }
  }, [data.length]);

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 text-xs font-mono select-none overflow-hidden">
        {/* Header */}
        <div className="flex items-center px-2 py-1.5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 font-bold text-[10px] text-slate-500 uppercase sticky top-0 z-10 shrink-0">
            <div className="w-16 text-left">Price</div>
            <div className="w-20 text-right">Volume</div>
            <div className="flex-1 text-center">Dist</div>
            <div className="w-12 text-right">%</div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto custom-scrollbar relative" ref={scrollRef}>
            {data.map((row, i) => {
                const isCurrentPrice = Math.abs(row.price - profile.price) < 0.05;
                const rowColor = row.type === 'buy' ? upColor : downColor;
                
                return (
                    <div 
                        key={i} 
                        className={`flex items-center px-2 py-0.5 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors group relative ${isCurrentPrice ? 'bg-indigo-50/50 dark:bg-indigo-900/20' : ''}`}
                    >
                        {/* Price Column */}
                        <div className="w-16 text-left font-bold" style={{ color: rowColor }}>
                            {row.price.toFixed(2)}
                        </div>

                        {/* Volume Column (Number) */}
                        <div className="w-20 text-right text-slate-600 dark:text-slate-300 pr-2 z-10 relative">
                            {row.volume.toLocaleString()}
                        </div>

                        {/* Bar Chart Column */}
                        <div className="flex-1 h-3 flex items-center relative">
                            {/* Background Track */}
                            <div className="w-full h-full bg-slate-200 dark:bg-slate-800/50 rounded-sm overflow-hidden relative">
                                {/* Fill Bar */}
                                <div 
                                    className="h-full absolute left-0 top-0 transition-all duration-500 ease-out"
                                    style={{ 
                                        width: `${row.widthPercent}%`,
                                        backgroundColor: rowColor,
                                        opacity: 0.7
                                    }}
                                />
                                
                                {/* Current Price Indicator Line */}
                                {isCurrentPrice && (
                                    <div className="absolute inset-0 border-y border-indigo-500 z-20 opacity-50"></div>
                                )}
                            </div>
                        </div>

                        {/* Percentage Column */}
                        <div className="w-12 text-right" style={{ color: rowColor }}>
                            {row.percent.toFixed(2)}%
                        </div>
                    </div>
                );
            })}
        </div>
        
        {/* Footer Summary */}
        <div className="px-2 py-1 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-[10px] flex justify-between text-slate-400">
            <span>Levels: {data.length}</span>
            <span>Max Vol: {Math.max(...data.map(d => d.volume)).toLocaleString()}</span>
        </div>
    </div>
  );
};
