
import React, { useMemo, useEffect, useRef } from 'react';
import { StockProfile, AppSettings } from '../../../../../types';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface TransactionListProps {
  profile: StockProfile;
  settings?: AppSettings;
}

export const TransactionList: React.FC<TransactionListProps> = ({ profile, settings }) => {
  const upColor = settings?.modules.chart.upColor || '#10b981';
  const downColor = settings?.modules.chart.downColor || '#f43f5e';

  // Mock Data Generation based on profile price
  const data = useMemo(() => {
      const rows = [];
      // Start time
      const now = new Date();
      now.setHours(9, 30, 0); 
      
      let currentPrice = profile.price;
      
      // Generate 100 historical trades
      for(let i=0; i<100; i++) {
          // Increment time slightly
          now.setSeconds(now.getSeconds() + Math.floor(Math.random() * 30));
          
          const isBuy = Math.random() > 0.45; // Slightly biased
          const change = Math.random() > 0.7 ? (Math.random() * 0.05) : 0; // Sometimes price stays same
          
          const price = isBuy ? currentPrice + change : currentPrice - change;
          const vol = Math.floor(Math.random() * 50) + 1 + (Math.random() > 0.95 ? 500 : 0); // Occasional big order
          
          rows.push({
              time: now.toTimeString().slice(0, 5),
              seconds: now.getSeconds(),
              price: price,
              vol: vol,
              type: isBuy ? 'buy' : 'sell'
          });
          currentPrice = price;
      }
      
      return {
          rows,
          buyVol: Math.floor(Math.random() * 20000) + 5000,
          sellVol: Math.floor(Math.random() * 20000) + 5000
      };
  }, [profile.symbol]);

  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Auto scroll to bottom on mount/update
  useEffect(() => {
      if(scrollRef.current) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
  }, [data]);

  return (
      <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 text-xs font-mono select-none overflow-hidden">
          {/* Header Stats */}
          <div className="flex justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-[10px] font-bold shrink-0">
              <div className="flex items-center gap-2">
                  <span className="text-slate-500 uppercase">Outer</span>
                  <span style={{ color: upColor }}>{data.buyVol.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-2">
                  <span className="text-slate-500 uppercase">Inner</span>
                  <span style={{ color: downColor }}>{data.sellVol.toLocaleString()}</span>
              </div>
          </div>
          
          {/* List */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-1" ref={scrollRef}>
              <table className="w-full border-collapse">
                  <thead className="text-[10px] text-slate-400 sticky top-0 bg-slate-50/95 dark:bg-slate-900/95 backdrop-blur z-10">
                      <tr>
                          <th className="text-left font-normal pl-2 pb-1 pt-1">Time</th>
                          <th className="text-right font-normal pb-1 pt-1">Price</th>
                          <th className="text-right font-normal pr-2 pb-1 pt-1">Vol</th>
                      </tr>
                  </thead>
                  <tbody>
                      {data.rows.map((row, i) => {
                          const isLarge = row.vol > 400;
                          return (
                              <tr key={i} className="hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors group">
                                  <td className="pl-2 py-0.5 text-slate-500 group-hover:text-slate-700 dark:group-hover:text-slate-300">
                                      {row.time}
                                      {/* <span className="text-[9px] opacity-50 ml-0.5">:{row.seconds.toString().padStart(2, '0')}</span> */}
                                  </td>
                                  <td className="text-right py-0.5 font-bold" style={{ color: row.type === 'buy' ? upColor : downColor }}>
                                      {row.price.toFixed(2)}
                                  </td>
                                  <td className={`text-right pr-2 py-0.5 ${isLarge ? 'text-purple-500 font-bold' : ''}`}>
                                      <div className="flex items-center justify-end gap-1">
                                          <span>{row.vol}</span>
                                          <span style={{ color: row.type === 'buy' ? upColor : downColor }}>
                                              {row.type === 'buy' ? <ArrowUp className="w-2.5 h-2.5" /> : <ArrowDown className="w-2.5 h-2.5" />}
                                          </span>
                                      </div>
                                  </td>
                              </tr>
                          );
                      })}
                  </tbody>
              </table>
          </div>
      </div>
  );
};
