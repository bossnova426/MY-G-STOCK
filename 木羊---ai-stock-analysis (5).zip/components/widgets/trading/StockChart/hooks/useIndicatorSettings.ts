
import React, { useState, useCallback } from 'react';
import { IndicatorDefinition } from '../../../../../indicators/types';
import { loadIndicator } from '../../../../../services/indicatorService';

export const useIndicatorSettings = (
    indicatorConfigs: Record<string, any>,
    definitions: Map<string, IndicatorDefinition>,
    setDefinitions: React.Dispatch<React.SetStateAction<Map<string, IndicatorDefinition>>>
) => {
    const [isOpen, setIsOpen] = useState(false);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editingDef, setEditingDef] = useState<IndicatorDefinition | null>(null);

    const openSettings = useCallback(async (instanceId: string) => {
        const config = indicatorConfigs[instanceId];
        if (!config) return;
        const defId = config.defId;
        
        let def = definitions.get(defId);
        if (!def) {
            def = await loadIndicator(defId);
            if (def) setDefinitions(prev => new Map(prev).set(defId, def!));
        }
        
        if (def) {
            setEditingId(instanceId);
            setEditingDef(def);
            setIsOpen(true);
        }
    }, [indicatorConfigs, definitions, setDefinitions]);

    const closeSettings = useCallback(() => {
        setIsOpen(false);
        setEditingId(null);
        setEditingDef(null);
    }, []);

    return {
        isOpen,
        editingId,
        editingDef,
        openSettings,
        closeSettings
    };
};
