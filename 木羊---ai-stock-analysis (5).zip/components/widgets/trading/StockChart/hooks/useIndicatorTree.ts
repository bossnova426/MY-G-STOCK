
import { useMemo } from 'react';
import { Folder, CheckSquare } from 'lucide-react';
import { INDICATOR_REGISTRY } from '../../../../../services/indicatorService';
import { TreeNode } from '../../../../common/TreeBrowser';

export const useIndicatorTree = () => {
    return useMemo(() => {
        const root: TreeNode[] = [];
        const getFolder = (path: string[], parentArray: TreeNode[]): TreeNode[] => {
            if (path.length === 0) return parentArray;
            const currentName = path[0];
            let folder = parentArray.find(n => n.label === currentName && n.type === 'folder');
            if (!folder) {
                folder = { id: `cat-${currentName}`, label: currentName, type: 'folder', children: [], icon: Folder, color: 'text-amber-500' };
                parentArray.push(folder);
            }
            return getFolder(path.slice(1), folder.children!);
        };
        INDICATOR_REGISTRY.forEach(ind => {
            const parts = ind.category.split('/');
            const targetArray = getFolder(parts, root);
            targetArray.push({ id: ind.id, label: ind.name, type: 'item', icon: CheckSquare, color: 'text-slate-400', data: ind });
        });
        return root;
    }, []);
};
