
import React, { useCallback } from 'react';
import { IndicatorDefinition } from '../../../../../indicators/types';
import { loadIndicator } from '../../../../../services/indicatorService';

interface UseIndicatorActionsProps {
    activeIndicators: string[];
    indicatorConfigs: Record<string, any>;
    indicatorMap: Record<string, number>;
    maximizedPane: number | null;
    definitions: Map<string, IndicatorDefinition>;
    setDefinitions: React.Dispatch<React.SetStateAction<Map<string, IndicatorDefinition>>>;
    setIndicatorConfigs: React.Dispatch<React.SetStateAction<Record<string, any>>>;
    setActiveIndicators: React.Dispatch<React.SetStateAction<string[]>>;
    setIndicatorMap: React.Dispatch<React.SetStateAction<Record<string, number>>>;
    setVisiblePaneCount: React.Dispatch<React.SetStateAction<number>>;
    setMaximizedPane: React.Dispatch<React.SetStateAction<number | null>>;
}

export const useIndicatorActions = ({
    activeIndicators, indicatorConfigs, indicatorMap, maximizedPane, definitions,
    setDefinitions, setIndicatorConfigs, setActiveIndicators, setIndicatorMap, setVisiblePaneCount, setMaximizedPane
}: UseIndicatorActionsProps) => {

    const handleAddIndicator = useCallback(async (defId: string, preferredPane?: number) => {
        const instanceId = `${defId}-${Date.now()}-${Math.floor(Math.random()*1000)}`;
        
        let def = definitions.get(defId);
        if (!def) {
            def = await loadIndicator(defId);
            if (def) setDefinitions(prev => new Map(prev).set(defId, def!));
        }

        const period = defId.includes('20') ? 20 : 14;
        const newConfig = {
            id: instanceId,
            defId: defId,
            visible: true,
            period,
            params: {},
            color: def?.defaultStyle?.color || '#cccccc',
            lineWidth: 2,
            styles: {}
        };

        setIndicatorConfigs(prev => ({ ...prev, [instanceId]: newConfig }));
        setActiveIndicators(prev => [...prev, instanceId]);

        setIndicatorMap(prevMap => {
            let targetPane = 0;
            if (preferredPane !== undefined) {
                targetPane = preferredPane;
            } else if (def?.chartType === 'overlay') {
                targetPane = 0;
            } else {
                const currentPanes = Object.values(prevMap) as number[];
                const maxPane = currentPanes.length > 0 ? Math.max(0, ...currentPanes) : 0;
                targetPane = maxPane + 1;
            }
            return { ...prevMap, [instanceId]: targetPane };
        });
    }, [definitions, setDefinitions, setIndicatorConfigs, setActiveIndicators, setIndicatorMap]);

    const handleRemoveIndicator = useCallback((instanceId: string) => {
        const nextIndicators = activeIndicators.filter(id => id !== instanceId);
        setActiveIndicators(nextIndicators);

        const paneIdx = indicatorMap[instanceId];
        const isPaneStillUsed = nextIndicators.some(id => indicatorMap[id] === paneIdx);

        const nextMap = { ...indicatorMap };
        delete nextMap[instanceId];
        
        setIndicatorConfigs(prev => {
            const next = { ...prev };
            delete next[instanceId];
            return next;
        });

        if (paneIdx > 0 && !isPaneStillUsed) {
            // Shift panes up
            Object.keys(nextMap).forEach(key => {
                if (nextMap[key] > paneIdx) {
                    nextMap[key] = nextMap[key] - 1;
                }
            });
            setVisiblePaneCount(prev => Math.max(1, prev - 1));
            if (maximizedPane === paneIdx) setMaximizedPane(null);
        }
        setIndicatorMap(nextMap);
    }, [activeIndicators, indicatorMap, maximizedPane, setActiveIndicators, setIndicatorConfigs, setIndicatorMap, setVisiblePaneCount, setMaximizedPane]);

    return { handleAddIndicator, handleRemoveIndicator };
};
