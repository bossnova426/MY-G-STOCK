
import { useState, useRef, useEffect } from 'react';

export const useStockChartState = () => {
    // --- UI State ---
    const [chartMode, setChartMode] = useState<'candles' | 'line' | 'area' | 'bars'>('candles');
    const [timeframe, setTimeframe] = useState<string>('1D');
    const [isLogScale, setIsLogScale] = useState(false); 
    const [visiblePaneCount, setVisiblePaneCount] = useState<number>(2);
    const [activePane, setActivePane] = useState<number>(0); 
    const [maximizedPane, setMaximizedPane] = useState<number | null>(null);
    const [rightOffset, setRightOffset] = useState<number>(10);
    
    // --- Indicators & Comparisons State ---
    const [comparisons, setComparisons] = useState<string[]>([]); 
    const [activeIndicators, setActiveIndicators] = useState<string[]>([]); // Instance IDs
    const [indicatorConfigs, setIndicatorConfigs] = useState<Record<string, any>>({});
    const [indicatorMap, setIndicatorMap] = useState<Record<string, number>>({});

    return {
        chartMode, setChartMode,
        timeframe, setTimeframe,
        isLogScale, setIsLogScale,
        visiblePaneCount, setVisiblePaneCount,
        activePane, setActivePane,
        maximizedPane, setMaximizedPane,
        rightOffset, setRightOffset,
        comparisons, setComparisons,
        activeIndicators, setActiveIndicators,
        indicatorConfigs, setIndicatorConfigs,
        indicatorMap, setIndicatorMap
    };
};
