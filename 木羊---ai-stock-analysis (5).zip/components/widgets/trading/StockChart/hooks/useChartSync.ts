
import { useState, useRef, useEffect, useCallback } from 'react';
import { IChartApi, Time, LogicalRange } from 'lightweight-charts';

export const useChartSync = (onHover?: (label: string | null) => void) => {
    const chartsRef = useRef<Map<number, IChartApi>>(new Map());
    const [syncRange, setSyncRange] = useState<LogicalRange | null>(null);
    const [syncCrosshair, setSyncCrosshair] = useState<{ time: Time, x: number } | null>(null);
    const [containerHeight, setContainerHeight] = useState(600);
    const containerRef = useRef<HTMLDivElement>(null);

    // Resize Observer
    useEffect(() => {
        if (!containerRef.current) return;
        const ro = new ResizeObserver(entries => {
            for (const entry of entries) {
                setContainerHeight(entry.contentRect.height);
            }
        });
        ro.observe(containerRef.current);
        return () => ro.disconnect();
    }, []);

    const handleChartReady = useCallback((idx: number, api: IChartApi | null) => {
        if (api) chartsRef.current.set(idx, api);
        else chartsRef.current.delete(idx);
    }, []);

    const handleSyncHover = useCallback((time: string | null) => {
        if (onHover) onHover(time);
        if (time) {
            setSyncCrosshair({ time: time as Time, x: 0 });
        } else {
            setSyncCrosshair(null);
        }
    }, [onHover]);

    return {
        chartsRef,
        syncRange,
        setSyncRange,
        syncCrosshair,
        containerHeight,
        containerRef,
        handleChartReady,
        handleSyncHover
    };
};
