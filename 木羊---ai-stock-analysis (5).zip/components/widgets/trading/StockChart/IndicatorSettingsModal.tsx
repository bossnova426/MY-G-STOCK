
import React, { useState, useEffect } from 'react';
import { X, Save, RotateCcw, Sliders, Palette, Info, Eye, EyeOff, Tag } from 'lucide-react';
import { IndicatorDefinition, IndicatorParams, IndicatorStyle } from '../../../../indicators/types';

interface IndicatorSettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    definition: IndicatorDefinition;
    currentParams: IndicatorParams;
    currentStyle: any; 
    onUpdate: (params: IndicatorParams, style: any) => void; // New for Real-time
    onSave: (params: IndicatorParams, style: any) => void;
}

type Tab = 'INPUTS' | 'STYLE' | 'INFO';

export const IndicatorSettingsModal: React.FC<IndicatorSettingsModalProps> = ({ 
    isOpen, onClose, definition, currentParams, currentStyle, onUpdate, onSave 
}) => {
    const [activeTab, setActiveTab] = useState<Tab>('INPUTS');
    const [params, setParams] = useState<IndicatorParams>(currentParams || {});
    const [styles, setStyles] = useState<any>(currentStyle || {});

    // Sync state when opening
    useEffect(() => {
        if (isOpen) {
            // Merge defaults if missing
            const mergedParams = { ...currentParams };
            definition.paramDefs?.forEach(def => {
                if (mergedParams[def.key] === undefined) mergedParams[def.key] = def.default;
            });
            setParams(mergedParams);

            // Initialize styles
            if (definition.outputDefs) {
                const mergedStyles: Record<string, IndicatorStyle> = { ...(currentStyle || {}) };
                definition.outputDefs.forEach(out => {
                    if (!mergedStyles[out.key]) {
                        mergedStyles[out.key] = { ...out.defaultStyle, visible: true };
                    }
                });
                setStyles(mergedStyles);
            } else {
                setStyles(currentStyle || definition.defaultStyle || { color: '#000000', lineWidth: 1, visible: true });
            }
        }
    }, [isOpen, definition, currentParams, currentStyle]);

    if (!isOpen) return null;

    const handleParamChange = (key: string, value: any) => {
        const newParams = { ...params, [key]: value };
        setParams(newParams);
        onUpdate(newParams, styles); // Real-time update
    };

    const handleStyleChange = (key: string | null, prop: keyof IndicatorStyle | 'showLabel', value: any) => {
        let newStyles;
        if (key) {
            newStyles = {
                ...styles,
                [key]: {
                    ...styles[key],
                    [prop]: value
                }
            };
        } else {
            newStyles = {
                ...styles,
                [prop]: value
            };
        }
        setStyles(newStyles);
        onUpdate(params, newStyles); // Real-time update
    };

    const handleReset = () => {
        const defaultParams: any = {};
        definition.paramDefs?.forEach(d => defaultParams[d.key] = d.default);
        
        let defaultStyles: any = {};
        if (definition.outputDefs) {
            definition.outputDefs.forEach(out => {
                defaultStyles[out.key] = { ...out.defaultStyle, visible: true };
            });
        } else {
            defaultStyles = definition.defaultStyle || {};
        }
        
        setParams(defaultParams);
        setStyles(defaultStyles);
        onUpdate(defaultParams, defaultStyles);
    };

    const handleClose = () => {
        onSave(params, styles); // Commit on close
        onClose();
    };

    const renderStyleRow = (label: string, styleObj: any, onChange: (prop: keyof IndicatorStyle | 'showLabel', val: any) => void) => (
        <div className="flex flex-col gap-1 p-2 border border-slate-100 dark:border-slate-800 rounded mb-2">
            <div className="flex items-center gap-2">
                <div className="w-24 truncate text-xs font-bold text-slate-700 dark:text-slate-300" title={label}>{label}</div>
                
                {/* Color */}
                <input 
                    type="color" 
                    value={styleObj.color || '#000000'}
                    onChange={e => onChange('color', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-none p-0 bg-transparent shrink-0"
                    title="Color"
                />

                {/* Width */}
                <select 
                    value={styleObj.lineWidth || 1}
                    onChange={e => onChange('lineWidth', parseInt(e.target.value))}
                    className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[10px] px-1 py-1 outline-none w-16"
                    title="Line Width"
                >
                    <option value={1}>1px</option>
                    <option value={2}>2px</option>
                    <option value={3}>3px</option>
                    <option value={4}>4px</option>
                </select>

                {/* Type/Style (Solid/Dash) */}
                <select 
                    value={styleObj.lineStyle || 0}
                    onChange={e => onChange('lineStyle', parseInt(e.target.value))}
                    className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[10px] px-1 py-1 outline-none w-20"
                    title="Line Style"
                >
                    <option value={0}>Solid</option>
                    <option value={1}>Dotted</option>
                    <option value={2}>Dashed</option>
                </select>

                {/* Visibility */}
                <button 
                    onClick={() => onChange('visible', !styleObj.visible)}
                    className={`p-1 rounded ${styleObj.visible !== false ? 'text-indigo-500' : 'text-slate-400'}`}
                    title="Toggle Visibility"
                >
                    {styleObj.visible !== false ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
            </div>
            
            {/* Show Label Checkbox */}
            <div className="flex items-center gap-2 pl-26 ml-24">
                <label className="flex items-center gap-1.5 cursor-pointer select-none">
                    <input 
                        type="checkbox" 
                        checked={!!styleObj.showLabel} 
                        onChange={(e) => onChange('showLabel', e.target.checked)}
                        className="rounded border-slate-300 dark:border-slate-600 accent-indigo-500 w-3.5 h-3.5"
                    />
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Tag className="w-3 h-3" /> Show Label & Line
                    </span>
                </label>
            </div>
        </div>
    );

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200" onClick={handleClose}>
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 w-[450px] rounded-xl shadow-2xl flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
                
                {/* Header */}
                <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-950">
                    <h3 className="font-bold text-slate-800 dark:text-white text-sm flex items-center gap-2">
                        <Sliders className="w-4 h-4 text-indigo-500" />
                        {definition.name}
                    </h3>
                    <button onClick={handleClose} className="text-slate-500 hover:text-slate-800 dark:hover:text-white"><X className="w-4 h-4" /></button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                    <button onClick={() => setActiveTab('INPUTS')} className={`flex-1 py-2 text-xs font-bold border-b-2 transition-colors ${activeTab === 'INPUTS' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>Inputs</button>
                    <button onClick={() => setActiveTab('STYLE')} className={`flex-1 py-2 text-xs font-bold border-b-2 transition-colors ${activeTab === 'STYLE' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>Style</button>
                    <button onClick={() => setActiveTab('INFO')} className={`flex-1 py-2 text-xs font-bold border-b-2 transition-colors ${activeTab === 'INFO' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>Info</button>
                </div>

                {/* Content */}
                <div className="p-4 h-[350px] overflow-y-auto custom-scrollbar bg-white dark:bg-slate-900">
                    
                    {/* INPUTS TAB */}
                    {activeTab === 'INPUTS' && (
                        <div className="space-y-4">
                            {!definition.paramDefs || definition.paramDefs.length === 0 ? (
                                <div className="text-center text-slate-400 text-xs py-10 italic">No customizable parameters.</div>
                            ) : (
                                definition.paramDefs.map(def => (
                                    <div key={def.key} className="flex flex-col gap-1.5">
                                        <div className="flex justify-between items-center">
                                            <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{def.label}</label>
                                            
                                            {/* Control Types */}
                                            {def.type === 'boolean' ? (
                                                <div 
                                                    className={`w-8 h-4 rounded-full cursor-pointer relative transition-colors ${params[def.key] ? 'bg-indigo-500' : 'bg-slate-300 dark:bg-slate-600'}`}
                                                    onClick={() => handleParamChange(def.key, !params[def.key])}
                                                >
                                                    <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-transform ${params[def.key] ? 'left-4.5' : 'left-0.5'}`} style={{ left: params[def.key] ? '18px' : '2px' }}></div>
                                                </div>
                                            ) : def.type === 'number' ? (
                                                <input 
                                                    type="number"
                                                    value={params[def.key]}
                                                    onChange={e => handleParamChange(def.key, parseFloat(e.target.value))}
                                                    min={def.min}
                                                    max={def.max}
                                                    step={def.step || 1}
                                                    className="w-20 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs px-2 py-1 text-right outline-none focus:border-indigo-500"
                                                />
                                            ) : def.type === 'select' ? (
                                                <select
                                                    value={params[def.key]}
                                                    onChange={e => handleParamChange(def.key, e.target.value)}
                                                    className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs px-2 py-1 outline-none focus:border-indigo-500 min-w-[100px]"
                                                >
                                                    {def.options?.map(opt => (
                                                        <option key={opt} value={opt}>{opt}</option>
                                                    ))}
                                                </select>
                                            ) : def.type === 'string' ? (
                                                <input 
                                                    type="text"
                                                    value={params[def.key]}
                                                    onChange={e => handleParamChange(def.key, e.target.value)}
                                                    className="flex-1 ml-4 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs px-2 py-1 outline-none focus:border-indigo-500"
                                                />
                                            ) : (
                                                <input 
                                                    type="color"
                                                    value={params[def.key]}
                                                    onChange={e => handleParamChange(def.key, e.target.value)}
                                                    className="w-6 h-6 rounded cursor-pointer border-none p-0 bg-transparent"
                                                />
                                            )}
                                        </div>
                                        
                                        {/* Slider for Numbers */}
                                        {def.type === 'number' && def.min !== undefined && def.max !== undefined && (
                                            <input 
                                                type="range" 
                                                min={def.min} max={def.max} step={def.step || 1}
                                                value={params[def.key]} 
                                                onChange={e => handleParamChange(def.key, parseFloat(e.target.value))}
                                                className="w-full h-1 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                                            />
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    )}

                    {/* STYLE TAB */}
                    {activeTab === 'STYLE' && (
                        <div className="space-y-2">
                            {definition.outputDefs && definition.outputDefs.length > 0 ? (
                                definition.outputDefs.map(output => (
                                    renderStyleRow(
                                        output.label, 
                                        styles[output.key] || output.defaultStyle, 
                                        (prop, val) => handleStyleChange(output.key, prop, val)
                                    )
                                ))
                            ) : (
                                // Legacy Single Style
                                renderStyleRow('Main Plot', styles, (prop, val) => handleStyleChange(null, prop, val))
                            )}
                        </div>
                    )}

                    {/* INFO TAB */}
                    {activeTab === 'INFO' && (
                        <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300">
                            <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded border border-slate-200 dark:border-slate-700">
                                <div className="font-bold text-slate-800 dark:text-white mb-1">{definition.name}</div>
                                <div className="text-slate-500 mb-2">{definition.category}</div>
                                <p className="leading-relaxed">{definition.description || "No description available."}</p>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-1">
                                    <span className="text-slate-500">ID</span>
                                    <span className="font-mono">{definition.id}</span>
                                </div>
                                <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-1">
                                    <span className="text-slate-500">Version</span>
                                    <span>{definition.version || '1.0.0'}</span>
                                </div>
                                <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-1">
                                    <span className="text-slate-500">Author</span>
                                    <span>{definition.author || 'System'}</span>
                                </div>
                                <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-1">
                                    <span className="text-slate-500">Source</span>
                                    <span className="capitalize">{definition.source}</span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex justify-between">
                    <button 
                        onClick={handleReset}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
                    >
                        <RotateCcw className="w-3 h-3" /> Defaults
                    </button>
                    <div className="flex gap-2">
                        <button 
                            onClick={handleClose}
                            className="flex items-center gap-1.5 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold shadow-sm transition-colors"
                        >
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
