
import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Eye, EyeOff, ArrowUp, ArrowDown, Maximize, Minimize, Settings, Trash2, Loader2, X } from 'lucide-react';
import { IndicatorDefinition } from '../../../../indicators/types';
import { INDICATOR_REGISTRY } from '../../../../services/indicatorService';

interface ChartLegendProps {
    paneIndex: number;
    visiblePaneCount: number; // Added to interface to avoid TS error, though unused in logic
    activePane: number;
    setActivePane: (i: number) => void;
    maximizedPane: number | null;
    setMaximizedPane: (i: number | null) => void;
    
    activeIndicators: string[]; // These are Instance IDs
    indicatorMap: Record<string, number>;
    indicatorConfigs: Record<string, any>;
    definitions: Map<string, IndicatorDefinition>;
    calculatingIndicators: Set<string>;
    comparisons: string[];
    
    onToggleVisibility: (id: string) => void;
    onMovePane: (id: string, dir: 'up' | 'down') => void;
    onSettings: (id: string) => void;
    onRemove: (id: string) => void;
    onRemoveComparison: (sym: string) => void;
}

export const ChartLegend: React.FC<ChartLegendProps> = ({
    paneIndex,
    activePane,
    setActivePane,
    maximizedPane,
    setMaximizedPane,
    activeIndicators,
    indicatorMap,
    indicatorConfigs,
    definitions,
    calculatingIndicators,
    comparisons,
    onToggleVisibility,
    onMovePane,
    onSettings,
    onRemove,
    onRemoveComparison
}) => {
    const [isNameHidden, setIsNameHidden] = useState(false);

    // Filter indicators for THIS paneIndex
    const indInstances = activeIndicators.filter(instanceId => {
        const config = indicatorConfigs[instanceId];
        // Ensure defId is extracted safely; if config is missing, try extracting from ID
        const defId = config?.defId || (instanceId && typeof instanceId === 'string' ? instanceId.split('-')[0] : '');
        
        if (!defId) return false;

        const def = definitions.get(defId) || INDICATOR_REGISTRY.find(d => d.id === defId);
        
        // Ensure mapped pane index is valid; default based on chart type
        const mapped = indicatorMap[instanceId] ?? (def?.chartType === 'overlay' ? 0 : 1);
        return mapped === paneIndex;
    });

    return (
        <div className="absolute top-2 left-2 z-30 flex flex-col gap-1 pointer-events-auto max-w-[300px]">
            {/* Comparisons Legend (Only on Main Pane 0) */}
            {paneIndex === 0 && comparisons && comparisons.length > 0 && (
                <div className="flex flex-col gap-1 mb-1">
                    {comparisons.map((sym, idx) => (
                        <div key={sym} className="flex items-center gap-2 bg-white/80 dark:bg-slate-900/80 backdrop-blur border border-slate-200 dark:border-slate-800 px-2 py-0.5 rounded-full text-[10px] shadow-sm animate-in fade-in slide-in-from-left-2 w-fit">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: ['#f59e0b', '#8b5cf6', '#ec4899'][idx % 3] }}></span>
                            <span className="font-bold text-slate-700 dark:text-slate-200">{sym}</span>
                            <button onClick={() => onRemoveComparison(sym)} className="text-slate-400 hover:text-rose-500"><X className="w-3 h-3" /></button>
                        </div>
                    ))}
                </div>
            )}

            {/* Pane Header Label */}
            <div className="group/pane-header flex items-center gap-2">
                 <span 
                    className={`text-[9px] font-bold uppercase cursor-pointer select-none transition-colors ${activePane === paneIndex ? 'text-indigo-500' : 'text-slate-400 hover:text-slate-300'}`} 
                    onClick={(e) => { e.stopPropagation(); setActivePane(paneIndex); }}
                 >
                    {paneIndex === 0 ? 'Main' : `Win ${paneIndex + 1}`} {activePane === paneIndex ? '(Active)' : ''}
                </span>
                {indInstances.length > 0 && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); setIsNameHidden(!isNameHidden); }} 
                        className="p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 opacity-0 group-hover/pane-header:opacity-100 transition-opacity"
                    >
                        {isNameHidden ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />}
                    </button>
                )}
            </div>

            {/* Indicator Labels for this Pane */}
            <div className="flex flex-col gap-1 pl-1">
                {indInstances.map(instanceId => {
                    const config = indicatorConfigs[instanceId];
                    const defId = config?.defId || (instanceId && typeof instanceId === 'string' ? instanceId.split('-')[0] : '');
                    const def = definitions.get(defId) || INDICATOR_REGISTRY.find(i => i.id === defId);
                    
                    const isCalculating = calculatingIndicators.has(instanceId);
                    
                    let legendColor = config?.color || '#cccccc';
                    if (config?.styles && Object.values(config.styles).length > 0) {
                        const styleObj: any = Object.values(config.styles)[0];
                        legendColor = styleObj.color;
                    }

                    return (
                        <div key={instanceId} className="flex items-center gap-1 bg-white/80 dark:bg-slate-900/80 backdrop-blur border border-slate-200 dark:border-slate-800 px-2 py-0.5 rounded-full text-[10px] shadow-sm group/legend w-fit">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: legendColor }}></span>
                            <span className={`font-bold mr-1 ${config?.visible !== false ? 'text-slate-700 dark:text-slate-200' : 'text-slate-400 line-through'}`}>
                                {isNameHidden ? '' : def?.shortName} {config?.period && `(${config.period})`}
                            </span>
                            {isCalculating && <Loader2 className="w-3 h-3 animate-spin text-slate-400" />}
                            
                            {/* Actions on Hover */}
                            <div className="flex items-center gap-1 opacity-0 group-hover/legend:opacity-100 transition-opacity">
                                <button onClick={() => onToggleVisibility(instanceId)} className="p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">{config?.visible !== false ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}</button>
                                <button onClick={() => onMovePane(instanceId, 'up')} className="p-0.5 text-slate-400 hover:text-indigo-500" title="Move to Upper Pane"><ArrowUp className="w-3 h-3" /></button>
                                <button onClick={() => onMovePane(instanceId, 'down')} className="p-0.5 text-slate-400 hover:text-indigo-500" title="Move to Lower Pane"><ArrowDown className="w-3 h-3" /></button>
                                <button onClick={() => setMaximizedPane(maximizedPane === paneIndex ? null : paneIndex)} className="p-0.5 text-slate-400 hover:text-emerald-500">{maximizedPane === paneIndex ? <Minimize className="w-3 h-3" /> : <Maximize className="w-3 h-3" />}</button>
                                <button onClick={() => onSettings(instanceId)} className="p-0.5 text-slate-400 hover:text-indigo-500"><Settings className="w-3 h-3" /></button>
                                <button onClick={() => onRemove(instanceId)} className="p-0.5 text-slate-400 hover:text-rose-500"><Trash2 className="w-3 h-3" /></button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
