
import { useState, useEffect } from 'react';
import { StockDataPoint } from '../../../../types';
import { generateStockData } from '../../../../services/mockDataService';
import { loadIndicator, INDICATOR_REGISTRY } from '../../../../services/indicatorService';
import { IndicatorDefinition } from '../../../../indicators/types';

export const useChartData = (
    initialData: StockDataPoint[],
    symbol: string,
    timeframe: string,
    activeIndicators: string[], // These are now Instance IDs (e.g. "sma20-123")
    comparisons: string[],
    indicatorConfigs: Record<string, any> // Maps Instance ID -> Config (containing defId)
) => {
    const [activeData, setActiveData] = useState<StockDataPoint[]>(initialData);
    const [calculatedData, setCalculatedData] = useState<StockDataPoint[]>([]);
    const [compareData, setCompareData] = useState<Record<string, StockDataPoint[]>>({});
    const [calculatingIndicators, setCalculatingIndicators] = useState<Set<string>>(new Set());
    const [definitions, setDefinitions] = useState<Map<string, IndicatorDefinition>>(new Map());
    const [isLoading, setIsLoading] = useState(false);

    // 1. Fetch/Generate Base Data
    useEffect(() => {
        setIsLoading(true);
        // Simulate network request delay for realism
        const timer = setTimeout(() => {
            const multiplier = timeframe === '1m' ? 1000 : timeframe === '1D' ? 100 : 50;
            const newData = generateStockData(symbol, multiplier);
            setActiveData(newData);
            setIsLoading(false);
        }, 300);
        return () => clearTimeout(timer);
    }, [timeframe, symbol]);

    // 2. Fetch Comparison Data
    useEffect(() => {
        const missing = comparisons.filter(sym => !compareData[sym]);
        if (missing.length > 0) {
            const newData = { ...compareData };
            missing.forEach(sym => {
                newData[sym] = generateStockData(sym, activeData.length > 0 ? activeData.length : 100);
            });
            setCompareData(newData);
        }
    }, [comparisons, activeData.length]);

    // 3. Calculation Loop (Supports Multi-Instance)
    useEffect(() => {
        const compute = async () => {
            // Start with base data
            // We map to a new array to avoid mutating activeData directly during calculation phases
            let enriched = activeData.map(d => ({ ...d })); 
            const newDefs = new Map<string, IndicatorDefinition>(definitions);
            
            // activeIndicators contains Instance IDs (e.g. 'sma20-171...', 'vol-171...')
            for (const instanceId of activeIndicators) {
                const config = indicatorConfigs[instanceId];
                // Fallback: if no config (race condition), assume instanceId is defId (legacy compat)
                const defId = config?.defId || instanceId.split('-')[0]; 

                let definition: IndicatorDefinition | undefined = newDefs.get(defId) as IndicatorDefinition | undefined;
                if (!definition) {
                    definition = await loadIndicator(defId);
                    if (definition) newDefs.set(defId, definition);
                }
                
                if (definition && definition.calculate) {
                    const params = { period: config?.period, ...(config?.params || {}) };
                    
                    if (definition.source === 'remote' || definition.isAsync) {
                        setCalculatingIndicators(prev => new Set(prev).add(instanceId));
                    }

                    try {
                        // Calculate using the generic definition
                        const result = await definition.calculate(activeData, params);
                        
                        // REMAPPING STEP: 
                        // Map the generic output keys (e.g., 'sma20', 'k', 'd') to Instance-Specific keys (e.g., 'sma20-123_main')
                        // This prevents collisions when adding the same indicator twice.
                        
                        // Determine which keys to look for in the result
                        let sourceKeys: string[] = [];
                        if (definition.outputDefs) {
                            sourceKeys = definition.outputDefs.map(o => o.key);
                        } else {
                            // Heuristics for built-ins without explicit outputDefs
                            if (defId === 'vol') sourceKeys = ['vol'];
                            else if (defId === 'ms_pattern') sourceKeys = ['ms_pattern_high', 'ms_pattern_low'];
                            else sourceKeys = [defId]; // Default behavior (e.g. sma20 -> key 'sma20')
                        }

                        if (result.length === enriched.length) {
                            for (let i = 0; i < enriched.length; i++) {
                                // 1. Map standard values
                                sourceKeys.forEach(key => {
                                    const val = result[i][key];
                                    
                                    // Special handling: Construct target key to match ChartPane expectation
                                    let targetKey = `${instanceId}-main`;
                                    if (definition.outputDefs) {
                                        targetKey = `${instanceId}-${key}`;
                                    } else if (defId === 'vol') {
                                        targetKey = `${instanceId}-vol`;
                                    }

                                    // Strict null AND NaN check to prevent crashing charts
                                    // Also enforce Number type
                                    if (val !== undefined && val !== null) {
                                        const numVal = Number(val);
                                        if (!isNaN(numVal)) {
                                            enriched[i][targetKey] = numVal;
                                        }
                                    }
                                });

                                // 2. Map Markers (Special Case)
                                if (result[i]._markers) {
                                    enriched[i][`${instanceId}-markers`] = result[i]._markers;
                                }
                            }
                        }
                    } catch (e) {
                        console.error(`Calculation failed for ${instanceId} (${defId})`, e);
                    } finally {
                        if (definition.source === 'remote' || definition.isAsync) {
                            setCalculatingIndicators(prev => {
                                const next = new Set(prev);
                                next.delete(instanceId);
                                return next;
                            });
                        }
                    }
                }
            }
            setDefinitions(newDefs);
            setCalculatedData(enriched);
        };
        
        if (activeData.length > 0) {
            compute();
        }
    }, [activeData, activeIndicators, indicatorConfigs]);

    return {
        activeData,
        calculatedData,
        compareData,
        calculatingIndicators,
        definitions,
        setDefinitions,
        isLoading
    };
};
