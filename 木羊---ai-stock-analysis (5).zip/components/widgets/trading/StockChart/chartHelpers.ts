
import { ColorType, CrosshairMode, DeepPartial, ChartOptions, PriceScaleMode } from 'lightweight-charts';
import { AppSettings } from '../../../../types';

// TradingView-like Smart Precision (e.g., crypto needs more decimals)
export const getSmartPrecision = (price: number) => {
    if (price < 0.001) return 6;
    if (price < 1) return 4;
    if (price < 50) return 2; // Penny stocks / low value
    return 2; // Standard
};

export const getChartOptions = (
    container: HTMLElement, 
    settings: AppSettings | undefined, 
    symbol: string, 
    isLogScale: boolean,
    isMainPane: boolean,
    currentPrice: number,
    rightOffset: number = 5,
    showTimeScale: boolean = true
): DeepPartial<ChartOptions> => {
    const isDark = settings?.theme === 'dark';
    const precision = getSmartPrecision(currentPrice);

    return {
        layout: {
            background: { type: ColorType.Solid, color: isDark ? '#020617' : '#ffffff' }, // Slate-950 or White
            textColor: isDark ? '#94a3b8' : '#334155',
            fontFamily: "'Inter', sans-serif",
            fontSize: 11,
            attributionLogo: false, // Requirement 4: Remove Logo
        },
        grid: {
            vertLines: { color: isDark ? '#1e293b' : '#f1f5f9' }, // Subtle grid
            horzLines: { color: isDark ? '#1e293b' : '#f1f5f9' },
        },
        width: container.clientWidth,
        height: container.clientHeight,
        crosshair: { 
            mode: CrosshairMode.Normal,
            vertLine: {
                labelBackgroundColor: isDark ? '#475569' : '#94a3b8',
                color: isDark ? '#475569' : '#cbd5e1',
            },
            horzLine: {
                labelBackgroundColor: isDark ? '#475569' : '#94a3b8',
                color: isDark ? '#475569' : '#cbd5e1',
            }
        },
        timeScale: { 
            borderColor: isDark ? '#1e293b' : '#e2e8f0', 
            visible: showTimeScale,
            timeVisible: true,
            rightOffset: rightOffset, // Dynamic Right Offset
        },
        rightPriceScale: { 
            borderColor: isDark ? '#1e293b' : '#e2e8f0', 
            mode: isLogScale ? PriceScaleMode.Logarithmic : PriceScaleMode.Normal,
            autoScale: true,
            minimumWidth: 70, // Enforce fixed width for alignment across stacked charts
        },
        localization: {
            priceFormatter: (p: number) => p.toFixed(precision),
        },
        handleScroll: {
            mouseWheel: true,
            pressedMouseMove: true,
            horzTouchDrag: true,
            vertTouchDrag: true,
        },
        handleScale: {
            axisPressedMouseMove: true,
            mouseWheel: true,
            pinch: true,
        }
    };
};
