
import React, { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Layers, PlusCircle, Save, LayoutTemplate, Settings2, X } from 'lucide-react';
import { TreeBrowser } from '../../../common/TreeBrowser';
import { TreeNode } from '../../../common/TreeBrowser';

interface ChartToolbarProps {
    symbol: string;
    tooltipSymbol?: string;
    timeframe: string;
    setTimeframe: (tf: string) => void;
    visiblePaneCount: number;
    rightOffset: number;
    setRightOffset: (n: number) => void;
    onAddComparison: () => void;
    onSaveTemplate: () => void;
    onAddIndicator: (id: string) => void;
    indicatorTreeData: TreeNode[];
}

const TIMEFRAMES = ['1m', '5m', '15m', '1H', '4H', '1D', '1W', '1M'];

export const ChartToolbar: React.FC<ChartToolbarProps> = ({
    symbol,
    tooltipSymbol,
    timeframe,
    setTimeframe,
    visiblePaneCount,
    rightOffset,
    setRightOffset,
    onAddComparison,
    onSaveTemplate,
    onAddIndicator,
    indicatorTreeData
}) => {
    const indBtnRef = useRef<HTMLButtonElement>(null);
    const viewBtnRef = useRef<HTMLButtonElement>(null);
    
    const [isIndicatorMenuOpen, setIsIndicatorMenuOpen] = useState(false);
    const [isViewMenuOpen, setIsViewMenuOpen] = useState(false);
    
    const [indMenuPos, setIndMenuPos] = useState<{top: number, left: number}>({ top: 0, left: 0 });
    const [viewMenuPos, setViewMenuPos] = useState<{top: number, left: number}>({ top: 0, left: 0 });

    const openIndMenu = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (indBtnRef.current) {
            const rect = indBtnRef.current.getBoundingClientRect();
            setIndMenuPos({ top: rect.bottom + 5, left: rect.left });
            setIsIndicatorMenuOpen(true);
            setIsViewMenuOpen(false);
        }
    };

    const openViewMenu = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (viewBtnRef.current) {
            const rect = viewBtnRef.current.getBoundingClientRect();
            setViewMenuPos({ top: rect.bottom + 5, left: rect.left });
            setIsViewMenuOpen(true);
            setIsIndicatorMenuOpen(false);
        }
    };

    return (
        <>
            <div className="flex items-center justify-between px-2 py-1.5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-40 shrink-0 select-none">
                <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-800 dark:text-slate-100">{tooltipSymbol || symbol}</span>
                    
                    <button onClick={onAddComparison} className="p-0.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-indigo-500 transition-colors" title="Compare Symbol"><PlusCircle className="w-4 h-4" /></button>

                    <div className="flex gap-0.5 ml-2 border-l border-slate-200 dark:border-slate-800 pl-2">
                        {TIMEFRAMES.map(tf => (
                            <button key={tf} onClick={() => setTimeframe(tf)} className={`px-2 py-1 rounded text-xs font-bold transition-all ${timeframe === tf ? 'text-indigo-600 bg-indigo-50 dark:text-indigo-400 dark:bg-indigo-900/30' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}>{tf}</button>
                        ))}
                    </div>
                    
                    <div className="relative ml-2 flex gap-1">
                        <button ref={indBtnRef} onClick={openIndMenu} className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800">
                            <Layers className="w-3.5 h-3.5" /> Indicators
                        </button>
                        <button ref={viewBtnRef} onClick={openViewMenu} className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800">
                            <Settings2 className="w-3.5 h-3.5" /> View
                        </button>
                    </div>
                    
                    <button onClick={onSaveTemplate} className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-indigo-500 transition-colors" title="Save Indicator Template"><Save className="w-3.5 h-3.5" /></button>
                </div>
                <div className="flex items-center gap-2 px-2 text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-800 rounded">
                    <LayoutTemplate className="w-3 h-3" />
                    <span>{visiblePaneCount} Win (Alt+[1-9])</span>
                </div>
            </div>

            {/* Indicator Menu */}
            {isIndicatorMenuOpen && createPortal(
                <>
                    <div className="fixed inset-0 z-[9998]" onClick={() => setIsIndicatorMenuOpen(false)}></div>
                    <div className="fixed z-[9999] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl w-64 max-h-[400px] flex flex-col animate-in fade-in zoom-in-95" style={indMenuPos} onClick={e => e.stopPropagation()}>
                        <div className="p-2 border-b border-slate-200 dark:border-slate-800 font-bold text-[10px] text-slate-500 uppercase">Library</div>
                        <div className="flex-1 overflow-y-auto custom-scrollbar p-1 h-64">
                            <TreeBrowser 
                                data={indicatorTreeData} 
                                onSelect={(n) => { 
                                    if(n.type==='item') {
                                        onAddIndicator(n.id);
                                    } 
                                }} 
                            />
                        </div>
                    </div>
                </>, 
                document.body
            )}

            {/* View Settings Menu */}
            {isViewMenuOpen && createPortal(
                <>
                    <div className="fixed inset-0 z-[9998]" onClick={() => setIsViewMenuOpen(false)}></div>
                    <div className="fixed z-[9999] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl w-60 p-3 flex flex-col gap-3 animate-in fade-in zoom-in-95" style={viewMenuPos} onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 pb-2">
                            <span className="font-bold text-[10px] text-slate-500 uppercase">Chart View Settings</span>
                            <button onClick={() => setIsViewMenuOpen(false)}><X className="w-3.5 h-3.5 text-slate-400" /></button>
                        </div>
                        
                        <div className="flex items-center justify-between">
                            <label className="text-xs text-slate-700 dark:text-slate-300">Right Blank Space</label>
                            <div className="flex items-center gap-1">
                                <input 
                                    type="number" 
                                    min="0" 
                                    max="100"
                                    value={rightOffset}
                                    onChange={(e) => setRightOffset(Math.max(0, parseInt(e.target.value) || 0))}
                                    className="w-12 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-0.5 text-xs text-center outline-none focus:border-indigo-500"
                                />
                                <span className="text-[10px] text-slate-400">bars</span>
                            </div>
                        </div>
                    </div>
                </>, 
                document.body
            )}
        </>
    );
};
