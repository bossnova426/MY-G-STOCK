
import React, { useEffect, useRef } from 'react';
import { 
    createChart, IChartApi, ISeriesApi, Time, 
    CandlestickSeries, HistogramSeries, LineSeries, AreaSeries, 
    LogicalRange, LineWidth, SeriesMarker, ColorType 
} from 'lightweight-charts';
import { StockDataPoint, AppSettings } from '../../../../../types';
import { IndicatorDefinition } from '../../../../../indicators/types';
import { getChartOptions, getSmartPrecision } from '../chartHelpers';

interface ChartPaneProps {
    paneIndex: number;
    isActive: boolean;
    isMaximized: boolean;
    height: number;
    width: number;
    
    // Data
    mainData: StockDataPoint[]; // Full dataset
    chartMode: 'candles' | 'line' | 'area' | 'bars';
    symbol: string;
    
    // Indicators for this pane
    indicators: {
        instanceId: string;
        def: IndicatorDefinition;
        config: any;
    }[];
    
    // Comparisons (Main pane only)
    comparisons?: { symbol: string, data: StockDataPoint[] }[];
    
    settings?: AppSettings;
    isLogScale: boolean;
    rightOffset: number;
    showTimeScale: boolean;
    
    // Callbacks
    onChartReady: (paneIndex: number, api: IChartApi | null) => void;
    onHover: (time: string | null) => void;
    syncRange: LogicalRange | null;
    setSyncRange: (range: LogicalRange | null) => void;
    syncCrosshair: { time: Time; x: number } | null;
}

export const ChartPane: React.FC<ChartPaneProps> = ({
    paneIndex, isActive, isMaximized, height, width,
    mainData, chartMode, symbol,
    indicators, comparisons,
    settings, isLogScale, rightOffset, showTimeScale,
    onChartReady, onHover, syncRange, setSyncRange, syncCrosshair
}) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const seriesRef = useRef<Map<string, ISeriesApi<any>>>(new Map());
    // Track if main data is loaded to prevent sync errors
    const hasDataRef = useRef<boolean>(false);

    // 1. Initialize Chart
    useEffect(() => {
        if (!containerRef.current) return;

        const lastPrice = mainData.length > 0 ? (mainData[mainData.length - 1]?.close || 100) : 100;
        const opts = getChartOptions(containerRef.current, settings, symbol, isLogScale, paneIndex === 0, lastPrice, rightOffset, showTimeScale);
        
        // Ensure height/width matches props
        opts.width = width;
        opts.height = height;

        const chart = createChart(containerRef.current, opts);
        chartRef.current = chart;
        onChartReady(paneIndex, chart);

        // Subscriptions
        chart.timeScale().subscribeVisibleLogicalRangeChange((range) => {
            if (range) setSyncRange(range);
        });

        chart.subscribeCrosshairMove((param) => {
            if (param.time) {
                onHover(param.time as string);
            } else {
                onHover(null);
            }
        });

        // Anchor Series (Hidden, for sync)
        const anchorSeries = chart.addSeries(AreaSeries, {
            topColor: 'rgba(0,0,0,0)',
            bottomColor: 'rgba(0,0,0,0)',
            lineColor: 'rgba(0,0,0,0)',
            lineWidth: 1, // Must be > 0 to exist logic-wise usually, but we want hidden
            priceScaleId: 'left',
            visible: true 
        });
        seriesRef.current.set('anchor', anchorSeries);

        return () => {
            chart.remove();
            chartRef.current = null;
            // CRITICAL: Clear series references because they are bound to the destroyed chart instance.
            seriesRef.current.clear();
            hasDataRef.current = false;
            onChartReady(paneIndex, null);
        };
    }, [paneIndex, chartMode, isLogScale, settings?.theme]); // Re-create on major config changes

    // 2. Handle Resizing & Options Updates
    useEffect(() => {
        if (!chartRef.current) return;
        chartRef.current.applyOptions({
            width,
            height,
            timeScale: { 
                rightOffset,
                visible: showTimeScale
            },
            layout: {
                textColor: settings?.theme === 'dark' ? '#94a3b8' : '#334155',
                background: { color: settings?.theme === 'dark' ? '#020617' : '#ffffff', type: ColorType.Solid }
            },
            grid: {
                vertLines: { color: settings?.theme === 'dark' ? '#1e293b' : '#f1f5f9' },
                horzLines: { color: settings?.theme === 'dark' ? '#1e293b' : '#f1f5f9' }
            }
        });
    }, [width, height, rightOffset, showTimeScale, settings?.theme]);

    // 3. Sync Logic (External Trigger)
    useEffect(() => {
        if (!chartRef.current || !syncRange) return;
        
        const currentRange = chartRef.current.timeScale().getVisibleLogicalRange();
        
        // Epsilon check to prevent infinite loops / fighting during scroll
        // When user drags, `subscribeVisibleLogicalRangeChange` updates state -> re-render -> this effect.
        // If we strictly enforce equality, tiny floating point differences might reset the inertia.
        const EPSILON = 0.05;
        
        if (!currentRange || 
            Math.abs(currentRange.from - syncRange.from) > EPSILON || 
            Math.abs(currentRange.to - syncRange.to) > EPSILON) {
            chartRef.current.timeScale().setVisibleLogicalRange(syncRange);
        }
    }, [syncRange]);

    useEffect(() => {
        if (!chartRef.current) return;
        // Crosshair Sync
        // Only attempt to set crosshair if we actually have data loaded, otherwise library throws "Value is null"
        if (syncCrosshair && hasDataRef.current) {
            const anchor = seriesRef.current.get('anchor') || seriesRef.current.get('main');
            if (anchor) {
                try {
                    chartRef.current.setCrosshairPosition(0, syncCrosshair.time, anchor);
                } catch (e) {
                    // Ignore transient errors during sync when data is sparse
                }
            }
        } else {
            chartRef.current.clearCrosshairPosition();
        }
    }, [syncCrosshair]);

    // 4. Data Rendering
    useEffect(() => {
        if (!chartRef.current) return;
        
        const chart = chartRef.current;
        const seriesMap = seriesRef.current;
        const upColor = settings?.modules.chart.upColor || '#10b981';
        const downColor = settings?.modules.chart.downColor || '#f43f5e';

        // A. Anchor Data - STRICT FILTERING
        const anchorSeries = seriesMap.get('anchor');
        if (anchorSeries && mainData.length > 0) {
            const anchorData = mainData
                .filter(d => d && d.date && d.close !== undefined && d.close !== null && !isNaN(Number(d.close)))
                .map(d => ({ time: d.date as Time, value: Number(d.close) }));
            
            if (anchorData.length > 0) {
                anchorSeries.setData(anchorData);
                hasDataRef.current = true;
            } else {
                hasDataRef.current = false;
            }
        } else {
            hasDataRef.current = false;
        }

        // B. Main Series (Pane 0 only)
        if (paneIndex === 0) {
            let mainSeries = seriesMap.get('main');
            if (!mainSeries) {
                const lastVal = mainData[mainData.length - 1]?.close || 100;
                const precision = getSmartPrecision(lastVal);
                const commonOpts = { 
                    priceFormat: { type: 'price' as const, precision, minMove: 1/Math.pow(10, precision) } 
                };
                
                if (chartMode === 'line') mainSeries = chart.addSeries(LineSeries, { color: '#3b82f6', lineWidth: 2, ...commonOpts });
                else if (chartMode === 'area') mainSeries = chart.addSeries(AreaSeries, { lineColor: '#3b82f6', topColor: '#3b82f655', bottomColor: '#3b82f600', ...commonOpts });
                else mainSeries = chart.addSeries(CandlestickSeries, { upColor, downColor, borderVisible: false, wickUpColor: upColor, wickDownColor: downColor, ...commonOpts });
                
                seriesMap.set('main', mainSeries);
            }

            if (mainData.length > 0) {
                const mappedData = mainData
                    .filter(d => {
                        if (!d || !d.date) return false;
                        // Strict filtering for OHLC to prevent "Value is null" crash
                        if (chartMode === 'candles') {
                            return (
                                d.open !== undefined && d.open !== null && !isNaN(Number(d.open)) &&
                                d.high !== undefined && d.high !== null && !isNaN(Number(d.high)) &&
                                d.low !== undefined && d.low !== null && !isNaN(Number(d.low)) &&
                                d.close !== undefined && d.close !== null && !isNaN(Number(d.close))
                            );
                        }
                        return d.close !== undefined && d.close !== null && !isNaN(Number(d.close));
                    })
                    .map(d => {
                        const base = { time: d.date as Time };
                        if (chartMode === 'line' || chartMode === 'area') return { ...base, value: Number(d.close) };
                        return { ...base, open: Number(d.open), high: Number(d.high), low: Number(d.low), close: Number(d.close) };
                    });
                
                if (mappedData.length > 0) {
                    mainSeries.setData(mappedData);
                }
            }

            // Comparisons
            if (comparisons) {
                comparisons.forEach((comp, idx) => {
                    let compSeries = seriesMap.get(`comp-${comp.symbol}`);
                    if (!compSeries) {
                        const colors = ['#f59e0b', '#8b5cf6', '#ec4899'];
                        compSeries = chart.addSeries(LineSeries, { 
                            color: colors[idx % colors.length], 
                            lineWidth: 2, 
                            priceScaleId: 'right', 
                            title: comp.symbol 
                        });
                        seriesMap.set(`comp-${comp.symbol}`, compSeries);
                    }
                    if (comp.data && comp.data.length > 0) {
                        const compData = comp.data
                            .filter(d => d && d.date && d.close != null && !isNaN(Number(d.close)))
                            .map(d => ({ time: d.date as Time, value: Number(d.close) }));
                        
                        if (compData.length > 0) {
                            compSeries.setData(compData);
                        }
                    }
                });
                
                // Cleanup Removed Comparisons could go here
            }
        }

        // C. Indicators
        // 1. Identify active series keys for this pane
        const activeSeriesKeys = new Set<string>(['main', 'anchor']);
        if (paneIndex === 0 && comparisons) comparisons.forEach(c => activeSeriesKeys.add(`comp-${c.symbol}`));

        indicators.forEach(({ instanceId, def, config }) => {
            const outputDefs = (def as any).outputDefs || [{ key: 'main', label: 'Main', type: 'line', defaultStyle: def.defaultStyle }];
            
            outputDefs.forEach((out: any) => {
                const seriesKey = `${instanceId}-${out.key}`;
                activeSeriesKeys.add(seriesKey);
                
                let series = seriesMap.get(seriesKey);
                if (!series) {
                    const styleToUse = (config?.styles && config.styles[out.key]) || out.defaultStyle || { color: config?.color || '#fbbf24', lineWidth: config?.lineWidth || 2 };
                    const commonOpts = { 
                        color: styleToUse.color, 
                        lineWidth: (styleToUse.lineWidth || 2) as LineWidth, 
                        priceScaleId: 'right', 
                        visible: styleToUse.visible !== false,
                        lastValueVisible: !!styleToUse.showLabel,
                        priceLineVisible: !!styleToUse.showLabel,
                        title: def.shortName // Helps with tooltips
                    };
                    
                    if (out.type === 'histogram') {
                        series = chart.addSeries(HistogramSeries, { ...commonOpts, priceFormat: { type: 'volume' } });
                    } else {
                        series = chart.addSeries(LineSeries, commonOpts);
                    }
                    seriesMap.set(seriesKey, series);
                } else {
                    // Update Styles Dynamically
                    const styleToUse = (config?.styles && config.styles[out.key]) || out.defaultStyle;
                    if (styleToUse) {
                        series.applyOptions({
                            color: styleToUse.color,
                            lineWidth: (styleToUse.lineWidth || 2) as LineWidth,
                            visible: styleToUse.visible !== false,
                            lastValueVisible: !!styleToUse.showLabel,
                            priceLineVisible: !!styleToUse.showLabel
                        });
                    }
                }

                // Data Map
                const dataKey = def.outputDefs ? `${instanceId}-${out.key}` : (def.id === 'vol' ? `${instanceId}-vol` : `${instanceId}-main`);
                
                const seriesData = mainData
                    .filter(d => d && d.date && d[dataKey] != null && !isNaN(Number(d[dataKey])))
                    .map(d => {
                        const pt: any = { time: d.date as Time, value: Number(d[dataKey]) };
                        if (out.type === 'histogram' && def.id === 'vol') {
                            pt.color = (d.close >= d.open) ? upColor : downColor;
                        }
                        return pt;
                    });
                
                if (seriesData.length > 0) {
                    series.setData(seriesData);
                }

                // Markers
                const markerKey = `${instanceId}-markers`;
                const markers: SeriesMarker<Time>[] = [];
                mainData.forEach(d => {
                    if (d && d.date && d[markerKey] && Array.isArray(d[markerKey])) {
                        markers.push(...d[markerKey]);
                    }
                });
                
                if (markers.length > 0) {
                    const s = series as any;
                    if (typeof s.setMarkers === 'function') {
                        s.setMarkers(markers);
                    }
                }
            });
        });

        // D. Cleanup Orphans
        const keysToRemove: string[] = [];
        seriesMap.forEach((_, key) => {
            if (!activeSeriesKeys.has(key)) {
                const s = seriesMap.get(key);
                if (s) {
                    chart.removeSeries(s);
                    keysToRemove.push(key);
                }
            }
        });
        keysToRemove.forEach(k => seriesMap.delete(k));

    }, [mainData, indicators, comparisons, chartMode, settings?.modules.chart.upColor, settings?.modules.chart.downColor]);

    return (
        <div 
            ref={containerRef} 
            className={`relative w-full border-b border-slate-200 dark:border-slate-800 transition-all ${isActive ? 'ring-1 ring-inset ring-indigo-500/30 z-10' : ''}`}
            style={{ height: height }}
        />
    );
};
