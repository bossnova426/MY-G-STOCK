
import React, { useEffect } from 'react';
import { StockDataPoint, AppSettings, CustomColumn, WidgetCommand } from '../../../../types';
import { IndicatorDefinition } from '../../../../indicators/types';
import { IndicatorSettingsModal } from './IndicatorSettingsModal';
import { ChartToolbar } from './ChartToolbar';
import { ChartLegend } from './ChartLegend';
import { Loader2 } from 'lucide-react';
import { eventBus, EVENTS } from '../../../../services/eventBus';

// Refactored Imports
import { useStockChartState } from './hooks/useStockChartState';
import { useChartData } from './useChartData';
import { ChartPane } from './components/ChartPane';
import { useChartSync } from './hooks/useChartSync';
import { useIndicatorActions } from './hooks/useIndicatorActions';
import { useIndicatorTree } from './hooks/useIndicatorTree';
import { useIndicatorSettings } from './hooks/useIndicatorSettings';

interface StockChartProps {
  data: StockDataPoint[];
  symbol?: string; 
  settings?: AppSettings;
  overrideColor?: string;
  sharedHoverLabel?: string | null;
  onHover?: (label: string | null) => void;
  customColumns?: CustomColumn[];
  command?: WidgetCommand | null;
}

export const StockChart: React.FC<StockChartProps> = ({ 
  data, 
  symbol = 'NVDA',
  settings, 
  onHover,
  command
}) => {
  // --- 1. State Management (Hook) ---
  const state = useStockChartState();
  const { 
      chartMode, timeframe, visiblePaneCount, activePane, maximizedPane, 
      activeIndicators, indicatorConfigs, indicatorMap, comparisons,
      setIndicatorMap, setIndicatorConfigs, setActiveIndicators, setVisiblePaneCount, 
      setActivePane, setMaximizedPane, setComparisons
  } = state;

  // --- 2. Data Management (Hook) ---
  const { 
      calculatedData, 
      compareData, 
      calculatingIndicators, 
      definitions, 
      setDefinitions, 
      isLoading 
  } = useChartData(data, symbol, timeframe, activeIndicators, comparisons, indicatorConfigs);

  // --- 3. Actions Hook ---
  const { handleAddIndicator, handleRemoveIndicator } = useIndicatorActions({
      activeIndicators, indicatorConfigs, indicatorMap, maximizedPane, definitions,
      setDefinitions, setIndicatorConfigs, setActiveIndicators, setIndicatorMap, setVisiblePaneCount, setMaximizedPane
  });

  // --- 4. Chart Sync Hook ---
  const { 
      chartsRef, syncRange, setSyncRange, syncCrosshair, containerHeight, containerRef, 
      handleChartReady, handleSyncHover 
  } = useChartSync(onHover);

  // --- 5. Settings & Menus ---
  const indicatorTreeData = useIndicatorTree();
  const settingsHook = useIndicatorSettings(indicatorConfigs, definitions, setDefinitions);

  // --- 6. Event Listeners ---
  useEffect(() => {
      const unsubAdd = eventBus.on(EVENTS.INDICATOR_ADDED, (payload: any) => {
          const indId = typeof payload === 'string' ? payload : payload?.id;
          if (indId) handleAddIndicator(indId);
      });
      return () => { unsubAdd(); };
  }, [handleAddIndicator]);

  useEffect(() => {
      if (command && command.type === 'ADD_INDICATOR') {
          handleAddIndicator(command.payload);
      }
  }, [command, handleAddIndicator]);

  useEffect(() => {
      // Auto-expand visible panes based on indicators
      const currentPanes = Object.values(indicatorMap) as number[];
      if (currentPanes.length > 0) {
          const maxPane = Math.max(...currentPanes);
          if (maxPane + 1 > visiblePaneCount) {
              setVisiblePaneCount(maxPane + 1);
          }
      }
  }, [indicatorMap, visiblePaneCount, setVisiblePaneCount]);

  // --- 7. Helper: Prepare Pane Props ---
  const getPaneIndicators = (paneIdx: number) => {
      return activeIndicators
          .filter(id => indicatorMap[id] === paneIdx)
          .map(id => {
              const config = indicatorConfigs[id];
              const defId = config?.defId || id.split('-')[0];
              const def = definitions.get(defId); // Definitions should be loaded by now
              return { instanceId: id, def: def as IndicatorDefinition, config };
          })
          .filter(item => !!item.def);
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden bg-white dark:bg-slate-950 select-none">
      <ChartToolbar 
          symbol={symbol}
          tooltipSymbol={syncCrosshair ? `${syncCrosshair.time}` : undefined} // Simplified tooltip
          timeframe={timeframe}
          setTimeframe={state.setTimeframe}
          visiblePaneCount={visiblePaneCount}
          rightOffset={state.rightOffset}
          setRightOffset={state.setRightOffset}
          onAddComparison={() => { const s = prompt("Symbol:"); if(s) setComparisons(p => [...p, s.toUpperCase()]) }}
          onSaveTemplate={() => alert('Template Saved')}
          onAddIndicator={(defId) => handleAddIndicator(defId)}
          indicatorTreeData={indicatorTreeData}
      />

      <div className="flex-1 flex flex-row min-h-0 relative" ref={containerRef}>
          <div className="flex-1 relative flex flex-col min-w-0 bg-slate-50 dark:bg-slate-950">
              
              {/* Loading Overlay */}
              {isLoading && (
                  <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-50/50 dark:bg-slate-950/50 backdrop-blur-sm">
                      <div className="flex flex-col items-center gap-2">
                          <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                          <span className="text-xs font-bold text-slate-500">Loading Data...</span>
                      </div>
                  </div>
              )}

              {/* Chart Grid Layout */}
              <div className="flex flex-col w-full h-full relative">
                  {Array.from({ length: visiblePaneCount }).map((_, i) => {
                      if (maximizedPane !== null && maximizedPane !== i) return null;
                      
                      const isMain = i === 0;
                      // Dynamic Height Calculation
                      const totalFlex = maximizedPane !== null ? 1 : 3 + (visiblePaneCount - 1); // Main is flex 3
                      const myFlex = isMain ? 3 : 1;
                      const height = maximizedPane !== null 
                          ? containerHeight 
                          : (containerHeight * myFlex) / totalFlex;

                      return (
                          <div 
                            key={i}
                            className="relative border-b last:border-b-0 border-slate-200 dark:border-slate-800"
                            style={{ height }}
                            onClick={() => setActivePane(i)}
                          >
                              <ChartLegend 
                                  paneIndex={i}
                                  visiblePaneCount={visiblePaneCount}
                                  activePane={activePane}
                                  setActivePane={setActivePane}
                                  maximizedPane={maximizedPane}
                                  setMaximizedPane={setMaximizedPane}
                                  activeIndicators={activeIndicators}
                                  indicatorMap={indicatorMap}
                                  indicatorConfigs={indicatorConfigs}
                                  definitions={definitions}
                                  calculatingIndicators={calculatingIndicators}
                                  comparisons={comparisons}
                                  onToggleVisibility={(id) => setIndicatorConfigs(p => ({ ...p, [id]: { ...p[id], visible: !p[id].visible } }))}
                                  onMovePane={(id, dir) => {
                                      const cur = indicatorMap[id] ?? 0;
                                      let n = dir === 'up' ? cur - 1 : cur + 1;
                                      if (n < 0) n = 0; if (n >= visiblePaneCount) n = visiblePaneCount - 1;
                                      setIndicatorMap(p => ({ ...p, [id]: n }));
                                  }}
                                  onSettings={settingsHook.openSettings}
                                  onRemove={handleRemoveIndicator}
                                  onRemoveComparison={(sym) => setComparisons(p => p.filter(x => x !== sym))}
                              />
                              
                              <ChartPane 
                                  paneIndex={i}
                                  isActive={activePane === i}
                                  isMaximized={maximizedPane === i}
                                  height={height}
                                  width={containerRef.current?.clientWidth || 800}
                                  mainData={calculatedData}
                                  chartMode={chartMode}
                                  symbol={symbol}
                                  indicators={getPaneIndicators(i)}
                                  comparisons={i === 0 ? comparisons.map(s => ({ symbol: s, data: compareData[s] || [] })) : []}
                                  settings={settings}
                                  isLogScale={state.isLogScale}
                                  rightOffset={state.rightOffset}
                                  showTimeScale={maximizedPane !== null ? true : (i === visiblePaneCount - 1)}
                                  onChartReady={handleChartReady}
                                  onHover={handleSyncHover}
                                  syncRange={syncRange}
                                  setSyncRange={setSyncRange}
                                  syncCrosshair={syncCrosshair}
                              />
                          </div>
                      );
                  })}
              </div>
          </div>

          {/* Settings Modal */}
          {settingsHook.isOpen && settingsHook.editingId && settingsHook.editingDef && (
              <IndicatorSettingsModal 
                  isOpen={settingsHook.isOpen}
                  onClose={settingsHook.closeSettings}
                  definition={settingsHook.editingDef}
                  currentParams={indicatorConfigs[settingsHook.editingId]?.params || {}}
                  currentStyle={indicatorConfigs[settingsHook.editingId]?.styles || {}}
                  onUpdate={(params, style) => {
                      // Real-time update
                      setIndicatorConfigs(prev => ({
                          ...prev,
                          [settingsHook.editingId!]: { ...prev[settingsHook.editingId!], styles: style, params: params }
                      }));
                  }}
                  onSave={(params, style) => {
                      setIndicatorConfigs(prev => ({
                          ...prev,
                          [settingsHook.editingId!]: { ...prev[settingsHook.editingId!], styles: style, params: params }
                      }));
                      settingsHook.closeSettings();
                  }}
              />
          )}
      </div>
    </div>
  );
};
