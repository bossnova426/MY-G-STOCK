
import React, { useMemo } from 'react';
import { StockProfile, FundamentalData, AppSettings } from '../../../../../types';
import { ArrowUp, ArrowDown, Activity, Layers, Tag } from 'lucide-react';
import { I18N } from '../../../../../constants';

interface QuoteDetailProps {
  profile: StockProfile;
  fundamentals: FundamentalData | null;
  settings?: AppSettings;
}

// Helper to format large numbers
const formatVol = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(2) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(2) + 'K';
    return num.toString();
};

export const QuoteDetail: React.FC<QuoteDetailProps> = ({ profile, fundamentals, settings }) => {
  const lang = settings?.language || 'en';
  const t = I18N[lang];

  // Mock Level 2 Data generation based on current price
  const { orderBook, stats, ticks } = useMemo(() => {
    const p = profile.price;
    const spread = p * 0.001; // 0.1% spread
    
    // Generate Asks (Sell) - Price increasing
    const asks = Array.from({length: 5}, (_, i) => ({
        price: p + (spread * (5 - i)), 
        vol: Math.floor(Math.random() * 500) + 10
    }));

    // Generate Bids (Buy) - Price decreasing
    const bids = Array.from({length: 5}, (_, i) => ({
        price: p - (spread * (i + 1)), 
        vol: Math.floor(Math.random() * 500) + 10
    }));

    // Detailed Stats (Mocking values not in basic profile)
    const open = p * (1 + (Math.random() * 0.02 - 0.01));
    const prevClose = p - profile.change;
    const high = Math.max(open, p * 1.01);
    const low = Math.min(open, p * 0.99);
    
    const stats = {
        open,
        high,
        low,
        prevClose,
        volume: Math.floor(Math.random() * 10000000) + 500000,
        amount: (Math.floor(Math.random() * 10000000) + 500000) * p,
        turnover: (Math.random() * 5).toFixed(2) + '%',
        pe: fundamentals?.peRatio || '-',
        amplitude: ((high - low) / prevClose * 100).toFixed(2) + '%',
        innerDisk: Math.floor(Math.random() * 4000), // Mock Inner (Sell)
        outerDisk: Math.floor(Math.random() * 6000), // Mock Outer (Buy)
    };

    return { orderBook: { asks, bids }, stats, ticks: [] };
  }, [profile, fundamentals]);

  const isUp = profile.change >= 0;
  const colorClass = isUp ? 'text-emerald-500' : 'text-rose-500';
  const bgClass = isUp ? 'bg-emerald-500' : 'bg-rose-500';

  return (
    <div className="h-full flex flex-col bg-slate-50 dark:bg-slate-900 overflow-hidden text-xs font-mono select-none">
      
      {/* 1. Header Area */}
      <div className="p-3 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-950">
          <div>
              <div className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  {profile.symbol} 
                  <span className="text-[10px] font-normal text-slate-500 bg-slate-100 dark:bg-slate-800 px-1 rounded">{profile.name}</span>
              </div>
              <div className="flex items-end gap-2 mt-1">
                  <span className={`text-2xl font-bold leading-none ${colorClass}`}>
                      {profile.price.toFixed(2)}
                  </span>
                  <div className={`flex flex-col text-[10px] font-bold leading-tight ${colorClass}`}>
                      <span>{profile.change > 0 ? '+' : ''}{profile.change.toFixed(2)}</span>
                      <span>{profile.change > 0 ? '+' : ''}{profile.changePercent.toFixed(2)}%</span>
                  </div>
              </div>
          </div>
          <div className="flex flex-col items-end gap-1">
               <div className="text-[10px] text-slate-500 flex items-center gap-1">
                   <span>{t.inflow}</span>
                   <span className="text-emerald-500">+12.5M</span>
               </div>
               <div className={`w-2 h-2 rounded-full ${bgClass} animate-pulse`}></div>
          </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar">
          
          {/* 2. Order Book (5-Level) */}
          <div className="flex border-b border-slate-200 dark:border-slate-800">
              {/* Left Side: Stats/Ratios (Mocking the 'Wei Bi' 'Wei Cha' from image) */}
              <div className="w-1/3 border-r border-slate-200 dark:border-slate-800 p-2 flex flex-col justify-center space-y-2">
                  <div>
                      <div className="text-[9px] text-slate-500 mb-0.5">Order Ratio</div>
                      <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden flex">
                          <div className="h-full bg-rose-500 w-[40%]"></div>
                          <div className="h-full bg-emerald-500 w-[60%]"></div>
                      </div>
                      <div className="flex justify-between text-[9px] mt-0.5">
                         <span className="text-rose-500">-12%</span>
                         <span className="text-emerald-500">+34%</span>
                      </div>
                  </div>
                  <div>
                      <div className="text-[9px] text-slate-500 mb-0.5">Big Orders</div>
                      <div className="text-rose-500 font-bold">-4.2M</div>
                  </div>
              </div>

              {/* Right Side: Bid/Ask List */}
              <div className="w-2/3 bg-slate-50 dark:bg-slate-900/50">
                  {/* Asks (Sell 5 -> Sell 1) */}
                  {orderBook.asks.map((ask, i) => (
                      <div key={`ask-${i}`} className="flex justify-between items-center px-2 py-0.5 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer group">
                          <span className="text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300">S{5-i}</span>
                          <span className={`${ask.price > stats.prevClose ? 'text-rose-500' : 'text-emerald-500'}`}>{ask.price.toFixed(2)}</span>
                          <span className="text-amber-500">{ask.vol}</span>
                      </div>
                  ))}
                  
                  <div className="border-t border-b border-slate-200 dark:border-slate-800 my-0.5"></div>

                  {/* Bids (Buy 1 -> Buy 5) */}
                  {orderBook.bids.map((bid, i) => (
                      <div key={`bid-${i}`} className="flex justify-between items-center px-2 py-0.5 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer group">
                          <span className="text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300">B{i+1}</span>
                          <span className={`${bid.price > stats.prevClose ? 'text-rose-500' : 'text-emerald-500'}`}>{bid.price.toFixed(2)}</span>
                          <span className="text-blue-500">{bid.vol}</span>
                      </div>
                  ))}
              </div>
          </div>

          {/* 3. Detailed Stats Grid */}
          <div className="grid grid-cols-2 gap-px bg-slate-200 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-800">
              {[
                  { label: t.open, val: stats.open.toFixed(2), color: stats.open > stats.prevClose ? 'text-rose-500' : 'text-emerald-500' },
                  { label: t.prev, val: stats.prevClose.toFixed(2), color: 'text-slate-300' },
                  { label: t.high, val: stats.high.toFixed(2), color: 'text-rose-500' },
                  { label: t.low, val: stats.low.toFixed(2), color: 'text-emerald-500' },
                  { label: t.vol, val: formatVol(stats.volume), color: 'text-amber-400' },
                  { label: t.amt, val: formatVol(stats.amount), color: 'text-blue-400' },
                  { label: t.turnover, val: stats.turnover, color: 'text-slate-300' },
                  { label: 'Amp', val: stats.amplitude, color: 'text-slate-300' },
                  { label: 'Inner', val: stats.innerDisk, color: 'text-emerald-500' },
                  { label: 'Outer', val: stats.outerDisk, color: 'text-rose-500' },
              ].map((item, i) => (
                  <div key={i} className="bg-white dark:bg-slate-900 px-2 py-1.5 flex justify-between items-center">
                      <span className="text-slate-500">{item.label}</span>
                      <span className={`font-bold ${item.color}`}>{item.val}</span>
                  </div>
              ))}
          </div>

          {/* 4. Industry / Concept Tags */}
          <div className="p-3 space-y-2">
              <div className="flex items-start gap-2">
                  <div className="mt-0.5 min-w-[30px] text-[10px] text-slate-500 uppercase font-bold">Ind</div>
                  <div className="flex flex-wrap gap-1">
                      <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-rose-500 border border-slate-200 dark:border-slate-700 rounded text-[10px]">{profile.sector}</span>
                      {profile.sector === 'Technology' && <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-rose-500 border border-slate-200 dark:border-slate-700 rounded text-[10px]">Semiconductors</span>}
                  </div>
              </div>
              <div className="flex items-start gap-2">
                  <div className="mt-0.5 min-w-[30px] text-[10px] text-slate-500 uppercase font-bold">Cpt</div>
                  <div className="flex flex-wrap gap-1">
                      <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded text-[10px]">AI Chips</span>
                      <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded text-[10px]">Cloud Computing</span>
                      <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded text-[10px]">Big Data</span>
                  </div>
              </div>
          </div>
          
      </div>
    </div>
  );
};
