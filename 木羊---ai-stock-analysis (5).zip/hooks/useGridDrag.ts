
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Widget, Workspace } from '../types';

const GRID_COLS = 12;
const ROW_HEIGHT = 50;

interface UseGridDragProps {
    workspaces: Workspace[];
    setWorkspaces: (ws: Workspace[]) => void;
    activeWorkspaceId: string;
}

export const useGridDrag = ({ workspaces, setWorkspaces, activeWorkspaceId }: UseGridDragProps) => {
    const gridRef = useRef<HTMLDivElement>(null);

    // Drag State
    const [dragState, setDragState] = useState<{
        active: boolean,
        widgetId: string | null,
        type: 'move' | 'resize',
        startX: number,
        startY: number,
        location: 'grid' | 'sidebar' | 'right' | 'bottom',
        initialLayout: { x: number, y: number, w: number, h: number },
        ghostLayout: { x: number, y: number, w: number, h: number } | null
    }>({
        active: false,
        widgetId: null,
        type: 'move',
        startX: 0,
        startY: 0,
        location: 'grid',
        initialLayout: { x: 0, y: 0, w: 0, h: 0 },
        ghostLayout: null
    });

    useEffect(() => {
        if (!dragState.active) return;

        const handleMouseMove = (e: MouseEvent) => {
            if (dragState.location === 'grid') {
                if (!gridRef.current) return;
                const gridRect = gridRef.current.getBoundingClientRect();
                const colWidth = gridRect.width / GRID_COLS;
                const deltaGridX = Math.round((e.clientX - dragState.startX) / colWidth);
                const deltaGridY = Math.round((e.clientY - dragState.startY) / ROW_HEIGHT);

                let newGhost = { ...dragState.initialLayout };

                if (dragState.type === 'move') {
                    newGhost.x = Math.max(0, Math.min(GRID_COLS - newGhost.w, dragState.initialLayout.x + deltaGridX));
                    newGhost.y = Math.max(0, dragState.initialLayout.y + deltaGridY);
                } else {
                    newGhost.w = Math.max(2, Math.min(GRID_COLS - newGhost.x, dragState.initialLayout.w + deltaGridX));
                    newGhost.h = Math.max(2, dragState.initialLayout.h + deltaGridY);
                }
                setDragState(prev => ({ ...prev, ghostLayout: newGhost }));
            } else if (dragState.location === 'bottom') {
                const deltaX = e.clientX - dragState.startX;
                const deltaW = Math.round(deltaX / 25);
                let newGhost = { ...dragState.initialLayout };
                newGhost.w = Math.max(8, dragState.initialLayout.w + deltaW);
                setDragState(prev => ({ ...prev, ghostLayout: newGhost }));
            } else {
                const deltaY = e.clientY - dragState.startY;
                const deltaH = Math.round(deltaY / 20);
                let newGhost = { ...dragState.initialLayout };
                newGhost.h = Math.max(4, dragState.initialLayout.h + deltaH);
                setDragState(prev => ({ ...prev, ghostLayout: newGhost }));
            }
        };

        const handleMouseUp = () => {
            if (dragState.active && dragState.widgetId && dragState.ghostLayout) {
                const updatedWorkspaces = workspaces.map(w => {
                    if (w.id !== activeWorkspaceId) return w;

                    const updateFn = (wd: Widget) => wd.id === dragState.widgetId ? { ...wd, layout: dragState.ghostLayout! } : wd;

                    return {
                        ...w,
                        widgets: w.widgets.map(updateFn),
                        sidebarWidgets: w.sidebarWidgets?.map(updateFn),
                        rightWidgets: w.rightWidgets?.map(updateFn),
                        bottomWidgets: w.bottomWidgets?.map(updateFn)
                    };
                });

                setWorkspaces(updatedWorkspaces);
                localStorage.setItem('gq_workspaces', JSON.stringify(updatedWorkspaces));
            }
            setDragState({
                active: false,
                widgetId: null,
                type: 'move',
                startX: 0,
                startY: 0,
                location: 'grid',
                initialLayout: { x: 0, y: 0, w: 0, h: 0 },
                ghostLayout: null
            });
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [dragState, activeWorkspaceId, workspaces, setWorkspaces]);

    const handleDragStart = useCallback((widgetId: string, layout: any, location: any) => (e: React.MouseEvent, type: 'move' | 'resize') => {
        e.preventDefault();
        setDragState({
            active: true,
            widgetId,
            type,
            startX: e.clientX,
            startY: e.clientY,
            location,
            initialLayout: { ...layout },
            ghostLayout: { ...layout }
        });
    }, []);

    return {
        gridRef,
        dragState,
        handleDragStart
    };
};
