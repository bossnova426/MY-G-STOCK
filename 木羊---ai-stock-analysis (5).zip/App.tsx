
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Settings, Plus, Layout, 
  X, ChevronLeft, ChevronRight,
  PanelLeft, PanelRight, PanelBottom
} from 'lucide-react';

import { Header } from './components/Header';
import { TickerTape } from './components/TickerTape';
import { SettingsModal } from './components/SettingsModal';
import { KeyboardWizard, SearchResult } from './components/KeyboardWizard';
import { GridItem } from './components/GridItem';
import { getPluginList, REGISTERED_PLUGINS } from './pluginRegistry';
import { dataService } from './services/dataAdapter';
import { eventBus, EVENTS } from './services/eventBus'; 
import { 
  Widget, Workspace, AppSettings, StockProfile, 
  CustomWatchlist, NewsItem, 
  AnalysisResult, FundamentalData, 
  WidgetCommand, WidgetContext, StockDataPoint
} from './types';
import { 
  DEFAULT_SETTINGS, DEFAULT_WORKSPACES, MOCK_NEWS, INITIAL_STOCK 
} from './constants';
import { useGridDrag } from './hooks/useGridDrag';

const GRID_COLS = 12;
const ROW_HEIGHT = 50;

export default function App() {
    const [settings, setSettings] = useState<AppSettings>(() => {
        const saved = localStorage.getItem('gq_settings');
        return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    });

    const [workspaces, setWorkspaces] = useState<Workspace[]>(() => {
        const saved = localStorage.getItem('gq_workspaces');
        return saved ? JSON.parse(saved) : DEFAULT_WORKSPACES;
    });
    const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>(workspaces[0].id);

    // --- UI State ---
    const [leftWidth, setLeftWidth] = useState(() => Number(localStorage.getItem('gq_ui_left_w')) || 320);
    const [rightWidth, setRightWidth] = useState(() => Number(localStorage.getItem('gq_ui_right_w')) || 320);
    const [bottomHeight, setBottomHeight] = useState(() => Number(localStorage.getItem('gq_ui_bot_h')) || 240);
    const [isRightSidebarOpen, setIsRightSidebarOpen] = useState(false);

    const [watchlists, setWatchlists] = useState<CustomWatchlist[]>([]);
    const [activeSymbol, setActiveSymbol] = useState<string>(INITIAL_STOCK.symbol);
    const [activeProfile, setActiveProfile] = useState<StockProfile>(INITIAL_STOCK);
    const [chartData, setChartData] = useState<StockDataPoint[]>([]);
    const [marketNews, setMarketNews] = useState<NewsItem[]>(MOCK_NEWS);
    const [fundamentals, setFundamentals] = useState<FundamentalData | null>(null);
    const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
    const [analysisLoading, setAnalysisLoading] = useState(false);
    const [lastWidgetCommand, setLastWidgetCommand] = useState<WidgetCommand | null>(null);
    const [groupStates, setGroupStates] = useState<Record<string, { symbol: string, profile: StockProfile }>>({});

    const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState(false); 
    const [isRightPanelOpen, setIsRightPanelOpen] = useState(false); 
    const [isBottomPanelOpen, setIsBottomPanelOpen] = useState(false);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isWizardOpen, setIsWizardOpen] = useState(false);
    const [wizardChar, setWizardChar] = useState('');
    const [docsPluginId, setDocsPluginId] = useState<string | null>(null);
    const [draggedWorkspaceId, setDraggedWorkspaceId] = useState<string | null>(null);

    // --- Resizing Panels Logic ---
    const [resizingPanel, setResizingPanel] = useState<'left' | 'right' | 'bottom' | null>(null);
    const isResizing = resizingPanel !== null;

    const handlePanelResize = useCallback((e: MouseEvent) => {
        if (!resizingPanel) return;
        if (resizingPanel === 'left') {
            const newW = Math.max(150, Math.min(600, e.clientX));
            setLeftWidth(newW);
            localStorage.setItem('gq_ui_left_w', String(newW));
        } else if (resizingPanel === 'right') {
            const newW = Math.max(150, Math.min(600, window.innerWidth - e.clientX - (isRightSidebarOpen ? 250 : 40)));
            setRightWidth(newW);
            localStorage.setItem('gq_ui_right_w', String(newW));
        } else if (resizingPanel === 'bottom') {
            const newH = Math.max(100, Math.min(600, window.innerHeight - e.clientY - 28));
            setBottomHeight(newH);
            localStorage.setItem('gq_ui_bot_h', String(newH));
        }
    }, [resizingPanel, isRightSidebarOpen]);

    const stopPanelResize = useCallback(() => setResizingPanel(null), []);

    useEffect(() => {
        if (resizingPanel) {
            window.addEventListener('mousemove', handlePanelResize);
            window.addEventListener('mouseup', stopPanelResize);
        }
        return () => {
            window.removeEventListener('mousemove', handlePanelResize);
            window.removeEventListener('mouseup', stopPanelResize);
        };
    }, [resizingPanel, handlePanelResize, stopPanelResize]);

    // --- Drag & Drop / Widget Resizing Logic (Using Hook) ---
    const { gridRef, dragState, handleDragStart } = useGridDrag({
        workspaces,
        setWorkspaces,
        activeWorkspaceId
    });

    // --- Workspace Actions ---
    const handleAddWorkspace = () => {
        const newWs = { id: `ws-${Date.now()}`, name: `Workspace ${workspaces.length + 1}`, widgets: [] };
        const next = [...workspaces, newWs];
        setWorkspaces(next);
        setActiveWorkspaceId(newWs.id);
        localStorage.setItem('gq_workspaces', JSON.stringify(next));
    };

    const handleDeleteWorkspace = (id: string) => {
        if (workspaces.length <= 1) return;
        const next = workspaces.filter(w => w.id !== id);
        setWorkspaces(next);
        if (activeWorkspaceId === id) setActiveWorkspaceId(next[0].id);
        localStorage.setItem('gq_workspaces', JSON.stringify(next));
    };

    const handleWorkspaceDragStart = (e: React.DragEvent, id: string) => {
        setDraggedWorkspaceId(id);
        e.dataTransfer.effectAllowed = 'move';
    };

    const handleWorkspaceDragOver = (e: React.DragEvent, targetId: string) => {
        e.preventDefault();
        if (!draggedWorkspaceId || draggedWorkspaceId === targetId) return;
        const idx1 = workspaces.findIndex(w => w.id === draggedWorkspaceId);
        const idx2 = workspaces.findIndex(w => w.id === targetId);
        if (idx1 !== -1 && idx2 !== -1) {
            const next = [...workspaces];
            const [removed] = next.splice(idx1, 1);
            next.splice(idx2, 0, removed);
            setWorkspaces(next);
        }
    };

    // --- System Effects ---
    useEffect(() => {
        if (settings.theme === 'dark') document.documentElement.classList.add('dark');
        else document.documentElement.classList.remove('dark');
    }, [settings.theme]);

    // --- Global Keyboard Listener for Wizard ---
    useEffect(() => {
        const handleGlobalKeyDown = (e: KeyboardEvent) => {
            // Ignore if input/textarea focused
            const tagName = (e.target as HTMLElement).tagName;
            if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tagName)) return;
            // Ignore modifier keys
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            
            // Check for alphanumeric or specific triggers to open wizard
            // Allowing . for commands, and regular numbers/letters for symbols
            if (/^[a-zA-Z0-9.]$/.test(e.key)) {
                if (!isWizardOpen) {
                    setWizardChar(e.key);
                    setIsWizardOpen(true);
                }
            }
        };

        window.addEventListener('keydown', handleGlobalKeyDown);
        return () => window.removeEventListener('keydown', handleGlobalKeyDown);
    }, [isWizardOpen]);

    useEffect(() => {
        const fetchMarketData = async () => {
            try {
                const quote = await dataService.getQuote(activeSymbol);
                setActiveProfile(quote);
                setFundamentals(await dataService.getFundamentals(activeSymbol));
                setChartData(await dataService.getHistory(activeSymbol, 100));
                
                // IMPORTANT: Load Watchlists
                const lists = await dataService.getWatchlists();
                setWatchlists(lists);
            } catch (e) { console.error(e); }
        };
        dataService.configure(settings.data);
        fetchMarketData();
        const interval = setInterval(fetchMarketData, settings.modules.system.refreshRate * 1000);
        return () => clearInterval(interval);
    }, [activeSymbol, settings.modules.system.refreshRate, settings.data]);

    const createWidgetContext = (widget: Widget): WidgetContext => {
        const groupState = widget.linkGroup ? groupStates[widget.linkGroup] : null;
        const currentSym = groupState ? groupState.symbol : activeSymbol;
        const currentProf = groupState ? groupState.profile : activeProfile;
        return {
            symbol: currentSym,
            profile: currentProf,
            chartData, analysis, loadingAnalysis: analysisLoading,
            availableWatchlists: watchlists, news: marketNews, fundamentals,
            widgetConfig: widget.config, settings, sharedHoverLabel: null,
            setSharedHoverLabel: () => {}, customColumns: [],
            onAddCustomColumn: () => {}, onRemoveCustomColumn: () => {},
            onUpdateConfig: (cfg) => handleWidgetConfigChange(widget.id, cfg),
            onRefreshData: () => {},
            onSymbolSelect: (s) => widget.linkGroup ? handleGroupSymbolChange(widget.linkGroup, s) : setActiveSymbol(s),
            onAddStockToWatchlists: () => {}, onRemoveStockFromWatchlist: () => {},
            onAddWatchlist: () => {}, onRenameWatchlist: () => {}, onDeleteWatchlist: () => {},
            onUpdateWatchlist: () => {}, pluginRegistry: REGISTERED_PLUGINS,
            workspaces, activeWorkspaceId, onSwitchWorkspace: setActiveWorkspaceId,
            onAddWorkspace: (n) => {}, onRenameWorkspace: (i, n) => {}, onDeleteWorkspace: (i) => {},
            savedScreens: [], onSaveScreen: () => {}, onOpenScreener: () => {}, command: lastWidgetCommand,
            eventBus: eventBus // INJECTED EVENT BUS
        };
    };

    const handleWidgetConfigChange = (widgetId: string, newConfig: any) => {
        const updateFn = (wd: Widget) => wd.id === widgetId ? { ...wd, config: newConfig } : wd;
        setWorkspaces(workspaces.map(w => w.id === activeWorkspaceId ? { ...w, 
            widgets: w.widgets.map(updateFn),
            sidebarWidgets: w.sidebarWidgets?.map(updateFn),
            rightWidgets: w.rightWidgets?.map(updateFn),
            bottomWidgets: w.bottomWidgets?.map(updateFn)
        } : w));
    };

    const handleUpdateWidget = (widgetId: string, updates: Partial<Widget>) => {
        const updateFn = (wd: Widget) => wd.id === widgetId ? { ...wd, ...updates } : wd;
        setWorkspaces(workspaces.map(w => w.id === activeWorkspaceId ? { ...w, 
            widgets: w.widgets.map(updateFn),
            sidebarWidgets: w.sidebarWidgets?.map(updateFn),
            rightWidgets: w.rightWidgets?.map(updateFn),
            bottomWidgets: w.bottomWidgets?.map(updateFn)
        } : w));
    };

    const handleRemoveWidget = (id: string) => {
        setWorkspaces(workspaces.map(w => w.id === activeWorkspaceId ? { ...w, 
            widgets: w.widgets.filter(x => x.id !== id),
            sidebarWidgets: w.sidebarWidgets?.filter(x => x.id !== id),
            rightWidgets: w.rightWidgets?.filter(x => x.id !== id),
            bottomWidgets: w.bottomWidgets?.filter(x => x.id !== id)
        } : w));
    };

    const handleMoveLocation = (widgetId: string, target: 'grid' | 'sidebar' | 'right' | 'bottom') => {
        const workspace = workspaces.find(w => w.id === activeWorkspaceId);
        if (!workspace) return;
        let widgetToMove: Widget | undefined;
        let newGrid = [...workspace.widgets];
        let newSide = [...(workspace.sidebarWidgets || [])];
        let newRight = [...(workspace.rightWidgets || [])];
        let newBot = [...(workspace.bottomWidgets || [])];
        
        const finder = (arr: Widget[]) => {
            const idx = arr.findIndex(w => w.id === widgetId);
            if (idx !== -1) return arr.splice(idx, 1)[0];
        };
        widgetToMove = finder(newGrid) || finder(newSide) || finder(newRight) || finder(newBot);
        
        if (widgetToMove) {
            if (target === 'grid') { 
                widgetToMove.layout.x = 0; widgetToMove.layout.y = 0; 
                newGrid.push(widgetToMove); 
            } else if (target === 'sidebar') { 
                widgetToMove.layout.h = 15; newSide.push(widgetToMove); setIsLeftSidebarOpen(true); 
            } else if (target === 'right') { 
                widgetToMove.layout.h = 15; newRight.push(widgetToMove); setIsRightPanelOpen(true); 
            } else if (target === 'bottom') { 
                widgetToMove.layout.w = 16; newBot.push(widgetToMove); setIsBottomPanelOpen(true); 
            }
            setWorkspaces(workspaces.map(w => w.id === activeWorkspaceId ? { ...w, widgets: newGrid, sidebarWidgets: newSide, rightWidgets: newRight, bottomWidgets: newBot } : w));
        }
    };

    const handleAddWidget = (type: string) => {
        const plugin = REGISTERED_PLUGINS[type];
        if (!plugin) return;
        const newWidget: Widget = {
            id: `w-${Date.now()}`,
            type,
            title: plugin.title,
            layout: { x: 0, y: 0, w: plugin.defaultLayout.w, h: plugin.defaultLayout.h },
            config: plugin.defaultConfig || {}
        };
        setWorkspaces(workspaces.map(w => w.id === activeWorkspaceId ? { ...w, widgets: [newWidget, ...w.widgets] } : w));
    };

    const handleGroupSymbolChange = async (groupId: string, symbol: string) => {
        const quote = await dataService.getQuote(symbol);
        setGroupStates(prev => ({ ...prev, [groupId]: { symbol, profile: quote } }));
    };

    const handleWizardSelect = (item: SearchResult, groupId?: string) => {
        if (item.type === 'STOCK') {
            if (groupId) {
                handleGroupSymbolChange(groupId, item.id);
            } else {
                setActiveSymbol(item.id);
            }
        } else if (item.type === 'INDICATOR') {
            eventBus.emit(EVENTS.INDICATOR_ADDED, { id: item.id });
        }
    };

    const activeWorkspace = workspaces.find(w => w.id === activeWorkspaceId);
    const plugins = getPluginList();

    return (
        <div className={`flex flex-col h-screen w-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden font-sans`}>
            <Header />
            
            {/* Top Workspace Tab Bar */}
            <div className="mt-8 flex items-center bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 px-2 h-10 shrink-0 select-none">
                <div className="flex items-center gap-1 mr-4 border-r border-slate-200 dark:border-slate-800 pr-2">
                    <button onClick={() => setIsLeftSidebarOpen(!isLeftSidebarOpen)} className={`p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors ${isLeftSidebarOpen ? 'text-indigo-500' : 'text-slate-400'}`}><PanelLeft className="w-4 h-4" /></button>
                    <button onClick={() => setIsRightPanelOpen(!isRightPanelOpen)} className={`p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors ${isRightPanelOpen ? 'text-indigo-500' : 'text-slate-400'}`}><PanelRight className="w-4 h-4" /></button>
                    <button onClick={() => setIsBottomPanelOpen(!isBottomPanelOpen)} className={`p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors ${isBottomPanelOpen ? 'text-indigo-500' : 'text-slate-400'}`}><PanelBottom className="w-4 h-4" /></button>
                </div>

                <div className="flex items-center gap-0.5 overflow-x-auto no-scrollbar flex-1">
                    {workspaces.map(ws => (
                        <div 
                            key={ws.id}
                            draggable
                            onDragStart={(e) => handleWorkspaceDragStart(e, ws.id)}
                            onDragOver={(e) => handleWorkspaceDragOver(e, ws.id)}
                            onDrop={() => setDraggedWorkspaceId(null)}
                            onClick={() => setActiveWorkspaceId(ws.id)}
                            className={`
                                group flex items-center gap-2 px-4 py-2 rounded-t-lg text-xs font-bold transition-all cursor-pointer border-b-2 min-w-[120px] relative
                                ${activeWorkspaceId === ws.id 
                                    ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-500 text-indigo-600 dark:text-indigo-400 shadow-[0_-2px_8px_rgba(79,70,229,0.1)]' 
                                    : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900'}
                            `}
                        >
                            <Layout className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{ws.name}</span>
                            {workspaces.length > 1 && (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleDeleteWorkspace(ws.id); }}
                                    className="opacity-0 group-hover:opacity-100 p-0.5 rounded-full hover:bg-rose-500 hover:text-white transition-all ml-1"
                                >
                                    <X className="w-3 h-3" />
                                </button>
                            )}
                        </div>
                    ))}
                    <button onClick={handleAddWorkspace} className="p-2 text-slate-400 hover:text-indigo-500 transition-colors"><Plus className="w-4 h-4" /></button>
                </div>

                <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-800 ml-2 pl-2">
                    <button onClick={() => setIsSettingsOpen(true)} className="p-1.5 text-slate-400 hover:text-indigo-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800"><Settings className="w-4 h-4" /></button>
                    {/* Plugin Library Toggle - Moved from sidebar content to top bar */}
                    <button 
                        onClick={() => setIsRightSidebarOpen(!isRightSidebarOpen)} 
                        className={`p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${isRightSidebarOpen ? 'text-indigo-500' : 'text-slate-400'}`}
                        title="Toggle Library"
                    >
                        {isRightSidebarOpen ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
                    </button>
                </div>
            </div>

            <div className="flex flex-1 overflow-hidden relative">
                
                {/* Left Sidebar */}
                <aside 
                    className={`
                        bg-slate-100 dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-row 
                        relative z-40 h-full overflow-hidden 
                        ${isLeftSidebarOpen ? '' : 'w-0 border-r-0'}
                        ${isResizing ? '' : 'transition-all duration-300'} 
                    `} 
                    style={{ width: isLeftSidebarOpen ? `${leftWidth}px` : '0' }}
                >
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-2 min-w-[150px]">
                        {activeWorkspace?.sidebarWidgets?.map(widget => {
                            const plugin = REGISTERED_PLUGINS[widget.type];
                            if (!plugin) return null;
                            const ctx = createWidgetContext(widget);
                            return <GridItem key={widget.id} widget={widget} onRemove={handleRemoveWidget} onUpdateWidget={handleUpdateWidget} isDragging={false} onDragStart={handleDragStart(widget.id, widget.layout, 'sidebar')} onShowDocs={setDocsPluginId} onRevertConfig={() => {}} location="sidebar" onMoveLocation={handleMoveLocation} customTitle={`${ctx.symbol} · ${widget.title}`}><plugin.component {...ctx} /></GridItem>;
                        })}
                    </div>
                    {/* Resize Handle Left */}
                    <div 
                        onMouseDown={() => setResizingPanel('left')}
                        className="w-1 cursor-col-resize hover:bg-indigo-500/50 transition-colors shrink-0"
                    />
                </aside>

                {/* Center Column */}
                <div className="flex-1 flex flex-col min-w-0 relative h-full">
                    <main className="flex-1 bg-slate-100 dark:bg-black relative flex flex-col min-w-0 min-h-0">
                        <div className="flex-1 overflow-auto p-1 custom-scrollbar">
                            <div ref={gridRef} className="relative w-full min-h-full" style={{ display: 'grid', gridTemplateColumns: `repeat(${GRID_COLS}, 1fr)`, gridAutoRows: `${ROW_HEIGHT}px`, gap: '2px' }}>
                                {dragState.active && dragState.ghostLayout && dragState.location === 'grid' && (
                                    <div className="bg-indigo-500/10 border-2 border-dashed border-indigo-500/30 rounded-lg pointer-events-none z-0" style={{ 
                                        gridColumn: `${dragState.ghostLayout.x + 1} / span ${dragState.ghostLayout.w}`,
                                        gridRow: `${dragState.ghostLayout.y + 1} / span ${dragState.ghostLayout.h}`
                                    }} />
                                )}
                                {activeWorkspace?.widgets.map(widget => {
                                    const plugin = REGISTERED_PLUGINS[widget.type];
                                    if (!plugin) return null;
                                    const ctx = createWidgetContext(widget);
                                    return <GridItem key={widget.id} widget={widget} onRemove={handleRemoveWidget} onUpdateWidget={handleUpdateWidget} isDragging={dragState.widgetId === widget.id} onDragStart={handleDragStart(widget.id, widget.layout, 'grid')} onShowDocs={setDocsPluginId} onRevertConfig={() => {}} location="grid" onMoveLocation={handleMoveLocation} customTitle={`${ctx.symbol} · ${widget.title}`}><plugin.component {...ctx} /></GridItem>;
                                })}
                            </div>
                        </div>
                    </main>

                    {/* Bottom Panel */}
                    <div 
                        className={`
                            border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 overflow-hidden flex flex-col 
                            ${isBottomPanelOpen ? '' : 'h-0 border-t-0'}
                            ${isResizing ? '' : 'transition-all duration-300'}
                        `} 
                        style={{ height: isBottomPanelOpen ? `${bottomHeight}px` : '0' }}
                    >
                        <div onMouseDown={() => setResizingPanel('bottom')} className="h-1 cursor-ns-resize hover:bg-indigo-500/50 transition-colors shrink-0" />
                        <div className="flex items-center justify-between px-2 py-1 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shrink-0">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Auxiliary Panel</span>
                            <button onClick={() => setIsBottomPanelOpen(false)} className="text-slate-400 hover:text-rose-500"><X className="w-3 h-3" /></button>
                        </div>
                        <div className="flex-1 overflow-x-auto custom-scrollbar flex p-2 gap-2">
                             {activeWorkspace?.bottomWidgets?.map(widget => {
                                const plugin = REGISTERED_PLUGINS[widget.type];
                                if (!plugin) return null;
                                const ctx = createWidgetContext(widget);
                                return <GridItem key={widget.id} widget={widget} onRemove={handleRemoveWidget} onUpdateWidget={handleUpdateWidget} isDragging={false} onDragStart={handleDragStart(widget.id, widget.layout, 'bottom')} onShowDocs={setDocsPluginId} onRevertConfig={() => {}} location="bottom" onMoveLocation={handleMoveLocation} customTitle={widget.title}><plugin.component {...ctx} /></GridItem>;
                            })}
                        </div>
                    </div>
                    <div className="shrink-0 border-t border-slate-800 bg-slate-950 z-20"><TickerTape /></div>
                </div>

                {/* Right Auxiliary Panel */}
                <aside 
                    className={`
                        bg-slate-100 dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-row 
                        relative z-40 h-full overflow-hidden 
                        ${isRightPanelOpen ? '' : 'w-0 border-l-0'}
                        ${isResizing ? '' : 'transition-all duration-300'}
                    `} 
                    style={{ width: isRightPanelOpen ? `${rightWidth}px` : '0' }}
                >
                    <div onMouseDown={() => setResizingPanel('right')} className="w-1 cursor-col-resize hover:bg-indigo-500/50 transition-colors shrink-0" />
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-2 min-w-[150px]">
                        {activeWorkspace?.rightWidgets?.map(widget => {
                            const plugin = REGISTERED_PLUGINS[widget.type];
                            if (!plugin) return null;
                            const ctx = createWidgetContext(widget);
                            return <GridItem key={widget.id} widget={widget} onRemove={handleRemoveWidget} onUpdateWidget={handleUpdateWidget} isDragging={false} onDragStart={handleDragStart(widget.id, widget.layout, 'right')} onShowDocs={setDocsPluginId} onRevertConfig={() => {}} location="right" onMoveLocation={handleMoveLocation} customTitle={widget.title}><plugin.component {...ctx} /></GridItem>;
                        })}
                    </div>
                </aside>

                {/* Plugin Library Sidebar (Right Edge) */}
                <aside 
                    className={`
                        bg-slate-50 dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col 
                        relative z-50 h-full 
                        ${isResizing ? '' : 'transition-all duration-300'}
                        ${isRightSidebarOpen ? 'w-64' : 'w-10'}
                    `}
                >
                    
                    <div className="flex-1 overflow-y-auto custom-scrollbar">
                        {isRightSidebarOpen ? (
                            <div className="p-3 space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1 pt-2">Library</h3>
                                <div className="grid grid-cols-2 gap-2">
                                    {plugins.map(p => (
                                        <button 
                                            key={p.id} 
                                            onClick={() => handleAddWidget(p.id)}
                                            className="flex flex-col items-center gap-2 p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-500 hover:shadow-md transition-all group"
                                        >
                                            <p.icon className="w-5 h-5 text-slate-500 group-hover:text-indigo-500 transition-colors" />
                                            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 truncate w-full text-center">{p.title}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center py-4 gap-4">
                                {plugins.slice(0, 15).map(p => (
                                    <button 
                                        key={p.id} 
                                        onClick={() => handleAddWidget(p.id)}
                                        className="p-2 rounded text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-all" 
                                        title={p.title}
                                    >
                                        <p.icon className="w-5 h-5" />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </aside>
            </div>

            <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} settings={settings} onSave={(s) => { setSettings(s); localStorage.setItem('gq_settings', JSON.stringify(s)); }} />
            <KeyboardWizard 
                isOpen={isWizardOpen} 
                initialChar={wizardChar} 
                onClose={() => setIsWizardOpen(false)} 
                onSelect={handleWizardSelect} 
                watchlists={watchlists} 
                workspaces={workspaces} 
                onSwitchWorkspace={setActiveWorkspaceId} 
            />
        </div>
    );
}
